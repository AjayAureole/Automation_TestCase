﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Text;
using System.Threading.Tasks;

namespace iPAS_ManageDispatchLabel
{
    class ManageDispatchLabelLanguageTemplate
    {
        static CultureInfo ci = null;
        static ResourceManager rm = null;
        static string resMsg_LabelAddSuccessfully = string.Empty;
        public string Msg_LabelAddSuccessfully
        {
            get { return resMsg_LabelAddSuccessfully; }
            set { resMsg_LabelAddSuccessfully = value; }
        }

        static string resMsg_LabelUpdateSuccessfully = string.Empty;
        public string Msg_LabelUpdateSuccessfully
        {
            get { return resMsg_LabelUpdateSuccessfully; }
            set { resMsg_LabelUpdateSuccessfully = value; }
        }

        static string resMsg_LabelNameExits = string.Empty;
        public string Msg_LabelNameExits
        {
            get { return resMsg_LabelNameExits; }
            set { resMsg_LabelNameExits = value; }
        }
        static string resMsg_LabelTypeExits = string.Empty;
        public string Msg_LabelTypeExits
        {
            get { return resMsg_LabelTypeExits; }
            set { resMsg_LabelTypeExits = value; }
        }
        static string resMsg_PleseEnterLabel = string.Empty;
        public string Msg_PleseEnterLabel
        {
            get { return resMsg_PleseEnterLabel; }
            set { resMsg_PleseEnterLabel = value; }
        }

        public static void messageResource(string languageCode)
        {
            if (languageCode == "zh-CN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ManageDispatchLabel.resource.ManageDispatchLabelCN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ManageDispatchLabel.resource.ManageDispatchLabelEN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
        }
        public static void messageInitialize()
        {
            resMsg_LabelAddSuccessfully = rm.GetString("resMsg_LabelAddSuccessfully", ci).Trim();
            resMsg_LabelUpdateSuccessfully = rm.GetString("resMsg_LabelUpdateSuccessfully", ci).Trim();
            resMsg_LabelNameExits = rm.GetString("resMsg_LabelNameExits", ci).Trim();
            resMsg_LabelTypeExits = rm.GetString("resMsg_LabelTypeExits", ci).Trim();
            resMsg_PleseEnterLabel = rm.GetString("resMsg_PleseEnterLabel", ci).Trim();
        }
    }
}
