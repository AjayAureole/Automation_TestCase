﻿using AutoItX3Lib;
using DataDrivenTesting;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace iPAS_ManageDispatchLabel
{
    class ManageDispatchLabel
    {
        string minsleep = ConfigurationSettings.AppSettings["min"];
        string midsleep = ConfigurationSettings.AppSettings["mid"];
        string maxsleep = ConfigurationSettings.AppSettings["max"];
        ManageDispatchLabelLanguageTemplate dispatchLanguage = new ManageDispatchLabelLanguageTemplate();
        public void addDispatchLabelInfo()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(min);
            Click<HtmlHyperlink>(PropertyType.Id, "lnkAdmin");
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(max);
            Click<HtmlDiv>(PropertyType.Id, "footer");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkDispatch");
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(max);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkManageDispatchLabel");
            Thread.Sleep(min);
            auto.MouseClick();
            Thread.Sleep(max);
            auto.Send("{F5}");
            Thread.Sleep(max);
            var totalbefore = window.ExecuteScript("var data=document.getElementById('spnTotalRecords').innerHTML;  return  data");
            string tot = totalbefore.ToString().Trim();
            int totalbeforerecord=0;
            try
            {
                totalbeforerecord = Convert.ToInt32(totalbefore);
            }catch(Exception e) { }
            Thread.Sleep(min);

            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtLabelName", ExcelDataTable.ReadData(1, "Label Name"));
            }catch(Exception e) { }
            try
            {
                Click<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_ddlLabelType");
                Thread.Sleep(mid);
                EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_ddlLabelType", ExcelDataTable.ReadData(1, "Label Type"));
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "txtLabelFormat");
                Thread.Sleep(max);
                mparentwindow = null;
                ////////////////////////
                Thread.Sleep(600);
                var idvalue = window.ExecuteScript("var data=document.getElementById('ulFormats').getElementsByTagName('a')[0];  return  data.id");
                string id = idvalue.ToString().Trim();
                Click<HtmlCustom>(PropertyType.Id, id);
                //////////////////////////////////////////////
            }
            catch (Exception e) { }
            /*********************Clicking on select Button*************************/
            Click<HtmlCustom>(PropertyType.Id, "btnSelectFormat");
            Thread.Sleep(max);
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnAdd");
            Thread.Sleep(mid);
            var data = window.ExecuteScript("var data=document.getElementById('spnAddLabelError').innerHTML;  return  data");
            string msg = data.ToString().Trim();
            if (msg != dispatchLanguage.Msg_LabelAddSuccessfully)
            {
                string screenShotName = "LabelInfo_NotAddedSuccessfully";
                screenShot(screenShotName);
            }
            Assert.AreEqual(dispatchLanguage.Msg_LabelAddSuccessfully, msg, msg);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);
            var afterTotal = window.ExecuteScript("var data=document.getElementById('spnTotalRecords').innerHTML;  return  data");
            string afterTot = afterTotal.ToString().Trim();
            int afterTotalRecords = Convert.ToInt32(afterTot);
            totalbeforerecord = totalbeforerecord + 1;
            Thread.Sleep(mid);
            if (afterTotalRecords != totalbeforerecord)
            {
                string screenShotName = "afterTotalRecords_NotProper";
                screenShot(screenShotName);
            }
            Assert.AreEqual(afterTotalRecords, totalbeforerecord, "Total Record value is Not Proper");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void labelNameMessageCheck()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);
           
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtLabelName", ExcelDataTable.ReadData(1, "Label Name"));
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_ddlLabelType");
                Thread.Sleep(mid);
                EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_ddlLabelType", ExcelDataTable.ReadData(1, "Label Type"));
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "txtLabelFormat");
                Thread.Sleep(max);
                mparentwindow = null;
                ////////////////////////////////////////////
                Thread.Sleep(600);
                var idvalue = window.ExecuteScript("var data=document.getElementById('ulFormats').getElementsByTagName('a')[0];  return  data.id");
                string id = idvalue.ToString().Trim();
                Click<HtmlCustom>(PropertyType.Id, id);
                //////////////////////////////////////////////
            }
            catch (Exception e) { }
            /*********************Clicking on select Button*************************/
            Click<HtmlCustom>(PropertyType.Id, "btnSelectFormat");
            Thread.Sleep(max);
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnAdd");
            Thread.Sleep(mid);
            var data = window.ExecuteScript("var data=document.getElementById('spnAddLabelError').innerHTML;  return  data");
            string msg = data.ToString().Trim();
            if (msg != dispatchLanguage.Msg_LabelNameExits)
            {
                string screenShotName = "LabelInfo_NotAddedSuccessfully";
                screenShot(screenShotName);
            }
            Assert.AreEqual(dispatchLanguage.Msg_LabelNameExits, msg, msg);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);           
        }
        public void labelTypeMessageCheck()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);

            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtLabelName","TypeCheck");
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_ddlLabelType");
                Thread.Sleep(mid);
                EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_ddlLabelType", ExcelDataTable.ReadData(1, "Label Type"));
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "txtLabelFormat");
                Thread.Sleep(max);
                mparentwindow = null;
                ////////////////////////////////////////////
                Thread.Sleep(600);
                var idvalue = window.ExecuteScript("var data=document.getElementById('ulFormats').getElementsByTagName('a')[0];  return  data.id");
                string id = idvalue.ToString().Trim();
                Click<HtmlCustom>(PropertyType.Id, id);
                //////////////////////////////////////////////
            }
            catch (Exception e) { }
            /*********************Clicking on select Button*************************/
            Click<HtmlCustom>(PropertyType.Id, "btnSelectFormat");
            Thread.Sleep(max);
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnAdd");
            Thread.Sleep(mid);
            var data = window.ExecuteScript("var data=document.getElementById('spnAddLabelError').innerHTML;  return  data");
            string msg = data.ToString().Trim();
            if (msg != dispatchLanguage.Msg_LabelTypeExits)
            {
                string screenShotName = "LabelInfo_NotAddedSuccessfully";
                screenShot(screenShotName);
            }
            Assert.AreEqual(dispatchLanguage.Msg_LabelTypeExits, msg, msg);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void searchAndUpdate()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlSpan>(PropertyType.InnerText, ExcelDataTable.ReadData(1, "Label Name"));
            int Mx2 = auto.MouseGetPosX();
            int My2 = auto.MouseGetPosY();
            Mx2 = Mx2 - 100;
            Thread.Sleep(min);
            auto.MouseMove(Mx2, My2);
            auto.MouseClick();
            Thread.Sleep(mid);
            /*********************Updating the Data******************/
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "txtLabelName");
                auto.Send("{BACKSPACE 30}");//Existing Data Deletion
                auto.Send("{DEL 30}");
                EnterText<HtmlEdit>(PropertyType.Id, "txtLabelName", ExcelDataTable.ReadData(1, "UpdateLabel Name"));
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_ddlLabelType");
                Thread.Sleep(mid);
                EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_ddlLabelType", ExcelDataTable.ReadData(1, "UpdateLabel Type"));
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "txtLabelFormat");
                Thread.Sleep(max);
                Thread.Sleep(max);
                mparentwindow = null;
                ////////////////////////////////////////////
                Thread.Sleep(600);
                var idvalue = window.ExecuteScript("var data=document.getElementById('ulFormats').getElementsByTagName('a')[1];  return  data.id");
                string id = idvalue.ToString().Trim();
                Click<HtmlCustom>(PropertyType.Id, id);
                //////////////////////////////////////////////   
            }
            catch (Exception e) { }
            /*********************Clicking on select Button*************************/
            Click<HtmlCustom>(PropertyType.Id, "btnSelectFormat");
            Thread.Sleep(max);
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnAdd");
            Thread.Sleep(mid);
            var data = window.ExecuteScript("var data=document.getElementById('spnAddLabelError').innerHTML;  return  data");
            string msg = data.ToString().Trim();
            if (msg != dispatchLanguage.Msg_LabelUpdateSuccessfully)
            {
                string screenShotName = "LabelInfo_NotupdatedSuccessfully";
                screenShot(screenShotName);
            }
            Assert.AreEqual(dispatchLanguage.Msg_LabelUpdateSuccessfully, msg, msg);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void searchAndDelete()
        {

            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);
            var totalbefore = window.ExecuteScript("var data=document.getElementById('spnTotalRecords').innerHTML;  return  data");
            string tot = totalbefore.ToString().Trim();
            int totalbeforerecord = 0;
            try
            {
                totalbeforerecord = Convert.ToInt32(totalbefore);
            }
            catch (Exception e) { }

            Click<HtmlSpan>(PropertyType.InnerText, ExcelDataTable.ReadData(1, "UpdateLabel Name"));
            int Mx2 = auto.MouseGetPosX();
            int My2 = auto.MouseGetPosY();
            Mx2 = Mx2 - 75;
            Thread.Sleep(min);
            auto.MouseMove(Mx2, My2);
            auto.MouseClick();
            Thread.Sleep(mid);
            auto.Send("{ENTER}");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);
            var afterTotal = window.ExecuteScript("var data=document.getElementById('spnTotalRecords').innerHTML;  return  data");
            string afterTot = afterTotal.ToString().Trim();
            int afterTotalRecords = 0;
            try {
                afterTotalRecords = Convert.ToInt32(afterTot);
            }catch(Exception e) { }
            totalbeforerecord = totalbeforerecord - 1;
            Thread.Sleep(mid);
            if (afterTotalRecords != totalbeforerecord)
            {
                string screenShotName = "afterDeletedTotalRecords_NotProper";
                screenShot(screenShotName);
            }
            Assert.AreEqual(afterTotalRecords, totalbeforerecord, "Total Record value is Not Proper");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void AddButtonClick()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(max);
            auto.Send("{F5}");
            Thread.Sleep(max);
            /**************Without Enter  any Data Click on the Add Button*********/

            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnAdd");
            Thread.Sleep(max);
            var data = window.ExecuteScript("var data=document.getElementById('spnAddLabelError').innerHTML;  return  data");
            string msg = data.ToString().Trim();

            //Here Removining Some Extra thing
            msg = msg.Replace("*", "");
            msg = msg.Replace(" ", "");

            string resMsg = dispatchLanguage.Msg_PleseEnterLabel;
            resMsg = resMsg.Replace(" ", "");
            if (msg != resMsg)
            {
                string screenShotName = "NegativeTestCaseIs_Fail";
                screenShot(screenShotName);
            }
            Assert.AreEqual(resMsg, msg, msg);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnCancel");
        }

        public void screenShot(string imgName)
        {
            BrowserWindow window = new BrowserWindow();
            string path = ConfigurationSettings.AppSettings["ScreenShot"];
            path = path + @"\\iPAS_ManageDispatchLabel";
            Directory.CreateDirectory(path);
            try
            {
                window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
                Image image = window.CaptureImage();
                image.Save(path + "\\" + imgName + ".jpeg", ImageFormat.Jpeg);
                image.Dispose();
            }
            catch (Exception e) { }
            Console.WriteLine("Screen Shot is Avaliable in " + path + "\t" + "Folder");
        }
        public void WindowButtonClick<T>(PropertyType type, string propertyvalue) where T : WinControl
        {
            WinControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Name)
                genericControl.SearchProperties[WinControl.PropertyNames.Name] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void PathEnterText<T>(PropertyType type, string propertyvalue, string text) where T : WinEdit
        {
            WinEdit genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            genericControl.FilterProperties[WinEdit.PropertyNames.Name] = propertyvalue;
            AutoItX3 auto = new AutoItX3();
            auto.WinActivate("Choose File to Upload");
            auto.Send(text);
            auto.Send("{ENTER}");
            Thread.Sleep(1000);
        }
        public void Click<T>(PropertyType type, string propertyvalue) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });

            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;
            else if (type == PropertyType.InnerText)
            {
                genericControl.SearchProperties[HtmlControl.PropertyNames.InnerText] = propertyvalue;
            }
            else if (type == PropertyType.TagInstance)
                genericControl.FilterProperties[HtmlControl.PropertyNames.TagInstance] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void EnterText<T>(PropertyType type, string propertyvalue, string text) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;

            Keyboard.SendKeys(genericControl, text);
        }
        private BrowserWindow mparentwindow { get; set; }
        public enum PropertyType
        {
            Id,
            Name,
            InnerText,
            TagInstance
        }
        public BrowserWindow TopParentWindow()
        {

            BrowserWindow window = new BrowserWindow();
            window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
            return window;
        }
        public BrowserWindow ParentWindow
        {
            get
            {
                if (this.mparentwindow == null)
                {
                    this.mparentwindow = TopParentWindow();
                }
                return this.mparentwindow;
            }
        }

    }
}
