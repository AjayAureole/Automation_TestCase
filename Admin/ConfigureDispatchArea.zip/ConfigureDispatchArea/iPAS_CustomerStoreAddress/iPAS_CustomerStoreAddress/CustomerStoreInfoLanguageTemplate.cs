﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Text;
using System.Threading.Tasks;

namespace iPAS_CustomerStoreAddress
{
    class CustomerStoreInfoLanguageTemplate
    {
        static CultureInfo ci = null;
        static ResourceManager rm = null;
        static string resMsg_CustomerStoreInfoAddedSuccessfully = string.Empty;
        public string Msg_CustomerStoreInfoAddedSuccessfully
        {
            get { return resMsg_CustomerStoreInfoAddedSuccessfully; }
            set { resMsg_CustomerStoreInfoAddedSuccessfully = value; }
        }

        static string resMsg_CustomerStoreInfoUpdatedSuccessfully = string.Empty;
        public string Msg_CustomerStoreInfoUpdatedSuccessfully
        {
            get { return resMsg_CustomerStoreInfoUpdatedSuccessfully; }
            set { resMsg_CustomerStoreInfoUpdatedSuccessfully = value; }
        }

        static string resMsg_NoRecordsFound = string.Empty;
        public string Msg_NoRecordsFound
        {
            get { return resMsg_NoRecordsFound; }
            set { resMsg_NoRecordsFound = value; }
        }
        static string resMsg_EntercustomerID = string.Empty;
        public string Msg_EntercustomerID
        {
            get { return resMsg_EntercustomerID; }
            set { resMsg_EntercustomerID = value; }
        }
        static string resMsg_EnterStoreID = string.Empty;
        public string Msg_EnterStoreID
        {
            get { return resMsg_EnterStoreID; }
            set { resMsg_EnterStoreID = value; }
        }

        static string resMsg_InvalidFormat = string.Empty;
        public string Msg_InvalidFormat
        {
            get { return resMsg_InvalidFormat; }
            set { resMsg_InvalidFormat = value; }
        }
        static string resMsg_EnterSearchCriteria = string.Empty;
        public string Msg_EnterSearchCriteria
        {
            get { return resMsg_EnterSearchCriteria; }
            set { resMsg_EnterSearchCriteria = value; }
        }
        public static void messageResource(string languageCode)
        {
            if (languageCode == "zh-CN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_CustomerStoreAddress.resource.CustomerStoreInfoCN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_CustomerStoreAddress.resource.CustomerStoreInfoEN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
        }
        public static void messageInitialize()
        {
            resMsg_CustomerStoreInfoAddedSuccessfully = rm.GetString("resMsg_CustomerStoreInfoAddedSuccessfully", ci).Trim();
            resMsg_CustomerStoreInfoUpdatedSuccessfully = rm.GetString("resMsg_CustomerStoreInfoUpdatedSuccessfully", ci).Trim();
            resMsg_NoRecordsFound = rm.GetString("resMsg_NoRecordsFound", ci).Trim();
            resMsg_EntercustomerID = rm.GetString("resMsg_EntercustomerID", ci).Trim();
            resMsg_EnterStoreID = rm.GetString("resMsg_EnterStoreID", ci).Trim(); 
             resMsg_InvalidFormat = rm.GetString("resMsg_InvalidFormat", ci).Trim();
            resMsg_EnterSearchCriteria = rm.GetString("resMsg_EnterSearchCriteria", ci).Trim();

        }
    }
}
