﻿using AutoItX3Lib;
using DataDrivenTesting;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace iPAS_CustomerStoreAddress
{
       
    class CustomerStoreAddressInfo
    {
        string minsleep = ConfigurationSettings.AppSettings["min"];
        string midsleep = ConfigurationSettings.AppSettings["mid"];
        string maxsleep = ConfigurationSettings.AppSettings["max"];
        CustomerStoreInfoLanguageTemplate storeLanguage = new CustomerStoreInfoLanguageTemplate();
        public void addStoreInfo()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(min);
            Click<HtmlHyperlink>(PropertyType.Id, "lnkAdmin");
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(max);
            Click<HtmlDiv>(PropertyType.Id, "footer");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkDispatch");
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(max);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkStoreAddress");
            Thread.Sleep(min);
            auto.MouseClick();
            Thread.Sleep(max);
            auto.Send("{F5}");
            Thread.Sleep(max);
          
            try {
                EnterText<HtmlEdit>(PropertyType.Id, "txtCustomerID", ExcelDataTable.ReadData(1, "Customer ID"));
            }catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtName", ExcelDataTable.ReadData(1, "Name"));
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtStoreID", ExcelDataTable.ReadData(1, "Store ID"));
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlTextArea>(PropertyType.Id, "ContentPlaceHolder1_txtStreet", ExcelDataTable.ReadData(1, "Street"));
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtRegion", ExcelDataTable.ReadData(1, "Region"));
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtCity", ExcelDataTable.ReadData(1, "City"));
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtState", ExcelDataTable.ReadData(1, "State"));
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtPostalCode", ExcelDataTable.ReadData(1, "Postal Code"));
            }catch(Exception e) { }
            Thread.Sleep(mid);
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnAddCustomerStoreInfo");
            Thread.Sleep(max);
            var data = window.ExecuteScript("var data=document.getElementById('spnCustomerStoreInfoError').innerHTML;  return  data");
            string msg = data.ToString().Trim();
            Thread.Sleep(mid);
            if (storeLanguage.Msg_CustomerStoreInfoAddedSuccessfully!=msg)
            {
                string screenShotName = "CustomerStoreInfoAdded_NotSuccessfully";
                screenShot(screenShotName);
            }
            Assert.AreEqual(storeLanguage.Msg_CustomerStoreInfoAddedSuccessfully, msg,msg);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void SearchAndUpdate()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);           
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtCustomerId", ExcelDataTable.ReadData(1, "Customer ID"));
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtCustomerName", ExcelDataTable.ReadData(1, "Name"));
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtStoreId", ExcelDataTable.ReadData(1, "Store ID"));
            }
            catch (Exception e) { }
            Thread.Sleep(min);
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearch");
            Thread.Sleep(mid);
            /*************************Clicking on the Action Header and than Edit button***************************/
            Click<HtmlHeaderCell>(PropertyType.InnerText, "Action");
            Thread.Sleep(min);
            int xCoodinate1 = auto.MouseGetPosX();
            int yCoodinate1 = auto.MouseGetPosY();
            yCoodinate1 = yCoodinate1 + 30;
            xCoodinate1 = xCoodinate1 - 15;
            auto.MouseMove(xCoodinate1, yCoodinate1);
            Thread.Sleep(min);
            auto.MouseClick();
            Thread.Sleep(max*2);

            /*Start the Updating the Data*/

            try
            {
                Click<HtmlEdit>(PropertyType.Id, "txtName");
                auto.Send("{BACKSPACE 30}");//Existing Data Deletion
                auto.Send("{DEL 30}");
                EnterText<HtmlEdit>(PropertyType.Id, "txtName", ExcelDataTable.ReadData(1, "UpdateName"));
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "txtStoreID");
                auto.Send("{BACKSPACE 30}");//Existing Data Deletion
                auto.Send("{DEL 30}");
                EnterText<HtmlEdit>(PropertyType.Id, "txtStoreID", ExcelDataTable.ReadData(1, "UpdateStore ID"));
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlTextArea>(PropertyType.Id, "ContentPlaceHolder1_txtStreet");
                auto.Send("{BACKSPACE 30}");//Existing Data Deletion
                auto.Send("{DEL 30}");
                EnterText<HtmlTextArea>(PropertyType.Id, "ContentPlaceHolder1_txtStreet", ExcelDataTable.ReadData(1, "UpdateStreet"));
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "txtRegion");
                auto.Send("{BACKSPACE 30}");//Existing Data Deletion
                auto.Send("{DEL 30}");
                EnterText<HtmlEdit>(PropertyType.Id, "txtRegion", ExcelDataTable.ReadData(1, "UpdateRegion"));
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "txtCity");
                auto.Send("{BACKSPACE 30}");//Existing Data Deletion
                auto.Send("{DEL 30}");
                EnterText<HtmlEdit>(PropertyType.Id, "txtCity", ExcelDataTable.ReadData(1, "UpdateCity"));
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "txtState");
                auto.Send("{BACKSPACE 30}");//Existing Data Deletion
                auto.Send("{DEL 30}");
                EnterText<HtmlEdit>(PropertyType.Id, "txtState", ExcelDataTable.ReadData(1, "UpdateState"));
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "txtPostalCode");
                auto.Send("{BACKSPACE 30}");//Existing Data Deletion
                auto.Send("{DEL 30}");
                EnterText<HtmlEdit>(PropertyType.Id, "txtPostalCode", ExcelDataTable.ReadData(1, "UpdatePostal Code"));
            }
            catch (Exception e) { }
            Thread.Sleep(mid);
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnAddCustomerStoreInfo");
            Thread.Sleep(max);
            var data = window.ExecuteScript("var data=document.getElementById('spnCustomerStoreInfoError').innerHTML;  return  data");
            string msg = data.ToString().Trim();
            Thread.Sleep(mid);
            if (storeLanguage.Msg_CustomerStoreInfoUpdatedSuccessfully != msg)
            {
                string screenShotName = "CustomerStoreInfoUpdated_NotSuccessfully";
                screenShot(screenShotName);
            }
            Assert.AreEqual(storeLanguage.Msg_CustomerStoreInfoUpdatedSuccessfully, msg, msg);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void deleteAddData()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtCustomerId", ExcelDataTable.ReadData(1, "Customer ID"));
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtCustomerName", ExcelDataTable.ReadData(1, "UpdateName"));
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtStoreId", ExcelDataTable.ReadData(1, "UpdateStore ID"));
            }
            catch (Exception e) { }
            Thread.Sleep(min);
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearch");
            Thread.Sleep(mid);
            /*************************Clicking on the Action Header and than Edit button***************************/
            Click<HtmlHeaderCell>(PropertyType.InnerText, "Action");
            Thread.Sleep(min);
            int xCoodinate = auto.MouseGetPosX();
            int yCoodinate = auto.MouseGetPosY();
            yCoodinate = yCoodinate + 30;
            xCoodinate = xCoodinate + 10;
            auto.MouseMove(xCoodinate, yCoodinate);
            Thread.Sleep(mid);
            auto.MouseClick();
            Thread.Sleep(min);
            auto.Send("{ENTER}");
            Thread.Sleep(mid);
            try
            {
                Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearchAll");
            }catch(Exception e) {

            }

            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void uploadingExcel()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);
            Click<HtmlCustom>(PropertyType.Id, "aUploadExcel");
            Thread.Sleep(mid);
            Click<HtmlFileInput>(PropertyType.Id, "ContentPlaceHolder1_uploadFile");
            Thread.Sleep(min);
            try
            {
                PathEnterText<WinEdit>(PropertyType.Name, "File name:", ExcelDataTable.ReadData(1, "filePath"));
                Thread.Sleep(mid);
            }
            catch (Exception e) { }
            Thread.Sleep(max * 10);
            /**********Here Validate image uploading Valid or Not*****************/
            var data2 = window.ExecuteScript("var data=document.getElementById('spnUploadError').innerHTML;  return  data");
            string successMsg2 = data2.ToString().Trim();
            if ("" != successMsg2)
            {
                string screenShotName = "NotUploaded";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", successMsg2, successMsg2);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void DeleteUploadingdata()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtCustomerId", ExcelDataTable.ReadData(1, "Customer ID1"));
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtCustomerName", ExcelDataTable.ReadData(1, "Name1"));
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtStoreId", ExcelDataTable.ReadData(1, "Store ID1"));
            }
            catch (Exception e) { }
            Thread.Sleep(min);
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearch");
            Thread.Sleep(mid);
            /*************************Clicking on the Action Header and than Edit button***************************/
            Click<HtmlHeaderCell>(PropertyType.InnerText, "Action");
            Thread.Sleep(min);
            int xCoodinate = auto.MouseGetPosX();
            int yCoodinate = auto.MouseGetPosY();
            yCoodinate = yCoodinate + 30;
            xCoodinate = xCoodinate + 10;
            auto.MouseMove(xCoodinate, yCoodinate);
            Thread.Sleep(mid);
            auto.MouseClick();
            Thread.Sleep(min);
            auto.Send("{ENTER}");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);


            /*********************Here click Search Button without Entering any thing*******/
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearch");
            Thread.Sleep(mid);
            var data2 = window.ExecuteScript("var data=document.getElementById('spnSearchError').innerHTML;  return  data");
            string successMsg2 = data2.ToString().Trim();
            if (storeLanguage.Msg_EnterSearchCriteria != successMsg2)
            {
                string screenShotName = "EnterSearchCriteria_NotValid";
                screenShot(screenShotName);
            }
            Assert.AreEqual(storeLanguage.Msg_EnterSearchCriteria, successMsg2, successMsg2);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);

        }
        public void FindData()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtCustomerId", ExcelDataTable.ReadData(1, "Customer ID1"));
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtCustomerName", ExcelDataTable.ReadData(1, "Name1"));
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtStoreId", ExcelDataTable.ReadData(1, "Store ID1"));
            }
            catch (Exception e) { }
            Thread.Sleep(min);
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearch");
            Thread.Sleep(max);
            bool b1 = Search();
            if (!b1)
            {
                string screenShotName = "Data_NotDeleted";
                screenShot(screenShotName);
            }
            Assert.IsTrue(b1,"Data is Not Deleted");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
       }
        public void NegativeValidation()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);
            Click<HtmlCustom>(PropertyType.Id, "aUploadExcel");
            Thread.Sleep(mid);
            Click<HtmlFileInput>(PropertyType.Id, "ContentPlaceHolder1_uploadFile");
            Thread.Sleep(min);
            try
            {
                PathEnterText<WinEdit>(PropertyType.Name, "File name:", ExcelDataTable.ReadData(1, "txtfilePath"));
                Thread.Sleep(mid);
            }
            catch (Exception e) { }
            Thread.Sleep(max * 6);
            /**********Here Validate image uploading Valid or Not*****************/
            var data2 = window.ExecuteScript("var data=document.getElementById('spnUploadError').innerHTML;  return  data");
            string successMsg2 = data2.ToString().Trim();
            if (storeLanguage.Msg_InvalidFormat != successMsg2)
            {
                string screenShotName = "FileIs_NotProper";
                screenShot(screenShotName);
            }
            Assert.AreEqual(storeLanguage.Msg_InvalidFormat, successMsg2, successMsg2);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void AddButtonClick()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(max);
            auto.Send("{F5}");
            Thread.Sleep(max);
            /**************Without Enter  any Data Click on the Add Button*********/

            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnAddCustomerStoreInfo");
            Thread.Sleep(max);
            var data = window.ExecuteScript("var data=document.getElementById('spnCustomerStoreInfoError').innerHTML;  return  data");
            string msg = data.ToString().Trim();

            //Here Removining Some Extra thing
            msg = msg.Replace("*", "");
            msg = msg.Replace("<br>", "");
            msg = msg.Replace(" ", "");

            string resMsg = storeLanguage.Msg_EntercustomerID+ storeLanguage.Msg_EnterStoreID;
            resMsg = resMsg.Replace(" ", "");
            if (msg != resMsg)
            {
                string screenShotName = "NegativeTestCaseIs_Fail";
                screenShot(screenShotName);
            }
            Assert.AreEqual(resMsg, msg, msg);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(max);
            try
            {
                Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnCancel");
            }
            catch (Exception e) { }
        }
        public void downloadTemplate()
        {

            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_downLoadTemplateLink");
            Thread.Sleep(max * 5);
            Click<HtmlDiv>(PropertyType.Id, "footer");
            bool open = false;
            try
            {
                WindowButtonClick<WinToolBar>(PropertyType.Name, "Notification");
                WindowButtonClick<WinButton>(PropertyType.Name, "Open");
                mparentwindow = null;
                Thread.Sleep(max * 10);
                open = true;
                auto.WinClose("Excel");
                auto.WinClose("Microsoft Excel");
            }
            catch (Exception e)
            {
                if (!open)
                {
                    screenShot("OPENButtonProblem");
                    Assert.IsTrue(open, "Not Able to Click Open Button");
                }
            }
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void sendExcelFile()
        {

            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnSendToExcel");
            Thread.Sleep(max * 25);
            Click<HtmlDiv>(PropertyType.Id, "footer");
            bool open = false;
            try
            {
                WindowButtonClick<WinToolBar>(PropertyType.Name, "Notification");
                WindowButtonClick<WinButton>(PropertyType.Name, "Open");
                mparentwindow = null;
                Thread.Sleep(max * 10);
                open = true;
                auto.WinClose("Excel");
                auto.WinClose("Microsoft Excel");
            }
            catch (Exception e)
            {
                if (!open)
                {
                    screenShot("OPENButtonProblem");
                    Assert.IsTrue(open, "Not Able to Click Open Button");
                }
            }
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }




        public bool Search()
        {
            BrowserWindow window = new BrowserWindow();
            Thread.Sleep(600);
            var data1 = window.ExecuteScript("var data=document.getElementById('ContentPlaceHolder1_tbCustomerStoreInfo').getElementsByTagName('span')[0];  return  data.innerHTML");
            string msg1 = data1.ToString().Trim();
             bool b1 = msg1.Equals(storeLanguage.Msg_NoRecordsFound);
            return b1;
        }
        //public void SentEmail()
        //{
        //    string smtpAddress = "smtp-relay.gmail.com";
        //    int portNumber = 587;
        //    bool enableSSL = true;
        //    string emailFrom = "ab366665@gmail.com";
        //    string password = "Ajay14326";

            //    string emailTo = "ajaykumar@aureoleinc.com";
            //    string subject = "Hello";
            //    string tbody = "Hello, I'm just writing this to say Hi!";

            //    MailMessage msg = new MailMessage(emailFrom, emailTo, subject, tbody);
            //    msg.IsBodyHtml = true;
            //    SmtpClient sc = new SmtpClient("smtp.gmail.com", 587);
            //    sc.UseDefaultCredentials = false;
            //    NetworkCredential cre = new NetworkCredential(emailFrom, password);
            //    sc.Credentials = cre;
            //    sc.EnableSsl = true;
            //    sc.Send(msg);
            //}
        public void screenShot(string imgName)
        {
            BrowserWindow window = new BrowserWindow();
            string path = ConfigurationSettings.AppSettings["ScreenShot"];
            path = path + @"\\iPAS_CustomerStoreAddress";
            Directory.CreateDirectory(path);
            try
            {
                window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
                Image image = window.CaptureImage();
                image.Save(path + "\\" + imgName + ".jpeg", ImageFormat.Jpeg);
                image.Dispose();
            }
            catch (Exception e) { }
            Console.WriteLine("Screen Shot is Avaliable in " + path + "\t" + "Folder");
        }
        public void WindowButtonClick<T>(PropertyType type, string propertyvalue) where T : WinControl
        {
            WinControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Name)
                genericControl.SearchProperties[WinControl.PropertyNames.Name] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void PathEnterText<T>(PropertyType type, string propertyvalue, string text) where T : WinEdit
        {
            WinEdit genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            genericControl.FilterProperties[WinEdit.PropertyNames.Name] = propertyvalue;
            AutoItX3 auto = new AutoItX3();
            auto.WinActivate("Choose File to Upload");
            auto.Send(text);
            auto.Send("{ENTER}");
            Thread.Sleep(1000);
        }
        public void Click<T>(PropertyType type, string propertyvalue) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });

            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;
            else if (type == PropertyType.InnerText)
            {
                genericControl.SearchProperties[HtmlControl.PropertyNames.InnerText] = propertyvalue;
            }
            else if (type == PropertyType.TagInstance)
                genericControl.FilterProperties[HtmlControl.PropertyNames.TagInstance] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void EnterText<T>(PropertyType type, string propertyvalue, string text) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;

            Keyboard.SendKeys(genericControl, text);

        }
        private BrowserWindow mparentwindow { get; set; }
        public enum PropertyType
        {
            Id,
            Name,
            InnerText,
            TagInstance
        }
        public BrowserWindow TopParentWindow()
        {

            BrowserWindow window = new BrowserWindow();
            window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
            return window;
        }
        public BrowserWindow ParentWindow
        {
            get
            {
                if (this.mparentwindow == null)
                {
                    this.mparentwindow = TopParentWindow();
                }
                return this.mparentwindow;
            }
        }

    }
}
