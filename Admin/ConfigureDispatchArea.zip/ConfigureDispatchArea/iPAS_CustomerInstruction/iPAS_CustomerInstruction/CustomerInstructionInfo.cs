﻿using AutoItX3Lib;
using DataDrivenTesting;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace iPAS_CustomerInstruction
{
    class CustomerInstructionInfo
    {
        string minsleep = ConfigurationSettings.AppSettings["min"];
        string midsleep = ConfigurationSettings.AppSettings["mid"];
        string maxsleep = ConfigurationSettings.AppSettings["max"];
        CustomerInstructionLanguageTemplate cuslanguage = new CustomerInstructionLanguageTemplate();
        public void AddNewShipToNumber()
        {           
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "lnkAdmin");
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(max);
            Click<HtmlDiv>(PropertyType.Id, "footer");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkDispatch");
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(max);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkCustInstructions");
            Thread.Sleep(min);
            auto.MouseClick();
            Thread.Sleep(max);
            auto.Send("{F5}");
            Thread.Sleep(max);
            var totalbefore = window.ExecuteScript("var data=document.getElementById('spnTotalRecords').innerHTML;  return  data");
            string tot = totalbefore.ToString().Trim();
            int totalbeforerecord = Convert.ToInt32(totalbefore);
            Thread.Sleep(max);

            try {
                EnterText<HtmlEdit>(PropertyType.Id, "txtShipNum", ExcelDataTable.ReadData(1, "Ship To Number"));
            } catch(Exception e) { }

            try {
                EnterText<HtmlEdit>(PropertyType.Id, "txtDispatchCustName", ExcelDataTable.ReadData(1, "Customer Name"));
            }
            catch (Exception e) { }
            try {
                EnterText<HtmlEdit>(PropertyType.Id, "txtShelfLife", ExcelDataTable.ReadData(1, "Shelf Life"));
            }
            catch (Exception e) { }
            try {
                Click<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpShelfPeriod");
                EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpShelfPeriod", ExcelDataTable.ReadData(1, "Shelf LifeList"));
            }
            catch (Exception e) { }
            try {
                EnterText<HtmlTextArea>(PropertyType.Id, "txtPickInst", ExcelDataTable.ReadData(1, "Picking Instruction"));
            }
            catch (Exception e) { }
            try {
                EnterText<HtmlTextArea>(PropertyType.Id, "txtShippingInst", ExcelDataTable.ReadData(1, "Shipping Instruction"));
            }
            catch (Exception e) { }
            try {
                EnterText<HtmlEdit>(PropertyType.Id, "txtSSCCNumOfLabel", ExcelDataTable.ReadData(1, "Number of Label"));
            }
            catch (Exception e) { }
            try
            {
                Thread.Sleep(min);
                Click<HtmlDiv>(PropertyType.Id, "footer");
                Thread.Sleep(min);
            }
            catch (Exception e) { }
            try {
                Click<HtmlRadioButton>(PropertyType.Id, "withMaterialDescRadio");
            }
            catch (Exception e) { }
            try {
                Click<HtmlCheckBox>(PropertyType.Id, "chkEAN");
            }
            catch (Exception e) { }
            try {
                EnterText<HtmlEdit>(PropertyType.Id, "txtEANNumOfLabel", ExcelDataTable.ReadData(1, "Number of Label"));
            }
            catch (Exception e) { }
            Thread.Sleep(max);
            Click<HtmlCustom>(PropertyType.Id, "ContentPlaceHolder1_btnAddCustomer");
            Thread.Sleep(max);
            var afterTotal = window.ExecuteScript("var data=document.getElementById('spnTotalRecords').innerHTML;  return  data");
            string afterTot = afterTotal.ToString().Trim();
            int afterTotalRecords = Convert.ToInt32(afterTot);
            totalbeforerecord = totalbeforerecord + 1;
            Thread.Sleep(min);
            if (afterTotalRecords != totalbeforerecord)
            {
                string screenShotName = "afterTotalRecords_NotProper";
                screenShot(screenShotName);
            }
            Thread.Sleep(min);
            Assert.AreEqual(afterTotalRecords, totalbeforerecord, "Total Record value is Not Proper");
            Thread.Sleep(max);
            var data = window.ExecuteScript("var data=document.getElementById('lblErrorMsg').innerHTML;  return  data");
            string msg = data.ToString().Trim();
            Thread.Sleep(min);
        /*
            ///////////////////////////////////////////

            var filePath = @"E:\AutomationProject\ADMIN\report.csv";
            var csv = new StringBuilder();

            var newLine = string.Format("{0}", msg);
            csv.AppendLine(newLine);

            //after your loop
            File.WriteAllText(filePath, csv.ToString());

            /////////////////////////////////////////////
    */
            if (msg != cuslanguage.Msg_ShipNumberAddedSuccessfully)
            {
                string screenShotName = "added_Notsuccessfully";
                screenShot(screenShotName);
            }
            Assert.AreEqual(cuslanguage.Msg_ShipNumberAddedSuccessfully, msg, msg);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }      
        public void update()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);
            try
            {
                Click<HtmlDiv>(PropertyType.Id, "divRecords");
            }catch(Exception e) { }
            try {
                Click<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpSearch");
                EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpSearch", "Ship To Number");
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtSearch", ExcelDataTable.ReadData(1, "Ship To Number"));
            }
            catch (Exception e) { }
            Thread.Sleep(min);
            Click<HtmlCustom>(PropertyType.Id, "ContentPlaceHolder1_btnGo");
            Thread.Sleep(mid);
            /*************************Clicking on the Data***************************/
            Click<HtmlDiv>(PropertyType.Id, "ctl01_divShipToNumber");
            int Mx2 = auto.MouseGetPosX();
            int My2 = auto.MouseGetPosY();
            Mx2 = Mx2 - 115;
            Thread.Sleep(max);
            auto.MouseMove(Mx2, My2);
            auto.MouseClick();
            Thread.Sleep(max);
          
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "txtDispatchCustName");
                auto.Send("{BACKSPACE 30}");//Existing Data Deletion
                auto.Send("{DEL 30}");
                EnterText<HtmlEdit>(PropertyType.Id, "txtDispatchCustName", ExcelDataTable.ReadData(1, "UpCustomer Name"));
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "txtShelfLife");
                auto.Send("{BACKSPACE 30}");//Existing Data Deletion
                auto.Send("{DEL 30}");
                EnterText<HtmlEdit>(PropertyType.Id, "txtShelfLife", ExcelDataTable.ReadData(1, "UpShelf Life"));
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpShelfPeriod");
                EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpShelfPeriod", ExcelDataTable.ReadData(1, "UpShelf LifeList"));
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlTextArea>(PropertyType.Id, "txtPickInst");
                auto.Send("{BACKSPACE 30}");//Existing Data Deletion
                auto.Send("{DEL 30}");
                EnterText<HtmlTextArea>(PropertyType.Id, "txtPickInst", ExcelDataTable.ReadData(1, "UpPicking Instruction"));
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlTextArea>(PropertyType.Id, "txtShippingInst");
                auto.Send("{BACKSPACE 30}");//Existing Data Deletion
                auto.Send("{DEL 30}");
                EnterText<HtmlTextArea>(PropertyType.Id, "txtShippingInst", ExcelDataTable.ReadData(1, "UpShipping Instruction"));
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "txtSSCCNumOfLabel");
                auto.Send("{BACKSPACE 10}");//Existing Data Deletion
                auto.Send("{DEL 10}");
                EnterText<HtmlEdit>(PropertyType.Id, "txtSSCCNumOfLabel", ExcelDataTable.ReadData(1, "UpNumber of Label"));
            }
            catch (Exception e) { }
            try
            {
                Thread.Sleep(min);
                Click<HtmlDiv>(PropertyType.Id, "footer");
                Thread.Sleep(min);
            }
            catch (Exception e) { }
            try
            {                
                Click<HtmlRadioButton>(PropertyType.Id, "withoutMaterialDescRadio");
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlCheckBox>(PropertyType.Id, "chkEAN");
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "txtEANNumOfLabel");
                auto.Send("{BACKSPACE 10}");//Existing Data Deletion
                auto.Send("{DEL 10}");
                EnterText<HtmlEdit>(PropertyType.Id, "txtEANNumOfLabel", ExcelDataTable.ReadData(1, "UpNumber of Label"));
            }
            catch (Exception e) { }
            Thread.Sleep(max);
            Click<HtmlCustom>(PropertyType.Id, "ContentPlaceHolder1_btnUpdateCustomer");
            Thread.Sleep(max);
            var data = window.ExecuteScript("var data=document.getElementById('lblErrorMsg').innerHTML;  return  data");
            string msg = data.ToString().Trim();
            Thread.Sleep(min);
            if (msg != cuslanguage.Msg_ShipToNumberUpdatedSuccessfully)
            {
                string screenShotName = "updated_Notsuccessfully";
                screenShot(screenShotName);
            }
            Assert.AreEqual(cuslanguage.Msg_ShipToNumberUpdatedSuccessfully, msg, msg);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void ComparePickingInstruction()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);
            try
            {
                Click<HtmlDiv>(PropertyType.Id, "divRecords");
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpSearch");
                EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpSearch", "Ship To Number");
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtSearch", ExcelDataTable.ReadData(1, "Ship To Number"));
            }
            catch (Exception e) { }
            Thread.Sleep(min);
            Click<HtmlCustom>(PropertyType.Id, "ContentPlaceHolder1_btnGo");
            Thread.Sleep(mid);
            /*************************Clicking on the Data***************************/
            Click<HtmlDiv>(PropertyType.Id, "ctl01_divShipToNumber");
            int Mx2 = auto.MouseGetPosX();
            int My2 = auto.MouseGetPosY();
            Mx2 = Mx2 + 275;
            Thread.Sleep(max);
            auto.MouseMove(Mx2, My2);            
            Thread.Sleep(max);

            /************************************/
            string pickingInstruction = ExcelDataTable.ReadData(1, "UpPicking Instruction").Trim();
            var data = window.ExecuteScript("var data=document.getElementById('ctl01_spnPickingContent').innerHTML;  return  data");
            string msg = data.ToString().Trim();
            if (pickingInstruction != msg)
            {
                string screenShotName = "pickingInstruction_NotProper";
                screenShot(screenShotName);
            }
            Assert.AreEqual(pickingInstruction, msg, "pickingInstruction_NotProper");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void CompareShippingInstruction()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);
            try
            {
                Click<HtmlDiv>(PropertyType.Id, "divRecords");
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpSearch");
                EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpSearch", "Ship To Number");
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtSearch", ExcelDataTable.ReadData(1, "Ship To Number"));
            }
            catch (Exception e) { }
            Thread.Sleep(min);
            Click<HtmlCustom>(PropertyType.Id, "ContentPlaceHolder1_btnGo");
            Thread.Sleep(mid);
            /*************************Clicking on the Data***************************/
            Click<HtmlDiv>(PropertyType.Id, "ctl01_divShipToNumber");
            int Mx2 = auto.MouseGetPosX();
            int My2 = auto.MouseGetPosY();
            Mx2 = Mx2 + 415;
            Thread.Sleep(max);
            auto.MouseMove(Mx2, My2);
            Thread.Sleep(max);

            /************************************/
            string pickingInstruction = ExcelDataTable.ReadData(1, "UpShipping Instruction").Trim();
            var data = window.ExecuteScript("var data=document.getElementById('ctl01_spnShippingContent').innerHTML;  return  data");
            string msg = data.ToString().Trim();
            if (pickingInstruction != msg)
            {
                string screenShotName = "ShippingInstruction_NotProper";
                screenShot(screenShotName);
            }
            Assert.AreEqual(pickingInstruction, msg, "ShippingInstruction_NotProper");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void delete()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);
            try
            {
                Click<HtmlDiv>(PropertyType.Id, "divRecords");
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpSearch");
                EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpSearch", "Ship To Number");
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtSearch", ExcelDataTable.ReadData(1, "Ship To Number"));
            }
            catch (Exception e) { }
            Thread.Sleep(min);
            Click<HtmlCustom>(PropertyType.Id, "ContentPlaceHolder1_btnGo");            
            Thread.Sleep(mid);
            /*************************Clicking on the Data***************************/
            Click<HtmlDiv>(PropertyType.Id, "ctl01_divShipToNumber");
            int Mx2 = auto.MouseGetPosX();
            int My2 = auto.MouseGetPosY();
            Mx2 = Mx2 - 95;
            Thread.Sleep(max);
            auto.MouseMove(Mx2, My2);
            auto.MouseClick();
            Thread.Sleep(min);
            auto.Send("{ENTER}");
            Thread.Sleep(max);
            try
            {
                Click<HtmlCustom>(PropertyType.Id, "ContentPlaceHolder1_btnShowAll");
            }catch(Exception e) { }
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void findData()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);
            try
            {
                Click<HtmlDiv>(PropertyType.Id, "divRecords");
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpSearch");
                EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpSearch", "Ship To Number");
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtSearch", ExcelDataTable.ReadData(1, "Ship To Number"));
            }
            catch (Exception e) { }
            Thread.Sleep(min);
            Click<HtmlCustom>(PropertyType.Id, "ContentPlaceHolder1_btnGo");
            Thread.Sleep(max);
            bool b1 = Search();
            if (!b1)
            {
                string screenShotName = "Data_IsNotDeleted";
                screenShot(screenShotName);
            }
            Assert.IsTrue(b1, "Data is Not Deleted");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void AddButtonClick()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(max);
            auto.Send("{F5}");
            Thread.Sleep(max);
            /**************Without Enter  any Data Click on the Add Button*********/

            Click<HtmlCustom>(PropertyType.Id, "ContentPlaceHolder1_btnAddCustomer");
            Thread.Sleep(max);
            var data = window.ExecuteScript("var data=document.getElementById('lblErrorMsg').innerHTML;  return  data");
            string msg = data.ToString().Trim();

            //Here Removining Some Extra thing
            msg = msg.Replace("*", "");
            msg = msg.Replace("<br>", "");
            msg = msg.Replace(" ", "");

            string resMsg = resMsg = cuslanguage.Msg_EnterShipToNumber + cuslanguage.Msg_EnterCustomerName;
            resMsg = resMsg.Replace(" ", "");
            if (msg != resMsg)
            {
                string screenShotName = "NegativeTestCaseIs_Fail";
                screenShot(screenShotName);
            }
            Assert.AreEqual(resMsg, msg, msg);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(max);
            try
            {
                Click<HtmlCustom>(PropertyType.Id, "ContentPlaceHolder1_btnClear");
            }
            catch (Exception e) { }
        }

        public bool Search()
        {
            BrowserWindow window = new BrowserWindow();
            Thread.Sleep(600);
            var data1 = window.ExecuteScript("var data=document.getElementById('ContentPlaceHolder1_tblCustomerInstructionList').getElementsByTagName('span')[0];  return  data.innerHTML");
            string msg1 = data1.ToString().Trim();
            bool b1 = msg1.Equals(cuslanguage.Msg_NoRecordsFound);
            return b1;
        }
        public void SentEmail()
        {
            string smtpAddress = "smtp-relay.gmail.com";
            int portNumber = 587;
            bool enableSSL = true;
            string emailFrom = "ab366665@gmail.com";
            string password = "Ajay14326";

            string emailTo = "ajaykumar@aureoleinc.com";
            string subject = "Hello";
            string tbody = "Hello, I'm just writing this to say Hi!";

            MailMessage msg = new MailMessage(emailFrom, emailTo, subject, tbody);
            msg.IsBodyHtml = true;
            SmtpClient sc = new SmtpClient("smtp.gmail.com", 587);
            sc.UseDefaultCredentials = false;
            NetworkCredential cre = new NetworkCredential(emailFrom, password);
            sc.Credentials = cre;
            sc.EnableSsl = true;
            sc.Send(msg);
        }
        public void screenShot(string imgName)
        {
            BrowserWindow window = new BrowserWindow();
            string path = ConfigurationSettings.AppSettings["ScreenShot"];
            path = path + @"\\iPAS_CustomerInstruction";
            Directory.CreateDirectory(path);
            try
            {
                window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
                Image image = window.CaptureImage();
                image.Save(path + "\\" + imgName + ".jpeg", ImageFormat.Jpeg);
                image.Dispose();
            }
            catch (Exception e) { }
            Console.WriteLine("Screen Shot is Avaliable in " + path + "\t" + "Folder");
        }
        public void WindowButtonClick<T>(PropertyType type, string propertyvalue) where T : WinControl
        {
            WinControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Name)
                genericControl.SearchProperties[WinControl.PropertyNames.Name] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void PathEnterText<T>(PropertyType type, string propertyvalue, string text) where T : WinEdit
        {
            WinEdit genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            genericControl.FilterProperties[WinEdit.PropertyNames.Name] = propertyvalue;
            AutoItX3 auto = new AutoItX3();
            auto.WinActivate("Choose File to Upload");
            auto.Send(text);
            auto.Send("{ENTER}");
            Thread.Sleep(1000);
        }
        public void Click<T>(PropertyType type, string propertyvalue) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });

            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;
            else if (type == PropertyType.InnerText)
            {
                genericControl.SearchProperties[HtmlControl.PropertyNames.InnerText] = propertyvalue;
            }
            else if (type == PropertyType.TagInstance)
                genericControl.FilterProperties[HtmlControl.PropertyNames.TagInstance] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void EnterText<T>(PropertyType type, string propertyvalue, string text) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;

            Keyboard.SendKeys(genericControl, text);

        }
        private BrowserWindow mparentwindow { get; set; }
        public enum PropertyType
        {
            Id,
            Name,
            InnerText,
            TagInstance
        }
        public BrowserWindow TopParentWindow()
        {

            BrowserWindow window = new BrowserWindow();
            window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
            return window;
        }
        public BrowserWindow ParentWindow
        {
            get
            {
                if (this.mparentwindow == null)
                {
                    this.mparentwindow = TopParentWindow();
                }
                return this.mparentwindow;
            }
        }
    }
}
