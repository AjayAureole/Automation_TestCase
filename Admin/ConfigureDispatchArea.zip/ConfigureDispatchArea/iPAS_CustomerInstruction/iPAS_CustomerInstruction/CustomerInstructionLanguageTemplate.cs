﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Text;
using System.Threading.Tasks;

namespace iPAS_CustomerInstruction
{
    class CustomerInstructionLanguageTemplate
    {
        static CultureInfo ci = null;
        static ResourceManager rm = null;
        static string resMsg_ShipNumberAddedSuccessfully = string.Empty;
        public string Msg_ShipNumberAddedSuccessfully
        {
            get { return resMsg_ShipNumberAddedSuccessfully; }
            set { resMsg_ShipNumberAddedSuccessfully = value; }
        }

        static string resMsg_ShipToNumberUpdatedSuccessfully = string.Empty;
        public string Msg_ShipToNumberUpdatedSuccessfully
        {
            get { return resMsg_ShipToNumberUpdatedSuccessfully; }
            set { resMsg_ShipToNumberUpdatedSuccessfully = value; }
        }

        static string resMsg_EnterShipToNumber = string.Empty;
        public string Msg_EnterShipToNumber
        {
            get { return resMsg_EnterShipToNumber; }
            set { resMsg_EnterShipToNumber = value; }
        }
        static string resMsg_EnterCustomerName = string.Empty;
        public string Msg_EnterCustomerName
        {
            get { return resMsg_EnterCustomerName; }
            set { resMsg_EnterCustomerName = value; }
        }
        static string resMsg_NoRecordsFound = string.Empty;
        public string Msg_NoRecordsFound
        {
            get { return resMsg_NoRecordsFound; }
            set { resMsg_NoRecordsFound = value; }
        }

        public static void messageResource(string languageCode)
        {
            if (languageCode == "zh-CN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_CustomerInstruction.resource.CustomerInstructionCN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_CustomerInstruction.resource.CustomerInstructionEN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
        }
        public static void messageInitialize()
        {
            resMsg_ShipNumberAddedSuccessfully = rm.GetString("resMsg_ShipNumberAddedSuccessfully", ci).Trim();
            resMsg_ShipToNumberUpdatedSuccessfully = rm.GetString("resMsg_ShipToNumberUpdatedSuccessfully", ci).Trim();
            resMsg_EnterShipToNumber = rm.GetString("resMsg_EnterShipToNumber", ci).Trim();
            resMsg_EnterCustomerName = rm.GetString("resMsg_EnterCustomerName", ci).Trim();
            resMsg_NoRecordsFound = rm.GetString("resMsg_NoRecordsFound", ci).Trim();

        }
    }
}
