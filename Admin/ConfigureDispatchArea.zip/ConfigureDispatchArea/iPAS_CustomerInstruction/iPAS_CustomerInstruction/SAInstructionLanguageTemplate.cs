﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Text;
using System.Threading.Tasks;

namespace iPAS_CustomerInstruction
{
    class SAInstructionLanguageTemplate
    {
        static CultureInfo ci = null;
        static ResourceManager rm = null;
        static string resMsg_SoldToAccountAddedSuccessfully = string.Empty;
        public string Msg_SoldToAccountAddedSuccessfully
        {
            get { return resMsg_SoldToAccountAddedSuccessfully; }
            set { resMsg_SoldToAccountAddedSuccessfully = value; }
        }

        static string resMsg_SoldToAccountUpdatedSuccessfully = string.Empty;
        public string Msg_SoldToAccountUpdatedSuccessfully
        {
            get { return resMsg_SoldToAccountUpdatedSuccessfully; }
            set { resMsg_SoldToAccountUpdatedSuccessfully = value; }
        }

        static string resMsg_EnterSoldToAccount = string.Empty;
        public string Msg_EnterSoldToAccount
        {
            get { return resMsg_EnterSoldToAccount; }
            set { resMsg_EnterSoldToAccount = value; }
        }
        static string resMsg_EnterCustomerName = string.Empty;
        public string Msg_EnterCustomerName
        {
            get { return resMsg_EnterCustomerName; }
            set { resMsg_EnterCustomerName = value; }
        }
        static string resMsg_NoRecordsFound = string.Empty;
        public string Msg_NoRecordsFound
        {
            get { return resMsg_NoRecordsFound; }
            set { resMsg_NoRecordsFound = value; }
        }

        static string resMsg_InvalidFormat = string.Empty;
        public string Msg_InvalidFormat
        {
            get { return resMsg_InvalidFormat; }
            set { resMsg_InvalidFormat = value; }
        }

        public static void messageResource(string languageCode)
        {
            if (languageCode == "zh-CN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_CustomerInstruction.resource.SAInstructionCN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_CustomerInstruction.resource.SAInstructionEN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
        }
        public static void messageInitialize()
        {
            resMsg_SoldToAccountAddedSuccessfully = rm.GetString("resMsg_SoldToAccountAddedSuccessfully", ci).Trim();
            resMsg_SoldToAccountUpdatedSuccessfully = rm.GetString("resMsg_SoldToAccountUpdatedSuccessfully", ci).Trim();
            resMsg_EnterSoldToAccount = rm.GetString("resMsg_EnterSoldToAccount", ci).Trim();
            resMsg_EnterCustomerName = rm.GetString("resMsg_EnterCustomerName", ci).Trim();
            resMsg_NoRecordsFound = rm.GetString("resMsg_NoRecordsFound", ci).Trim();
            resMsg_InvalidFormat = rm.GetString("resMsg_InvalidFormat", ci).Trim();


        }
    }
}
