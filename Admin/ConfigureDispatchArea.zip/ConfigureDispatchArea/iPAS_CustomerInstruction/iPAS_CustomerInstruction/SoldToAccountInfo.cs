﻿using AutoItX3Lib;
using DataDrivenTesting;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace iPAS_CustomerInstruction
{
    class SoldToAccountInfo
    {
        string minsleep = ConfigurationSettings.AppSettings["min"];
        string midsleep = ConfigurationSettings.AppSettings["mid"];
        string maxsleep = ConfigurationSettings.AppSettings["max"];
        SAInstructionLanguageTemplate soldLanguage = new SAInstructionLanguageTemplate();
        public void AddNewSoldToAccount()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);            
            try
            {
                Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_btnSAInstruction");
                Thread.Sleep(max);
            }catch(Exception e) { }
            auto.Send("{F5}");
            Thread.Sleep(max);
            var totalbefore = window.ExecuteScript("var data=document.getElementById('spnTotalRecords').innerHTML;  return  data");
            string tot = totalbefore.ToString().Trim();
            int totalbeforerecord = Convert.ToInt32(totalbefore);
            Thread.Sleep(max);
            try {
                EnterText<HtmlEdit>(PropertyType.Id, "txtSoldToAccount", ExcelDataTable.ReadData(1, "Sold To Account1"));
            } catch(Exception e) { }
            try {
                EnterText<HtmlEdit>(PropertyType.Id, "txtDispatchCustName", ExcelDataTable.ReadData(1, "Customer Name1"));
            }
            catch (Exception e) { }
            try {
                EnterText<HtmlTextArea>(PropertyType.Id, "txtShippingInst", ExcelDataTable.ReadData(1, "Shipping Instruction1"));
            }
            catch (Exception e) { }
            Thread.Sleep(mid);
            Click<HtmlCustom>(PropertyType.Id, "ContentPlaceHolder1_btnAddCustomer");
            Thread.Sleep(max);
            var afterTotal = window.ExecuteScript("var data=document.getElementById('spnTotalRecords').innerHTML;  return  data");
            string afterTot = afterTotal.ToString().Trim();
            int afterTotalRecords = Convert.ToInt32(afterTot);
            totalbeforerecord = totalbeforerecord + 1;
            Thread.Sleep(min);
            if (afterTotalRecords != totalbeforerecord)
            {
                string screenShotName = "afterTotalRecords_NotProper";
                screenShot(screenShotName);
            }
            Thread.Sleep(min);
            Assert.AreEqual(afterTotalRecords, totalbeforerecord, "Total Record value is Not Proper");
            Thread.Sleep(max);
            var data = window.ExecuteScript("var data=document.getElementById('lblErrorMsg').innerHTML;  return  data");
            string msg = data.ToString().Trim();
            Thread.Sleep(min);
            if (msg != soldLanguage.Msg_SoldToAccountAddedSuccessfully)
            {
                string screenShotName = "accountadded_NotSuccessfully";
                screenShot(screenShotName);
            }
            Assert.AreEqual(soldLanguage.Msg_SoldToAccountAddedSuccessfully, msg, msg);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void update()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);
            try
            {
                Click<HtmlDiv>(PropertyType.Id, "divRecords");
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpSearch");
                EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpSearch", "Sold To Account");
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtSearch", ExcelDataTable.ReadData(1, "Sold To Account1"));
            }
            catch (Exception e) { }
            Thread.Sleep(min);
            Click<HtmlCustom>(PropertyType.Id, "ContentPlaceHolder1_btnGo");
            Thread.Sleep(mid);
            /*************************Clicking on the Data***************************/
            Click<HtmlDiv>(PropertyType.Id, "ucSoldToAccountInstructionSummary_0_divSoldToAccount");
            int Mx2 = auto.MouseGetPosX();
            int My2 = auto.MouseGetPosY();
            Mx2 = Mx2 - 140;
            Thread.Sleep(max);
            auto.MouseMove(Mx2, My2);
            auto.MouseClick();
            Thread.Sleep(max);

            /***********************Updating the Data************************************/
           
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "txtDispatchCustName");
                auto.Send("{BACKSPACE 30}");//Existing Data Deletion
                auto.Send("{DEL 30}");
                EnterText<HtmlEdit>(PropertyType.Id, "txtDispatchCustName", ExcelDataTable.ReadData(1, "UpCustomer Name1"));
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlTextArea>(PropertyType.Id, "txtShippingInst");
                auto.Send("{BACKSPACE 30}");//Existing Data Deletion
                auto.Send("{DEL 30}");
                EnterText<HtmlTextArea>(PropertyType.Id, "txtShippingInst", ExcelDataTable.ReadData(1, "UpShipping Instruction1"));
            }
            catch (Exception e) { }
            Thread.Sleep(mid);
            Click<HtmlCustom>(PropertyType.Id, "ContentPlaceHolder1_btnUpdateCustomer");
            Thread.Sleep(mid);
            var data = window.ExecuteScript("var data=document.getElementById('lblErrorMsg').innerHTML;  return  data");
            string msg = data.ToString().Trim();
            Thread.Sleep(min);
            if (msg != soldLanguage.Msg_SoldToAccountUpdatedSuccessfully)
            {
                string screenShotName = "accountUpdated_NotSuccessfully";
                screenShot(screenShotName);
            }
            Assert.AreEqual(soldLanguage.Msg_SoldToAccountUpdatedSuccessfully, msg, msg);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void delete()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);
            try
            {
                Click<HtmlDiv>(PropertyType.Id, "divRecords");
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpSearch");
                EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpSearch", "Sold To Account");
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtSearch", ExcelDataTable.ReadData(1, "Sold To Account1"));
            }
            catch (Exception e) { }
            Thread.Sleep(min);
            Click<HtmlCustom>(PropertyType.Id, "ContentPlaceHolder1_btnGo");
            Thread.Sleep(mid);
            /*************************Clicking on the Data***************************/
            Click<HtmlDiv>(PropertyType.Id, "ucSoldToAccountInstructionSummary_0_divSoldToAccount");
            int Mx2 = auto.MouseGetPosX();
            int My2 = auto.MouseGetPosY();
            Mx2 = Mx2 - 118;
            Thread.Sleep(max);
            auto.MouseMove(Mx2, My2);
            auto.MouseClick();
            Thread.Sleep(min);
            auto.Send("{ENTER}");
            Thread.Sleep(mid);
            try {
                Click<HtmlCustom>(PropertyType.Id, "ContentPlaceHolder1_btnShowAll");
            } catch(Exception e) { }
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }        
        public void downloadTemplate()
        {

            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);                
            auto.Send("{F5}");
            Thread.Sleep(max);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_downLoadTemplateLink");
            Thread.Sleep(max * 4);
            Click<HtmlDiv>(PropertyType.Id, "footer");
            bool open=false;
            try
            {
                WindowButtonClick<WinToolBar>(PropertyType.Name, "Notification");            
                WindowButtonClick<WinButton>(PropertyType.Name, "Open");
                mparentwindow = null;
                Thread.Sleep(max * 10);
                open = true;
                auto.WinClose("Microsoft Excel");
                auto.WinClose("Excel");
            }catch (Exception e) {
                if (!open)
                {
                    screenShot("OPENButtonProblem");
                    Assert.IsTrue(open, "Not Able to Click Open Button");
                }
            }
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void uploadingExcel()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);
            Click<HtmlCustom>(PropertyType.Id, "btnUploadSAInfo");
            Thread.Sleep(mid);
            Click<HtmlFileInput>(PropertyType.Id, "ContentPlaceHolder1_uploadFile");
            Thread.Sleep(min);
            try
            {
                PathEnterText<WinEdit>(PropertyType.Name, "File name:", ExcelDataTable.ReadData(1, "filePath"));
                Thread.Sleep(mid);
            }
            catch (Exception e) { }
            Thread.Sleep(max * 5);
            /**********Here Validate image uploading Valid or Not*****************/
            var data2 = window.ExecuteScript("var data=document.getElementById('lblUploadError').innerHTML;  return  data");
            string successMsg2 = data2.ToString().Trim();
            if ("" != successMsg2)
            {
                string screenShotName = "NotUploaded";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", successMsg2, successMsg2);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void deleteUploaded()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);
            try
            {
                Click<HtmlDiv>(PropertyType.Id, "divRecords");
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpSearch");
                EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpSearch", "Sold To Account");
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtSearch", ExcelDataTable.ReadData(1, "uploadingSold To Account"));
            }
            catch (Exception e) { }
            Thread.Sleep(min);
            Click<HtmlCustom>(PropertyType.Id, "ContentPlaceHolder1_btnGo");
            Thread.Sleep(mid);

            /*******************Validate Search Criteria*************/
            var data1 = window.ExecuteScript("var data=document.getElementById('lblSearchMsg').innerHTML;  return  data");
            string msg1 = data1.ToString().Trim();
            if (msg1!="")
            {
                string screenShotName = "Search_Criteria";
                screenShot(screenShotName);
            }
            Assert.AreEqual("",msg1,msg1);
            
            /*************************Clicking on the Data***************************/
            Click<HtmlDiv>(PropertyType.Id, "ucSoldToAccountInstructionSummary_0_divSoldToAccount");
            int Mx2 = auto.MouseGetPosX();
            int My2 = auto.MouseGetPosY();
            Mx2 = Mx2 - 118;
            Thread.Sleep(max);
            auto.MouseMove(Mx2, My2);
            auto.MouseClick();
            Thread.Sleep(min);
            auto.Send("{ENTER}");
            Thread.Sleep(mid);           
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void findData()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);
            try
            {
                Click<HtmlDiv>(PropertyType.Id, "divRecords");
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpSearch");
                EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpSearch", "Sold To Account");
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtSearch", ExcelDataTable.ReadData(1, "uploadingSold To Account"));
            }
            catch (Exception e) { }
            Thread.Sleep(min);
            Click<HtmlCustom>(PropertyType.Id, "ContentPlaceHolder1_btnGo");
            Thread.Sleep(max);
            bool b1 = Search();
            if (!b1)
            {
                string screenShotName = "Data_IsNotDeleted";
                screenShot(screenShotName);
            }
            Assert.IsTrue(b1, "Data is Not Deleted");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void AddButtonClick()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(max);
            auto.Send("{F5}");
            Thread.Sleep(max);
            /**************Without Enter  any Data Click on the Add Button*********/

            Click<HtmlCustom>(PropertyType.Id, "ContentPlaceHolder1_btnAddCustomer");
            Thread.Sleep(max);
            var data = window.ExecuteScript("var data=document.getElementById('lblErrorMsg').innerHTML;  return  data");
            string msg = data.ToString().Trim();

            //Here Removining Some Extra thing
            msg = msg.Replace("*", "");
            msg = msg.Replace("<br>", "");
            msg = msg.Replace(" ", "");

            string resMsg = soldLanguage.Msg_EnterSoldToAccount + soldLanguage.Msg_EnterCustomerName;
            resMsg = resMsg.Replace(" ", "");
            if (msg != resMsg)
            {
                string screenShotName = "NegativeTestCaseIs_Fail";
                screenShot(screenShotName);
            }
            Assert.AreEqual(resMsg, msg, msg);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(max);
            try
            {
                Click<HtmlCustom>(PropertyType.Id, "ContentPlaceHolder1_btnClear");
            }catch(Exception e) { }
        }
        public void NegativeValidation()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);
            Click<HtmlCustom>(PropertyType.Id, "btnUploadSAInfo");
            Thread.Sleep(mid);
            Click<HtmlFileInput>(PropertyType.Id, "ContentPlaceHolder1_uploadFile");
            Thread.Sleep(min);
            try
            {
                PathEnterText<WinEdit>(PropertyType.Name, "File name:", ExcelDataTable.ReadData(1, "filePathTxT"));
                Thread.Sleep(mid);
            }
            catch (Exception e) { }
            Thread.Sleep(max * 5);
            /**********Here Validate image uploading Valid or Not*****************/
            var data2 = window.ExecuteScript("var data=document.getElementById('lblUploadError').innerHTML;  return  data");
            string successMsg2 = data2.ToString().Trim();
            if (soldLanguage.Msg_InvalidFormat != successMsg2)
            {
                string screenShotName = "FileIs_NotProper";
                screenShot(screenShotName);
            }
            Assert.AreEqual(soldLanguage.Msg_InvalidFormat, successMsg2, successMsg2);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public bool Search()
        {
            BrowserWindow window = new BrowserWindow();
            Thread.Sleep(800);
            var data1 = window.ExecuteScript("var data=document.getElementById('ContentPlaceHolder1_tblSoldToAccountInstructionList').getElementsByTagName('span')[0];  return  data.innerHTML");
            string msg1 = data1.ToString().Trim();
            bool b1 = msg1.Equals(soldLanguage.Msg_NoRecordsFound);
            return b1;
        }
        public void screenShot(string imgName)
        {
            BrowserWindow window = new BrowserWindow();
            string path = ConfigurationSettings.AppSettings["ScreenShot"];
            path = path + @"\\iPAS_CustomerInstruction";
            Directory.CreateDirectory(path);
            try
            {
                window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
                Image image = window.CaptureImage();
                image.Save(path + "\\" + imgName + ".jpeg", ImageFormat.Jpeg);
                image.Dispose();
            }
            catch (Exception e) { }
            Console.WriteLine("Screen Shot is Avaliable in " + path + "\t" + "Folder");
        }
        public void WindowButtonClick<T>(PropertyType type, string propertyvalue) where T : WinControl
        {
            WinControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Name)
                genericControl.SearchProperties[WinControl.PropertyNames.Name] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void PathEnterText<T>(PropertyType type, string propertyvalue, string text) where T : WinEdit
        {
            WinEdit genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            genericControl.FilterProperties[WinEdit.PropertyNames.Name] = propertyvalue;
            AutoItX3 auto = new AutoItX3();
            auto.WinActivate("Choose File to Upload");
            auto.Send(text);
            auto.Send("{ENTER}");
            Thread.Sleep(1000);
        }
        public void Click<T>(PropertyType type, string propertyvalue) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });

            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;
            else if (type == PropertyType.InnerText)
            {
                genericControl.SearchProperties[HtmlControl.PropertyNames.InnerText] = propertyvalue;
            }
            else if (type == PropertyType.TagInstance)
                genericControl.FilterProperties[HtmlControl.PropertyNames.TagInstance] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void EnterText<T>(PropertyType type, string propertyvalue, string text) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;

            Keyboard.SendKeys(genericControl, text);

        }
        private BrowserWindow mparentwindow { get; set; }
        public enum PropertyType
        {
            Id,
            Name,
            InnerText,
            TagInstance
        }
        public BrowserWindow TopParentWindow()
        {

            BrowserWindow window = new BrowserWindow();
            window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
            return window;
        }
        public BrowserWindow ParentWindow
        {
            get
            {
                if (this.mparentwindow == null)
                {
                    this.mparentwindow = TopParentWindow();
                }
                return this.mparentwindow;
            }
        }
    }
}
