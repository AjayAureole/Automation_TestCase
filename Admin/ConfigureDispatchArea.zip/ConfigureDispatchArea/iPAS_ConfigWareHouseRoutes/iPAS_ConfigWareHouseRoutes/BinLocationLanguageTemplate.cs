﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Text;
using System.Threading.Tasks;

namespace iPAS_ConfigWareHouseRoutes
{
    class BinLocationLanguageTemplate
    {
        static CultureInfo ci = null;
        static ResourceManager rm = null;
        static string resMsg_SelectSectionName = string.Empty;
        public string Msg_SelectSectionName
        {
            get { return resMsg_SelectSectionName; }
            set { resMsg_SelectSectionName = value; }
        }

        static string resMsg_EnterLevel = string.Empty;
        public string Msg_EnterLevel
        {
            get { return resMsg_EnterLevel; }
            set { resMsg_EnterLevel = value; }
        }

        static string resMsg_EnterRackFrom = string.Empty;
        public string Msg_EnterRackFrom
        {
            get { return resMsg_EnterRackFrom; }
            set { resMsg_EnterRackFrom = value; }
        }
        static string resMsg_EnterRackTo = string.Empty;
        public string Msg_EnterRackTo
        {
            get { return resMsg_EnterRackTo; }
            set { resMsg_EnterRackTo = value; }
        }
        static string noSectionsAreAdded = string.Empty;
        public string SectionsAreAdded
        {
            get { return noSectionsAreAdded; }
            set { noSectionsAreAdded = value; }
        }

        public static void messageResource(string languageCode)
        {
            if (languageCode == "zh-CN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ConfigWareHouseRoutes.resource.BinLocationCN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ConfigWareHouseRoutes.resource.BinLocationEN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
        }
        public static void messageInitialize()
        {
            resMsg_SelectSectionName = rm.GetString("resMsg_SelectSectionName", ci).Trim();
            resMsg_EnterLevel = rm.GetString("resMsg_EnterLevel", ci).Trim();
            resMsg_EnterRackFrom = rm.GetString("resMsg_EnterRackFrom", ci).Trim();
            resMsg_EnterRackTo = rm.GetString("resMsg_EnterRackTo", ci).Trim();
            noSectionsAreAdded = rm.GetString("noSectionsAreAdded", ci).Trim();
        }
    }
}
