﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Text;
using System.Threading.Tasks;

namespace iPAS_ConfigWareHouseRoutes
{
    class WarehouseRouteLanguageTemplate
    {
        static CultureInfo ci = null;
        static ResourceManager rm = null;
        static string resMsg_EnterSectionName = string.Empty;
        public string Msg_EnterSectionName
        {
            get { return resMsg_EnterSectionName; }
            set { resMsg_EnterSectionName = value; }
        }     

        public static void messageResource(string languageCode)
        {
            if (languageCode == "zh-CN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ConfigWareHouseRoutes.resource.WarehouseRouteCN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ConfigWareHouseRoutes.resource.WarehouseRouteEN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
        }
        public static void messageInitialize()
        {
            resMsg_EnterSectionName = rm.GetString("resMsg_EnterSectionName", ci).Trim();           
        }
    }
}
