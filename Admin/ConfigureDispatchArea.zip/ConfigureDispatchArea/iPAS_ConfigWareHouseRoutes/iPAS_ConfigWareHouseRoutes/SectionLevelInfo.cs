﻿using AutoItX3Lib;
using DataDrivenTesting;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace iPAS_ConfigWareHouseRoutes
{
    class SectionLevelInfo
    {
        string minsleep = ConfigurationSettings.AppSettings["min"];
        string midsleep = ConfigurationSettings.AppSettings["mid"];
        string maxsleep = ConfigurationSettings.AppSettings["max"];
        BinLocationLanguageTemplate binLocation = new BinLocationLanguageTemplate();

        public void addNewLevel()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkSectionLevel");
            Thread.Sleep(min);
            auto.MouseClick();
            Thread.Sleep(max);
            auto.Send("{F5}");
            Thread.Sleep(max);
            ////////////////////Validate Section Name Combobox///////////////////////////

            string sectionName = ExcelDataTable.ReadData(1, "Section Name");
            sectionName = sectionName.ToUpper();
            Thread.Sleep(max * 3);

            var list = window.ExecuteScript("var list=document.getElementById('ContentPlaceHolder1_drpSecName'); var i; var isBool=false; var sec='" + sectionName + "';for (i = 0; i < list.options.length; i++){ var data=list.options[i].text;var data1=sec; if(data==data1){ isBool=true; break; } } return  isBool;");
            Thread.Sleep(max);

            if (list.ToString().Trim().ToUpper() != "TRUE")
            {
                string screenShotName = "SelectionNameIs_NotThere";
                screenShot(screenShotName);
            }
            if (list.ToString().Trim().ToUpper() != "TRUE")
                Assert.IsTrue(false,"Selection Name is Not There");

            try
            {
                Click<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpSecName");
                Thread.Sleep(min);
                EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpSecName", ExcelDataTable.ReadData(1, "Section Name"));
            } catch(Exception e) { }
            try
            {               
                EnterText<HtmlEdit>(PropertyType.Id, "txtLevels", ExcelDataTable.ReadData(1, "Level"));
            }
            catch (Exception e) { }            
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtRackFrom", ExcelDataTable.ReadData(1, "Rack From"));
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtRackTo", ExcelDataTable.ReadData(1, "Rack To"));
            }
            catch (Exception e) { }
            Thread.Sleep(min);
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnAddSectionLevel");
            Thread.Sleep(max*3);
            var data = window.ExecuteScript("var data=document.getElementById('spnError').innerHTML;  return  data");
            string msg = data.ToString().Trim();
            if (msg != "")
            {
                string screenShotName = "Level_IsNotAdded";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", msg, msg);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void update()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);           
            try
            {
                Click<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpSectionNameForLevel");
                Thread.Sleep(mid);
                EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpSectionNameForLevel", ExcelDataTable.ReadData(1, "Section Name"));
            }catch (Exception e) { }
            Thread.Sleep(max*2);
            Click<HtmlInputButton>(PropertyType.Id, "ctl00_ContentPlaceHolder1_rlSectionLevel__rli0_btnEdit");
            Thread.Sleep(max*2);

            /************************Start the Updaitng****************************/
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "txtLevels");
                auto.Send("{BACKSPACE 30}");//Existing Data Deletion
                auto.Send("{DEL 30}");
                EnterText<HtmlEdit>(PropertyType.Id, "txtLevels", ExcelDataTable.ReadData(1, "UpdateLevel"));
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "txtRackFrom");
                auto.Send("{BACKSPACE 30}");//Existing Data Deletion
                auto.Send("{DEL 30}");
                EnterText<HtmlEdit>(PropertyType.Id, "txtRackFrom", ExcelDataTable.ReadData(1, "UpdateRack From"));
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "txtRackTo");
                auto.Send("{BACKSPACE 30}");//Existing Data Deletion
                auto.Send("{DEL 30}");
                EnterText<HtmlEdit>(PropertyType.Id, "txtRackTo", ExcelDataTable.ReadData(1, "UpdateRack To"));
            }
            catch (Exception e) { }
            Thread.Sleep(min);
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnUpdateSectionLevel");
            Thread.Sleep(max*3);
            var data = window.ExecuteScript("var data=document.getElementById('spnError').innerHTML;  return  data");
            string msg = data.ToString().Trim();
            if (msg != "")
            {
                string screenShotName = "Level_IsNotUpdated";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", msg, msg);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);

        }
        public void delete()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);
            try
            {
                //Click<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpSectionNameForLevel");
                //Thread.Sleep(min);
                EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpSectionNameForLevel", ExcelDataTable.ReadData(1, "Section Name"));
            }
            catch (Exception e) { }
            Thread.Sleep(max*3);
            Click<HtmlInputButton>(PropertyType.Id, "ctl00_ContentPlaceHolder1_rlSectionLevel__rli0_btnDelete");
            Thread.Sleep(mid);
            auto.Send("{ENTER}");
            Thread.Sleep(max*2);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void findData()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);
            try
            {              
                EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpSectionNameForLevel", ExcelDataTable.ReadData(1, "Section Name"));
            }
            catch (Exception e) { }
            Thread.Sleep(max);
            bool b1 = Search();
            if (!b1)
            {
                string screenShotName = "SelectionLevelIs_NotDeleted";
                screenShot(screenShotName);
            }
            Assert.IsTrue(b1,"Selection Level is Not Deleted");
        }
        public void AddButtonClick()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            //Thread.Sleep(mid);
            //auto.Send("{F5}");
            //Thread.Sleep(max);       

            /**************Without Enter  any Data Click on the Add Button*********/
            
            try
            {
                EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpSecName", "Please Select");
            }
            catch (Exception e) { }
            Thread.Sleep(max);
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnAddSectionLevel");
            Thread.Sleep(max);
            var data = window.ExecuteScript("var data=document.getElementById('spnError').innerHTML;  return  data");
            string msg = data.ToString().Trim();

            //Here Removining Some Extra thing
            msg = msg.Replace("*", "");
            msg = msg.Replace("<br>", "");
            msg = msg.Replace(" ", "");

            string resMsg = binLocation.Msg_SelectSectionName + binLocation.Msg_EnterLevel + binLocation.Msg_EnterRackFrom + binLocation.Msg_EnterRackTo;
            resMsg = resMsg.Replace(" ", "");
            if (msg != resMsg)
            {
                string screenShotName = "NegativeTestCaseIs_Fail";
                screenShot(screenShotName);
            }
            Assert.AreEqual(resMsg, msg, msg);
            //Thread.Sleep(min);
            //auto.Send("{F5}");
            //Thread.Sleep(max);
            try
            {
                Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnCancel");
            }
            catch (Exception e) { }
            //Thread.Sleep(mid);
            //auto.Send("{F5}");
            //Thread.Sleep(max);
        }
        public bool Search()
        {
            BrowserWindow window = new BrowserWindow();
            Thread.Sleep(600);
            var data1 = window.ExecuteScript("var data=document.getElementById('ctl00_ContentPlaceHolder1_rlSectionLevel').getElementsByTagName('span')[0];  return  data.innerHTML");
            string msg1 = data1.ToString().Trim();
            bool b1 = msg1.Equals(binLocation.SectionsAreAdded);
            return b1;
        }

        public void screenShot(string imgName)
        {
            BrowserWindow window = new BrowserWindow();
            string path = ConfigurationSettings.AppSettings["ScreenShot"];
            path = path + @"\\iPAS_ConfigWareHouseRoutes";
            Directory.CreateDirectory(path);
            try
            {
                window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
                Image image = window.CaptureImage();
                image.Save(path + "\\" + imgName + ".jpeg", ImageFormat.Jpeg);
                image.Dispose();
            }
            catch (Exception e) { }
            Console.WriteLine("Screen Shot is Avaliable in " + path + "\t" + "Folder");
        }
        public void WindowButtonClick<T>(PropertyType type, string propertyvalue) where T : WinControl
        {
            WinControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Name)
                genericControl.SearchProperties[WinControl.PropertyNames.Name] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void PathEnterText<T>(PropertyType type, string propertyvalue, string text) where T : WinEdit
        {
            WinEdit genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            genericControl.FilterProperties[WinEdit.PropertyNames.Name] = propertyvalue;
            AutoItX3 auto = new AutoItX3();
            auto.WinActivate("Choose File to Upload");
            auto.Send(text);
            auto.Send("{ENTER}");
            Thread.Sleep(1000);
        }
        public void Click<T>(PropertyType type, string propertyvalue) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });

            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;
            else if (type == PropertyType.InnerText)
            {
                genericControl.SearchProperties[HtmlControl.PropertyNames.InnerText] = propertyvalue;
            }
            else if (type == PropertyType.TagInstance)
                genericControl.FilterProperties[HtmlControl.PropertyNames.TagInstance] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void EnterText<T>(PropertyType type, string propertyvalue, string text) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;

            Keyboard.SendKeys(genericControl, text);

        }
        private BrowserWindow mparentwindow { get; set; }
        public enum PropertyType
        {
            Id,
            Name,
            InnerText,
            TagInstance
        }
        public BrowserWindow TopParentWindow()
        {

            BrowserWindow window = new BrowserWindow();
            window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
            return window;
        }
        public BrowserWindow ParentWindow
        {
            get
            {
                if (this.mparentwindow == null)
                {
                    this.mparentwindow = TopParentWindow();
                }
                return this.mparentwindow;
            }
        }
    }
}
