﻿using AutoItX3Lib;
using DataDrivenTesting;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace iPAS_ConfigWareHouseRoutes
{
    class AddSectionName
    {
        string minsleep = ConfigurationSettings.AppSettings["min"];
        string midsleep = ConfigurationSettings.AppSettings["mid"];
        string maxsleep = ConfigurationSettings.AppSettings["max"];
        WarehouseRouteLanguageTemplate warehouseLanguage = new WarehouseRouteLanguageTemplate(); 
        public void addNewSectionName()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(min);
            Click<HtmlHyperlink>(PropertyType.Id, "lnkAdmin");
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(max);
            Click<HtmlDiv>(PropertyType.Id, "footer");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkDispatch");
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(max);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkWareHouseRoute");
            Thread.Sleep(min);
            auto.MouseClick();
            Thread.Sleep(max);
            auto.Send("{F5}");
            Thread.Sleep(max);
            try {
                EnterText<HtmlEdit>(PropertyType.Id,"txtSectionName", ExcelDataTable.ReadData(1, "Section Name"));

            } catch(Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtSectionDescription", ExcelDataTable.ReadData(1, "Description"));
            }
            catch (Exception e) { }
            Thread.Sleep(min);
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnAddWareHouse");
            Thread.Sleep(mid);
            var data = window.ExecuteScript("var data=document.getElementById('spnError').innerHTML;  return  data");
            string msg = data.ToString().Trim();
            if (msg!="")
            {
                string screenShotName = "Selection_NotAdd";
                screenShot(screenShotName);
            }
            Assert.AreEqual("",msg,msg);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void delete()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);

            /*************************Clicking on the Data***************************/
            try
            {
                Click<HtmlSpan>(PropertyType.InnerText, ExcelDataTable.ReadData(1, "Section Name"));
            }
            catch (Exception e) { }
            int Mx2 = auto.MouseGetPosX();
            int My2 = auto.MouseGetPosY();
            Mx2 = Mx2 + 440;
            Thread.Sleep(max);
            auto.MouseMove(Mx2, My2);
            auto.MouseClick();
            Thread.Sleep(min);
            auto.Send("{ENTER}");
            Thread.Sleep(mid);           
           }
        public void AddButtonClick()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            //Thread.Sleep(mid);
            //auto.Send("{F5}");
            Thread.Sleep(max);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkSectionName");
            Thread.Sleep(min);
            auto.MouseClick();
            Thread.Sleep(max);
            auto.Send("{F5}");
            Thread.Sleep(max);
            /**************Without Enter  any Data Click on the Add Button*********/

            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnAddWareHouse");
            Thread.Sleep(max);
            var data = window.ExecuteScript("var data=document.getElementById('spnError').innerHTML;  return  data");
            string msg = data.ToString().Trim();

            //Here Removining Some Extra thing
            msg = msg.Replace("*", "");
            msg = msg.Replace("<br>", "");
            msg = msg.Replace(" ", "");

            string resMsg = resMsg = warehouseLanguage.Msg_EnterSectionName;            
            resMsg = resMsg.Replace(" ", "");
            if (msg != resMsg)
            {
                string screenShotName = "NegativeTestCaseIs_Fail";
                screenShot(screenShotName);
            }
            Assert.AreEqual(resMsg, msg, msg);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(max);
            try
            {
                Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnCancel");
            }
            catch (Exception e) { }
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);
        }
        public bool Search()
        {
            BrowserWindow window = new BrowserWindow();
            Thread.Sleep(600);
            var data1 = window.ExecuteScript("var data=document.getElementById('ContentPlaceHolder1_tblCustomerInstructionList').getElementsByTagName('span')[0];  return  data.innerHTML");
            string msg1 = data1.ToString().Trim();
            bool b1 = msg1.Equals("");
            return b1;
        }
        //public void SentEmail()
        //{
        //    string smtpAddress = "smtp-relay.gmail.com";
        //    int portNumber = 587;
        //    bool enableSSL = true;
        //    string emailFrom = "ab366665@gmail.com";
        //    string password = "Ajay14326";

        //    string emailTo = "ajaykumar@aureoleinc.com";
        //    string subject = "Hello";
        //    string tbody = "Hello, I'm just writing this to say Hi!";

        //    MailMessage msg = new MailMessage(emailFrom, emailTo, subject, tbody);
        //    msg.IsBodyHtml = true;
        //    SmtpClient sc = new SmtpClient("smtp.gmail.com", 587);
        //    sc.UseDefaultCredentials = false;
        //    NetworkCredential cre = new NetworkCredential(emailFrom, password);
        //    sc.Credentials = cre;
        //    sc.EnableSsl = true;
        //    sc.Send(msg);
        //}
        public void screenShot(string imgName)
        {
            BrowserWindow window = new BrowserWindow();
            string path = ConfigurationSettings.AppSettings["ScreenShot"];
            path = path + @"\\iPAS_ConfigWareHouseRoutes";
            Directory.CreateDirectory(path);
            try
            {
                window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
                Image image = window.CaptureImage();
                image.Save(path + "\\" + imgName + ".jpeg", ImageFormat.Jpeg);
                image.Dispose();
            }
            catch (Exception e) { }
            Console.WriteLine("Screen Shot is Avaliable in " + path + "\t" + "Folder");
        }
        public void WindowButtonClick<T>(PropertyType type, string propertyvalue) where T : WinControl
        {
            WinControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Name)
                genericControl.SearchProperties[WinControl.PropertyNames.Name] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void PathEnterText<T>(PropertyType type, string propertyvalue, string text) where T : WinEdit
        {
            WinEdit genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            genericControl.FilterProperties[WinEdit.PropertyNames.Name] = propertyvalue;
            AutoItX3 auto = new AutoItX3();
            auto.WinActivate("Choose File to Upload");
            auto.Send(text);
            auto.Send("{ENTER}");
            Thread.Sleep(1000);
        }
        public void Click<T>(PropertyType type, string propertyvalue) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });

            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;
            else if (type == PropertyType.InnerText)
            {
                genericControl.SearchProperties[HtmlControl.PropertyNames.InnerText] = propertyvalue;
            }
            else if (type == PropertyType.TagInstance)
                genericControl.FilterProperties[HtmlControl.PropertyNames.TagInstance] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void EnterText<T>(PropertyType type, string propertyvalue, string text) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;

            Keyboard.SendKeys(genericControl, text);

        }
        private BrowserWindow mparentwindow { get; set; }
        public enum PropertyType
        {
            Id,
            Name,
            InnerText,
            TagInstance
        }
        public BrowserWindow TopParentWindow()
        {

            BrowserWindow window = new BrowserWindow();
            window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
            return window;
        }
        public BrowserWindow ParentWindow
        {
            get
            {
                if (this.mparentwindow == null)
                {
                    this.mparentwindow = TopParentWindow();
                }
                return this.mparentwindow;
            }
        }
    }
}
