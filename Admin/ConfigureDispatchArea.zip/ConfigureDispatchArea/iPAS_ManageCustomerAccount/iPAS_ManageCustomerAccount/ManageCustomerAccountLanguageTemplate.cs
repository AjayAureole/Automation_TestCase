﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Text;
using System.Threading.Tasks;

namespace iPAS_ManageCustomerAccount
{
    class ManageCustomerAccountLanguageTemplate
    {
        static CultureInfo ci = null;
        static ResourceManager rm = null; 
        static string resMsg_CustomerAccountAddedSuccessfully = string.Empty;
        public string Msg_CustomerAccountAddedSuccessfully
        {
            get { return resMsg_CustomerAccountAddedSuccessfully; }
            set { resMsg_CustomerAccountAddedSuccessfully = value; }
        }
        static string resMsg_CustomeDuplicateAccount = string.Empty;
        public string Msg_CustomeDuplicateAccount
        {
            get { return resMsg_CustomeDuplicateAccount; }
            set { resMsg_CustomeDuplicateAccount = value; }
        }


        public static void messageResource(string languageCode)
        {
            if (languageCode == "zh-CN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ManageCustomerAccount.resource.ManageCustomerAccountCN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ManageCustomerAccount.resource.ManageCustomerAccountEN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
        }
        public static void messageInitialize()
        {
            resMsg_CustomerAccountAddedSuccessfully = rm.GetString("resMsg_CustomerAccountAddedSuccessfully", ci).Trim();
            resMsg_CustomeDuplicateAccount = rm.GetString("resMsg_CustomeDuplicateAccount", ci).Trim();
    }
}
}
