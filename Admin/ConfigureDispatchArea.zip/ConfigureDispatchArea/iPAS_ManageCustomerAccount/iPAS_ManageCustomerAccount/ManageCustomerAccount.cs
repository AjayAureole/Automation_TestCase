﻿using AutoItX3Lib;
using DataDrivenTesting;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace iPAS_ManageCustomerAccount
{
    class ManageCustomerAccount
    {
        string minsleep = ConfigurationSettings.AppSettings["min"];
        string midsleep = ConfigurationSettings.AppSettings["mid"];
        string maxsleep = ConfigurationSettings.AppSettings["max"];
        ManageCustomerAccountLanguageTemplate custAccount = new ManageCustomerAccountLanguageTemplate();
        public void addCustomerAccount()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "lnkAdmin");
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(max);
            Click<HtmlDiv>(PropertyType.Id, "footer");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkDispatch");
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(max);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkManageCusAccount");
            Thread.Sleep(min);
            auto.MouseClick();
            Thread.Sleep(max);
            auto.Send("{F5}");
            Thread.Sleep(max);
            var totalbefore = window.ExecuteScript("var data=document.getElementById('spnTotalRecords').innerHTML;  return  data");
            string tot = totalbefore.ToString().Trim();
            int totalbeforerecord = Convert.ToInt32(totalbefore);
            Thread.Sleep(min);
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtMasterCustomerName", ExcelDataTable.ReadData(1, "Customer Name"));
            }
            catch (Exception e) { }
            
            /***********************Clicking Add Button**********************/
            Thread.Sleep(mid);
            Click<HtmlCustom>(PropertyType.Id, "ContentPlaceHolder1_btnAddCustomer");
            Thread.Sleep(mid);
            var data = window.ExecuteScript("var data=document.getElementById('lblErrorMsg').innerHTML;  return  data");
            string successMsg = data.ToString().Trim();
            if (custAccount.Msg_CustomerAccountAddedSuccessfully != successMsg)
            {
                string screenShotName = "CustomerAccountAdded_NotSuccess";
                screenShot(screenShotName);
            }
            Assert.AreEqual(custAccount.Msg_CustomerAccountAddedSuccessfully, successMsg, successMsg);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            var afterTotal = window.ExecuteScript("var data=document.getElementById('spnTotalRecords').innerHTML;  return  data");
            string afterTot = afterTotal.ToString().Trim();
            int afterTotalRecords = Convert.ToInt32(afterTot);
            totalbeforerecord = totalbeforerecord + 1;
            Thread.Sleep(mid);
            if (afterTotalRecords != totalbeforerecord)
            {
                string screenShotName = "afterTotalRecords_NotProper";
                screenShot(screenShotName);
            }
            Assert.AreEqual(afterTotalRecords, totalbeforerecord, "Total Record value is Not Proper");
        }

        public void againAddCustomerAccount()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);           
            auto.Send("{F5}");
            Thread.Sleep(max);
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtMasterCustomerName", ExcelDataTable.ReadData(1, "Customer Name"));
            }catch(Exception e) { }
            /****************clicking on the Add Sub Account Details*************/
            Click<HtmlCustom>(PropertyType.Id, "addchildshippinglink");
            Thread.Sleep(mid);
            Click<HtmlCustom>(PropertyType.Id, "ContentPlaceHolder1_addMoreLink");
            Thread.Sleep(mid);
            /******************** 1st sub Account Details*************/
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtShipToNumber", ExcelDataTable.ReadData(1, "UpdateShip to Number1"));
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtSubCustomerName", ExcelDataTable.ReadData(1, "UpdateCustomer Name1"));
            }
            catch (Exception e) { }

            /******************** 2nd sub Account Details*************/
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder_1_txtShipToNumber", ExcelDataTable.ReadData(1, "UpdateShip to Number1"));
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder_1_txtSubCustomerName", ExcelDataTable.ReadData(1, "UpdateCustomer Name1"));
            }
            catch (Exception e) { }
            Thread.Sleep(mid);
            Click<HtmlCustom>(PropertyType.Id, "ContentPlaceHolder1_btnAddCustomer");
            Thread.Sleep(mid);
            var data = window.ExecuteScript("var data=document.getElementById('lblErrorMsg').innerHTML;  return  data");
            string successMsg = data.ToString().Trim();
            if (custAccount.Msg_CustomeDuplicateAccount != successMsg)
            {
                string screenShotName = "CustomerAccountUpdated_NotSuccess";
                screenShot(screenShotName);
            }
            Assert.AreEqual(custAccount.Msg_CustomeDuplicateAccount, successMsg, successMsg);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);

        }

        public void searchAndUpdate()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlCell>(PropertyType.InnerText, ExcelDataTable.ReadData(1, "Customer Name"));
            int Mx2 = auto.MouseGetPosX();
            int My2 = auto.MouseGetPosY();
            Mx2 = Mx2 - 325;
            Thread.Sleep(min);
            auto.MouseMove(Mx2, My2);
            auto.MouseClick();
            Thread.Sleep(mid);

            /******************Now Updating the Customer Info******************/
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "txtMasterCustomerName");
                auto.Send("{BACKSPACE 30}");//Existing Data Deletion
                auto.Send("{DEL 30}");
                EnterText<HtmlEdit>(PropertyType.Id, "txtMasterCustomerName", ExcelDataTable.ReadData(1, "UpdateCustomer Name"));
            }catch (Exception e) { }
            /****************clicking on the Add Sub Account Details*************/
            Click<HtmlCustom>(PropertyType.Id, "addchildshippinglink");
            Thread.Sleep(mid);
            Click<HtmlCustom>(PropertyType.Id, "ContentPlaceHolder1_addMoreLink");
            Thread.Sleep(mid);
            /******************** 1st sub Account Details*************/
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtShipToNumber", ExcelDataTable.ReadData(1, "UpdateShip to Number1"));
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtSubCustomerName", ExcelDataTable.ReadData(1, "UpdateCustomer Name1"));
            }
            catch (Exception e) { }

            /******************** 2nd sub Account Details*************/
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder_1_txtShipToNumber", ExcelDataTable.ReadData(1, "UpdateShip to Number2"));
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder_1_txtSubCustomerName", ExcelDataTable.ReadData(1, "UpdateCustomer Name2"));
            }
            catch (Exception e) { }
            Thread.Sleep(mid);
            Click<HtmlCustom>(PropertyType.Id, "ContentPlaceHolder1_btnUpdateCustomer");
            Thread.Sleep(mid);
            var data = window.ExecuteScript("var data=document.getElementById('lblErrorMsg').innerHTML;  return  data");
            string successMsg = data.ToString().Trim();
            if ("" != successMsg)
            {
                string screenShotName = "CustomerAccountUpdated_NotSuccess";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", successMsg, successMsg);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void clickPlusIcon()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);
            Click<HtmlCell>(PropertyType.InnerText, ExcelDataTable.ReadData(1, "UpdateCustomer Name"));
            int Mx2 = auto.MouseGetPosX();
            int My2 = auto.MouseGetPosY();
            Mx2 = Mx2 - 200;
            Thread.Sleep(min);
            auto.MouseMove(Mx2, My2);
            auto.MouseClick();
            Thread.Sleep(mid);
            /********************Delete the Sub Account 1*********************/
            try {
                Click<HtmlCell>(PropertyType.InnerText, ExcelDataTable.ReadData(1, "UpdateCustomer Name1"));
            }catch(Exception e)
            {
                if (true)
                {
                    string screenShotName = "Sub_Account1_IsNotUpdated";
                    screenShot(screenShotName);
                }
                Assert.IsFalse(true, ExcelDataTable.ReadData(1, "UpdateCustomer Name1")+"  "+"Sub Account Is Not Updated");
            }
            int Mx3 = auto.MouseGetPosX();
            int My3 = auto.MouseGetPosY();
            Mx3 = Mx3 - 50;
            Thread.Sleep(min);
            auto.MouseMove(Mx3, My3);
            auto.MouseClick();
            auto.Send("{ENTER}");
            Thread.Sleep(mid);


            /********************Delete the Sub Account 2*********************/
            try {
                Click<HtmlCell>(PropertyType.InnerText, ExcelDataTable.ReadData(1, "UpdateCustomer Name2"));

            }catch(Exception e)
            {
                if (true)
                {
                    string screenShotName = "Sub_Account2_IsNotUpdated";
                    screenShot(screenShotName);
                }
                Assert.IsFalse(true, ExcelDataTable.ReadData(1, "UpdateCustomer Name2") + "  " + "Sub Account Is Not Updated");
            }
            int Mx4 = auto.MouseGetPosX();
            int My4 = auto.MouseGetPosY();
            Mx4 = Mx4 - 50;
            Thread.Sleep(min);
            auto.MouseMove(Mx4, My4);
            auto.MouseClick();
            auto.Send("{ENTER}");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void searchAndDelete()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);

            var totalbefore = window.ExecuteScript("var data=document.getElementById('spnTotalRecords').innerHTML;  return  data");
            string tot = totalbefore.ToString().Trim();
            int totalbeforerecord = Convert.ToInt32(totalbefore);
            Thread.Sleep(min);

            Click<HtmlCell>(PropertyType.InnerText, ExcelDataTable.ReadData(1, "UpdateCustomer Name"));
            int Mx2 = auto.MouseGetPosX();
            int My2 = auto.MouseGetPosY();
            Mx2 = Mx2 - 300;
            Thread.Sleep(min);
            auto.MouseMove(Mx2, My2);
            auto.MouseClick();
            Thread.Sleep(min);
            auto.Send("{ENTER}");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);
            var afterTotal = window.ExecuteScript("var data=document.getElementById('spnTotalRecords').innerHTML;  return  data");
            string afterTot = afterTotal.ToString().Trim();
            int afterTotalRecords = Convert.ToInt32(afterTot);
            totalbeforerecord = totalbeforerecord - 1;
            Thread.Sleep(mid);
            if (afterTotalRecords != totalbeforerecord)
            {
                string screenShotName = "TotalRecord_IsNotProper";
                screenShot(screenShotName);
            }
            Assert.AreEqual(afterTotalRecords, totalbeforerecord, "Total Record value is Not Proper");
        }
        public void screenShot(string imgName)
        {
            BrowserWindow window = new BrowserWindow();
            string path = ConfigurationSettings.AppSettings["ScreenShot"];
            path = path + @"\\iPAS_ManageCustomerAccount";
            Directory.CreateDirectory(path);
            try
            {
                window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
                Image image = window.CaptureImage();
                image.Save(path + "\\" + imgName + ".jpeg", ImageFormat.Jpeg);
                image.Dispose();
            }
            catch (Exception e) { }
            Console.WriteLine("Screen Shot is Avaliable in " + path + "\t" + "Folder");
        }
        public void WindowButtonClick<T>(PropertyType type, string propertyvalue) where T : WinControl
        {
            WinControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Name)
                genericControl.SearchProperties[WinControl.PropertyNames.Name] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void PathEnterText<T>(PropertyType type, string propertyvalue, string text) where T : WinEdit
        {
            WinEdit genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            genericControl.FilterProperties[WinEdit.PropertyNames.Name] = propertyvalue;
            AutoItX3 auto = new AutoItX3();
            auto.WinActivate("Choose File to Upload");
            auto.Send(text);
            auto.Send("{ENTER}");
            Thread.Sleep(1000);
        }
        public void Click<T>(PropertyType type, string propertyvalue) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });

            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;
            else if (type == PropertyType.InnerText)
            {
                genericControl.SearchProperties[HtmlControl.PropertyNames.InnerText] = propertyvalue;
            }
            else if (type == PropertyType.TagInstance)
                genericControl.FilterProperties[HtmlControl.PropertyNames.TagInstance] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void EnterText<T>(PropertyType type, string propertyvalue, string text) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;

            Keyboard.SendKeys(genericControl, text);

        }
        private BrowserWindow mparentwindow { get; set; }
        public enum PropertyType
        {
            Id,
            Name,
            InnerText,
            TagInstance
        }
        public BrowserWindow TopParentWindow()
        {

            BrowserWindow window = new BrowserWindow();
            window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
            return window;
        }
        public BrowserWindow ParentWindow
        {
            get
            {
                if (this.mparentwindow == null)
                {
                    this.mparentwindow = TopParentWindow();
                }
                return this.mparentwindow;
            }
        }
    }
}
