﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Text;
using System.Threading.Tasks;

namespace iPAS_DefinePackageSize
{
    class PackageTypeLanguageTemplate
    {
        static CultureInfo ci = null;
        static ResourceManager rm = null;
        static string resMsg_EnterHeight = string.Empty;
        public string Msg_EnterHeight
        {
            get { return resMsg_EnterHeight; }
            set { resMsg_EnterHeight = value; }
        }

        static string resMsg_EnterLength = string.Empty;
        public string Msg_EnterLength
        {
            get { return resMsg_EnterLength; }
            set { resMsg_EnterLength = value; }
        }

        static string resMsg_EnterPackageName = string.Empty;
        public string Msg_EnterPackageName
        {
            get { return resMsg_EnterPackageName; }
            set { resMsg_EnterPackageName = value; }
        }
        static string resMsg_EnterWidth = string.Empty;
        public string Msg_EnterWidth
        {
            get { return resMsg_EnterWidth; }
            set { resMsg_EnterWidth = value; }
        }


        static string resMsg_PackageTypeAddedSuccessfully = string.Empty;
        public string Msg_PackageTypeAddedSuccessfully
        {
            get { return resMsg_PackageTypeAddedSuccessfully; }
            set { resMsg_PackageTypeAddedSuccessfully = value; }
        }
        static string resMsg_PackageTypeUpdatedSuccessfully = string.Empty;
        public string Msg_PackageTypeUpdatedSuccessfully
        {
            get { return resMsg_PackageTypeUpdatedSuccessfully; }
            set { resMsg_PackageTypeUpdatedSuccessfully = value; }
        }
        public static void messageResource(string languageCode)
        {
            if (languageCode == "zh-CN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_DefinePackageSize.resource.PackageTypeCN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_DefinePackageSize.resource.PackageTypeEN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
        }
        public static void messageInitialize()
        {
            resMsg_EnterHeight = rm.GetString("resMsg_EnterHeight", ci).Trim();
            resMsg_EnterLength = rm.GetString("resMsg_EnterLength", ci).Trim();
            resMsg_EnterPackageName = rm.GetString("resMsg_EnterPackageName", ci).Trim();
            resMsg_EnterWidth = rm.GetString("resMsg_EnterWidth", ci).Trim();
            resMsg_PackageTypeAddedSuccessfully = rm.GetString("resMsg_PackageTypeAddedSuccessfully", ci).Trim();
            resMsg_PackageTypeUpdatedSuccessfully = rm.GetString("resMsg_PackageTypeUpdatedSuccessfully", ci).Trim();

        }
    }
}
