﻿using System;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using DataDrivenTesting;
using ConfigureReceivingArea;
using OpenQA.Selenium;
using System.Diagnostics;
using System.Threading;
using OpenQA.Selenium.Firefox;
using System.Configuration;


namespace iPAS_DispatchArea
{
    /// <summary>
    /// Summary description for CodedUITest1
    /// </summary>
    [CodedUITest]
    public class CodedUITest1
    {
        private IWebDriver driver;
        string url = string.Empty;
        string browserName = string.Empty;
        [TestInitialize]
        public void Initialize()
        {            
            string loginExcel = ConfigurationSettings.AppSettings["loginExcel"];
            string path = ConfigurationSettings.AppSettings["ExcelPath"];
            ExcelDataTable.PopulateInCollection(loginExcel + "\\LoginExcel.xlsx");
            ExcelDataTable.PopulateInCollection(path + "\\DispatchAreaInfo.xlsx");
            url = ExcelDataTable.ReadData(1, "Url");
            browserName= ExcelDataTable.ReadData(1, "Browser");
        }
        [TestMethod]
        public void CodedUITestMethod1()
        {            
            BrowserWindow window = new BrowserWindow();

            string[] bro = browserName.Split(' ');
            for (int i = 0; i < 1; i++)
            {
                BrowserWindow.CurrentBrowser = "IE";                
                var browser = BrowserWindow.Launch(new Uri(url));                
                Thread.Sleep(2000);
                ExecuteTestCases(browser);
                Thread.Sleep(1000);
                browser.Close();                
            }
        }       
        public void ExecuteTestCases(BrowserWindow browser)
        {
            LoginUser login = new LoginUser();
            login.Login(browser);
            DispatchAreaInfo dispatchinfo = new DispatchAreaInfo();
            dispatchinfo.AddDispatchArea(browser);
            dispatchinfo.Update(browser);
            dispatchinfo.delete(browser);
            dispatchinfo.AddButtonClick(browser);
        }
        [TestCleanup]
        public void DeleteBrowserData()
        {
            //Temporary Internet Files
            Process.Start("rundll32.exe", "InetCpl.cpl,ClearMyTracksByProcess 8");
            //Cookies()
            Process.Start("rundll32.exe", "InetCpl.cpl,ClearMyTracksByProcess 2");
            //History()
            Process.Start("rundll32.exe", "InetCpl.cpl,ClearMyTracksByProcess 1");
            //Form(Data)
            Process.Start("rundll32.exe", "InetCpl.cpl,ClearMyTracksByProcess 16");
            //Passwords
            Process.Start("rundll32.exe", "InetCpl.cpl,ClearMyTracksByProcess 32");
            //Delete(All)
            Process.Start("rundll32.exe", "InetCpl.cpl,ClearMyTracksByProcess 255");
            //Delete All – Also delete files and settings stored by add-ons
            Process.Start("rundll32.exe", "InetCpl.cpl,ClearMyTracksByProcess 4351"); 
        }
        #region Additional test attributes

        // You can use the following additional attributes as you write your tests:

        ////Use TestInitialize to run code before running each test 
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{        
        //    // To generate code for this test, select "Generate Code for Coded UI Test" from the shortcut menu and select one of the menu items.
        //}

        ////Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{        
        //    // To generate code for this test, select "Generate Code for Coded UI Test" from the shortcut menu and select one of the menu items.
        //}

        #endregion

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }
        private TestContext testContextInstance;
    }
}
