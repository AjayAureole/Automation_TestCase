﻿
using Excel;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace DataDrivenTesting
{
    public class ExcelDataTable
    {

        public static DataTable ExcelData(string filePath)
        {
            FileStream stream = File.Open(filePath,FileMode.Open,FileAccess.Read);

            IExcelDataReader excelreader = ExcelReaderFactory.CreateOpenXmlReader(stream);

            //Here set the First Row as a column
            excelreader.IsFirstRowAsColumnNames = true;

            DataSet result = excelreader.AsDataSet();
            DataTableCollection table = result.Tables;
            DataTable resultTable = table["sheet1"];
            excelreader.Close();
            return resultTable;

        }
       public static List<DataCollection>  datacol = new List<DataCollection>();
        public static void PopulateInCollection(string filePath)
        {
           // ExcelDataTable data = new ExcelDataTable();
            DataTable table = ExcelData(filePath);
            for(int row = 1; row <= table.Rows.Count; row++)
            {

                for (int col = 0; col <= table.Columns.Count-1; col++)
                {
                    DataCollection dtTable = new DataCollection()
                    {
                        rowNumber = row,
                        colName = table.Columns[col].ColumnName,
                        colValue = table.Rows[row - 1][col].ToString()
                    };

                datacol.Add(dtTable);                
                }
            }

        }
        
        public static string ReadData(int rowNumber,string columnName)
        {
            try
            {
                string data = (from colData in datacol
                               where colData.colName == columnName && colData.rowNumber == rowNumber
                               select colData.colValue).SingleOrDefault();
                return data.ToString();

            }catch(Exception e)
            {
                return null;
            }
        }

    }



    public class DataCollection
    {
        public int rowNumber { get; set; }
        public string colName { get; set; }
        public string colValue { get; set; }

    }
}
