﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Text;
using System.Threading.Tasks;

namespace iPAS_DispatchArea
{
    class DispatchAreaLanguageTemplate
    {
        static CultureInfo ci = null;
        static ResourceManager rm = null;
        static string resMsg_DispatchAreaAddedSuccessfully = string.Empty;
        public string Msg_DispatchAreaAddedSuccessfully
        {
            get { return resMsg_DispatchAreaAddedSuccessfully; }
            set { resMsg_DispatchAreaAddedSuccessfully = value; }
        }

        static string resMsg_DispatchAreaUpdatedSuccessfully = string.Empty;
        public string Msg_DispatchAreaUpdatedSuccessfully
        {
            get { return resMsg_DispatchAreaUpdatedSuccessfully; }
            set { resMsg_DispatchAreaUpdatedSuccessfully = value; }
        }

        /// 
        
        static string resMsg_PleaseEnterKeyName = string.Empty;
        public string Msg_PleaseEnterKeyName
        {
            get { return resMsg_PleaseEnterKeyName; }
            set { resMsg_PleaseEnterKeyName = value; }
        }
        static string resMsg_PleaseEnterKeyValue = string.Empty;
        public string Msg_PleaseEnterKeyValue
        {
            get { return resMsg_PleaseEnterKeyValue; }
            set { resMsg_PleaseEnterKeyValue = value; }
        }
        static string resMsg_PleaseSelectPickingType = string.Empty;
        public string Msg_PleaseSelectPickingType
        {
            get { return resMsg_PleaseSelectPickingType; }
            set { resMsg_PleaseSelectPickingType = value; }
        }
        static string resMsg_PleaseSelectCheckingAndPackingType = string.Empty;
        public string Msg_PleaseSelectCheckingAndPackingType
        {
            get { return resMsg_PleaseSelectCheckingAndPackingType; }
            set { resMsg_PleaseSelectCheckingAndPackingType = value; }
        }
        public static void messageResource(string languageCode)
        {
            if (languageCode == "zh-CN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_DispatchArea.Resource.DispatchAreaCN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }else
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_DispatchArea.Resource.DispatchAreaEN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
        }
        public static void messageInitialize()
        {
            resMsg_DispatchAreaAddedSuccessfully = rm.GetString("resMsg_DispatchAreaAddedSuccessfully", ci).Trim();
            resMsg_DispatchAreaUpdatedSuccessfully = rm.GetString("resMsg_DispatchAreaUpdatedSuccessfully", ci).Trim();
            resMsg_PleaseEnterKeyName = rm.GetString("resMsg_PleaseEnterKeyName", ci).Trim();
            resMsg_PleaseEnterKeyValue = rm.GetString("resMsg_PleaseEnterKeyValue", ci).Trim();
            resMsg_PleaseSelectPickingType = rm.GetString("resMsg_PleaseSelectPickingType", ci).Trim();
            resMsg_PleaseSelectCheckingAndPackingType = rm.GetString("resMsg_PleaseSelectCheckingAndPackingType", ci).Trim();

        }
    }
}
