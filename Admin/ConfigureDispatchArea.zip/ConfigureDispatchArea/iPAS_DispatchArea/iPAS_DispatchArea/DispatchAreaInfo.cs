﻿using AutoItX3Lib;
using DataDrivenTesting;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace iPAS_DispatchArea
{
    class DispatchAreaInfo
    {
        string minsleep = ConfigurationSettings.AppSettings["min"];
        string midsleep = ConfigurationSettings.AppSettings["mid"];
        string maxsleep = ConfigurationSettings.AppSettings["max"];
        DispatchAreaLanguageTemplate Dispatchlanguage = new DispatchAreaLanguageTemplate();
        public void AddDispatchArea(BrowserWindow browser)
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(min);
            Click<HtmlHyperlink>(PropertyType.Id, browser, "lnkAdmin");
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(max);
            Click<HtmlDiv>(PropertyType.Id,browser,"footer");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, browser, "ContentPlaceHolder1_lnkDispatch");
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(max);
            Click<HtmlHyperlink>(PropertyType.Id, browser, "ContentPlaceHolder1_lnkDispatchArea");
            Thread.Sleep(min);
            auto.MouseClick();
            Thread.Sleep(max);
            auto.Send("{F5}");
            Thread.Sleep(max);
            var totalbefore = browser.ExecuteScript("var data=document.getElementById('spnTotalRecords').innerHTML;  return  data");
            string tot = totalbefore.ToString().Trim();
            int totalbeforerecord = Convert.ToInt32(totalbefore);
            Thread.Sleep(max);
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, browser, "txtName",ExcelDataTable.ReadData(1, "Key Name"));
            }catch(Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, browser, "txtValue", ExcelDataTable.ReadData(1, "Key Value"));
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlCheckBox>(PropertyType.Id, browser, "chkSTOEnabled");
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlCheckBox>(PropertyType.Id, browser, "chkSingleOrder");
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlCheckBox>(PropertyType.Id, browser, "chkCollective");
            }
            catch (Exception e) { }
            Thread.Sleep(mid);
            Click<HtmlCustom>(PropertyType.Id, browser, "btnAddDiapatchArea");
            Thread.Sleep(max);
            var afterTotal = browser.ExecuteScript("var data=document.getElementById('spnTotalRecords').innerHTML;  return  data");
            string afterTot = afterTotal.ToString().Trim();
            int afterTotalRecords = Convert.ToInt32(afterTot);
            totalbeforerecord = totalbeforerecord + 1;
            Thread.Sleep(mid);
            if (afterTotalRecords != totalbeforerecord)
            {
                string screenShotName = "afterTotalRecords_NotProper";
                screenShot(screenShotName);
            }
            Assert.AreEqual(afterTotalRecords, totalbeforerecord, "Total Record value is Not Proper");
            Thread.Sleep(mid);
            var DipatchMsg = browser.ExecuteScript("var data=document.getElementById('lblErrorMsg').innerHTML; return data;");
            string msg = DipatchMsg.ToString().Trim();
            if (msg != Dispatchlanguage.Msg_DispatchAreaAddedSuccessfully)
            {
                string screenShotName = "added_NotSuccessfully";
                screenShot(screenShotName);
            }
            Assert.AreEqual(Dispatchlanguage.Msg_DispatchAreaAddedSuccessfully, msg,msg);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void Update(BrowserWindow browser)
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(max);
            auto.Send("{F5}");
            Thread.Sleep(max);
            Click<HtmlDiv>(PropertyType.InnerText, browser, ExcelDataTable.ReadData(1, "Key Name"));
            int Mx2 = auto.MouseGetPosX();
            int My2 = auto.MouseGetPosY();
            Mx2 = Mx2 - 170;
            Thread.Sleep(max);
            auto.MouseMove(Mx2, My2);
            auto.MouseClick();
            Thread.Sleep(max);

            /********************Updating the Dispatch information***************/

            try {

                Click<HtmlEdit>(PropertyType.Id,browser,"txtName");
                auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                auto.Send("{DEL 20}");
                EnterText<HtmlEdit>(PropertyType.Id,browser,"txtName", ExcelDataTable.ReadData(1, "UpdateKey Name"));
            }catch(Exception e) { }
            try
            {
                Click<HtmlEdit>(PropertyType.Id,browser,"txtValue");
                auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                auto.Send("{DEL 20}");
                EnterText<HtmlEdit>(PropertyType.Id,browser,"txtValue", ExcelDataTable.ReadData(1, "UpdateKey Value"));
            }catch (Exception e) { }
            try
            {
                Click<HtmlCheckBox>(PropertyType.Id, browser, "chkSTOEnabled");
            }catch (Exception e) { }
            try
            {
                Thread.Sleep(mid);
                Click<HtmlCheckBox>(PropertyType.Id, browser, "chkByGroup");
            }catch (Exception e) { }
            try
            {
                Click<HtmlCheckBox>(PropertyType.Id, browser, "chkByProduct");
            }catch (Exception e) { }
            Thread.Sleep(mid);
            Click<HtmlCustom>(PropertyType.Id,browser, "btnUpdateDispatchArea");
            Thread.Sleep(mid);
            var DipatchUpdateMsg = browser.ExecuteScript("var data=document.getElementById('lblErrorMsg').innerHTML; return data;");
            string msg = DipatchUpdateMsg.ToString().Trim();
            if (msg != Dispatchlanguage.Msg_DispatchAreaUpdatedSuccessfully)
            {
                string screenShotName = "updated_NotSuccessfully";
                screenShot(screenShotName);
            }
            Assert.AreEqual(Dispatchlanguage.Msg_DispatchAreaUpdatedSuccessfully, msg, msg);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void delete( BrowserWindow browser)
        {           
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(max);
            auto.Send("{F5}");
            Thread.Sleep(max);
            //var list = browser.ExecuteScript(@"var list=document.getElementById('tblDispatchConfigArea').getElementsByTagName('div'); 
            //                   var div_id;
            //                   for (var i = 0; i < list.length; i++)
            //                     {
            //                          if(list[i].innerHTML=='Ajay'){
            //                            div_id=list[i].getAttribute('id');
            //                            alert(div_id);
            //                            }                                   
            //                     }
            //               return div_id;"); 
            //string id= list.ToString().Trim();

            Click<HtmlDiv>(PropertyType.InnerText, browser, ExcelDataTable.ReadData(1, "UpdateKey Name"));
            int Mx2 = auto.MouseGetPosX();
            int My2 = auto.MouseGetPosY();
            Mx2 = Mx2 - 140;
            Thread.Sleep(max);
            auto.MouseMove(Mx2, My2);
            auto.MouseClick();
            Thread.Sleep(min);
            auto.Send("{ENTER}");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);
        }
        public void AddButtonClick(BrowserWindow browser)
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(max);
            auto.Send("{F5}");
            Thread.Sleep(max);  
            /**************Without Enter  any Data Click on the Add Button*********/
            
            Click<HtmlCustom>(PropertyType.Id, browser, "btnAddDiapatchArea");
            Thread.Sleep(mid);
            var DipatchUpdateMsg = window.ExecuteScript("var data=document.getElementById('lblErrorMsg').innerHTML; return data;");
            string msg = DipatchUpdateMsg.ToString().Trim();
            //Here Removining Some Extra thing
            msg = msg.Replace("*", "");
            msg = msg.Replace("<br>", "");
            msg = msg.Replace("&amp;", "");
            msg = msg.Replace(" ", "");

            //Resource file 
            string resMsg = Dispatchlanguage.Msg_PleaseEnterKeyName + Dispatchlanguage.Msg_PleaseEnterKeyValue + Dispatchlanguage.Msg_PleaseSelectPickingType + Dispatchlanguage.Msg_PleaseSelectCheckingAndPackingType;
            //Here Removining Some Extra thing
            resMsg = resMsg.Replace(" ","");
            resMsg = resMsg.Replace("&","");
            if (msg != resMsg)
            {
                string screenShotName = "NegativeTestCaseIs_Fail";
                screenShot(screenShotName);
            }
            Assert.AreEqual(resMsg, msg, msg);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(max);
            Click<HtmlCustom>(PropertyType.Id, browser, "btnClear");
        }
        public void screenShot(string imgName)
        {
            BrowserWindow window = new BrowserWindow();
            string path = ConfigurationSettings.AppSettings["ScreenShot"];
            path = path + @"\\iPAS_DispatchArea";
            Directory.CreateDirectory(path);
            try
            {
                window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
                Image image = window.CaptureImage();
                image.Save(path + "\\" + imgName + ".jpeg", ImageFormat.Jpeg);
                image.Dispose();
            }
            catch (Exception e) { }
            Console.WriteLine("Screen Shot is Avaliable in " + path + "\t" + "Folder");
        }
        public void PathEnterText<T>(PropertyType type, BrowserWindow browser, string propertyvalue, string text) where T : WinEdit
        {
            WinEdit genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { browser });
            genericControl.FilterProperties[WinEdit.PropertyNames.Name] = propertyvalue;
            AutoItX3 auto = new AutoItX3();
            auto.WinActivate("Choose File to Upload");
            auto.Send(text);
            auto.Send("{ENTER}");
            Thread.Sleep(1000);
        }
        public void WindowButtonClick<T>(PropertyType type, BrowserWindow browser, string propertyvalue) where T : WinControl
        {
            WinControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { browser });
            if (type == PropertyType.Name)
                genericControl.SearchProperties[WinControl.PropertyNames.Name] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void Click<T>(PropertyType type, BrowserWindow browser, string propertyvalue) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { browser });
            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;
            else if (type == PropertyType.InnerText)
                genericControl.FilterProperties[HtmlControl.PropertyNames.InnerText] = propertyvalue;            
            else if (type == PropertyType.TagInstance)
                genericControl.FilterProperties[HtmlControl.PropertyNames.TagInstance] = propertyvalue;
            else if (type == PropertyType.FriendlyName)
                genericControl.FilterProperties[HtmlControl.PropertyNames.FriendlyName] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void EnterText<T>(PropertyType type, BrowserWindow browser, string propertyvalue, string text) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { browser });
            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;

            Keyboard.SendKeys(genericControl, text);
        }
        private BrowserWindow mparentwindow { get; set; }
        public enum PropertyType
        {
            Id,
            Name,
            InnerText,
            TagInstance,
            DisplayText,
            FriendlyName
        }
        public BrowserWindow TopParentWindow()
        {
            BrowserWindow window = new BrowserWindow();
            window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
            return window;
        }
        public BrowserWindow ParentWindow
        {
            get
            {
                if (this.mparentwindow == null)
                {
                    this.mparentwindow = TopParentWindow();
                }
                return this.mparentwindow;
            }
        }
    }
}
