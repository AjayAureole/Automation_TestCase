﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Text;
using System.Threading.Tasks;

namespace iPAS_ManageCarriers
{
    class CarrierLanguageTemplate
    {
        static CultureInfo ci = null;
        static ResourceManager rm = null;
        static string resMsg_CarrierAddedSuccessfully = string.Empty;
        public string Msg_CarrierAddedSuccessfully
        {
            get { return resMsg_CarrierAddedSuccessfully; }
            set { resMsg_CarrierAddedSuccessfully = value; }
        }

        static string resMsg_CarrierUpdatedSuccessfully = string.Empty;
        public string Msg_CarrierUpdatedSuccessfully
        {
            get { return resMsg_CarrierUpdatedSuccessfully; }
            set { resMsg_CarrierUpdatedSuccessfully = value; }
        }

        static string resMsg_EnterCarrierCode = string.Empty;
        public string Msg_EnterCarrierCode
        {
            get { return resMsg_EnterCarrierCode; }
            set { resMsg_EnterCarrierCode = value; }
        }
        static string resMsg_EnterCarrierName = string.Empty;
        public string Msg_EnterCarrierName
        {
            get { return resMsg_EnterCarrierName; }
            set { resMsg_EnterCarrierName = value; }
        }
        
        public static void messageResource(string languageCode)
        {
            if (languageCode == "zh-CN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ManageCarriers.resource.CarrierCN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ManageCarriers.resource.CarrierEN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
        }
        public static void messageInitialize()
        {
            resMsg_CarrierAddedSuccessfully = rm.GetString("resMsg_CarrierAddedSuccessfully", ci).Trim();
            resMsg_CarrierUpdatedSuccessfully = rm.GetString("resMsg_CarrierUpdatedSuccessfully", ci).Trim();
            resMsg_EnterCarrierCode = rm.GetString("resMsg_EnterCarrierCode", ci).Trim();
            resMsg_EnterCarrierName = rm.GetString("resMsg_EnterCarrierName", ci).Trim();
        }
    }
}
