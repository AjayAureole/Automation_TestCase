﻿using AutoItX3Lib;
using DataDrivenTesting;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace iPAS_ManageExternalWarehouse
{
    class ManageExternalWarehouse
    {
        string minsleep = ConfigurationSettings.AppSettings["min"];
        string midsleep = ConfigurationSettings.AppSettings["mid"];
        string maxsleep = ConfigurationSettings.AppSettings["max"];
        ManageExternalWarehouseLanguageTemplate externalWarehourse = new ManageExternalWarehouseLanguageTemplate();
        public void addExternalWarehouse()
        {

            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "lnkAdmin");
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(max);
            Click<HtmlDiv>(PropertyType.Id, "footer");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkDispatch");
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(max);
            try {
                Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkManageExtWarehouse");
            }catch(Exception e)
            {
                string screenShotName = "NotFoundExternalWarehouse";
                screenShot(screenShotName);
                Assert.IsFalse(true, "ManageExternalWarehouse Module is Not visible");
            }
            Thread.Sleep(min);
            auto.MouseClick();
            Thread.Sleep(max);
            auto.Send("{F5}");
            Thread.Sleep(max);
            var totalbefore = window.ExecuteScript("var data=document.getElementById('spnTotalRecords').innerHTML;  return  data");
            string tot = totalbefore.ToString().Trim();
            int totalbeforerecord = Convert.ToInt32(totalbefore);
            Thread.Sleep(min);
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtDispatchGate", ExcelDataTable.ReadData(1, "Dispatch Gate"));
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtWarehouseName", ExcelDataTable.ReadData(1, "Warehouse Name"));

            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtPlantCode", ExcelDataTable.ReadData(1, "Receive Plant Code"));

            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtStorageLocation", ExcelDataTable.ReadData(1, "Receive Storage Location"));

            }
            catch (Exception e) { }
            Thread.Sleep(mid);
            Click<HtmlCustom>(PropertyType.Id, "ContentPlaceHolder1_btnAddWarehouse");
            Thread.Sleep(max);
            var data = window.ExecuteScript("var data=document.getElementById('spnAddWarehouseError').innerHTML;  return  data");
            string successMsg = data.ToString().Trim();
            if (externalWarehourse.Msg_AddWarehouseSuccess != successMsg)
            {
                string screenShotName = "ExternalWarehouseAdded_NotSuccess";
                screenShot(screenShotName);
            }
            Assert.AreEqual(externalWarehourse.Msg_AddWarehouseSuccess, successMsg, successMsg);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            var afterTotal = window.ExecuteScript("var data=document.getElementById('spnTotalRecords').innerHTML;  return  data");
            string afterTot = afterTotal.ToString().Trim();
            int afterTotalRecords = Convert.ToInt32(afterTot);
            totalbeforerecord = totalbeforerecord + 1;
            Thread.Sleep(mid);
            if (afterTotalRecords != totalbeforerecord)
            {
                string screenShotName = "afterTotalRecords_NotProper";
                screenShot(screenShotName);
            }
            Assert.AreEqual(afterTotalRecords, totalbeforerecord, "Total Record value is Not Proper");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void againAdExternalWarehouse()
        {

            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);            
            auto.Send("{F5}");
            Thread.Sleep(max);
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtDispatchGate", ExcelDataTable.ReadData(1, "Dispatch Gate"));
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtWarehouseName", ExcelDataTable.ReadData(1, "Warehouse Name"));

            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtPlantCode", ExcelDataTable.ReadData(1, "Receive Plant Code"));

            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtStorageLocation", ExcelDataTable.ReadData(1, "Receive Storage Location"));

            }
            catch (Exception e) { }
            Thread.Sleep(mid);
            Click<HtmlCustom>(PropertyType.Id, "ContentPlaceHolder1_btnAddWarehouse");
            Thread.Sleep(max);
            var data = window.ExecuteScript("var data=document.getElementById('spnAddWarehouseError').innerHTML;  return  data");
            string successMsg = data.ToString().Trim();
            if (externalWarehourse.Msg_WarehouseNameAlreadyExistInGate != successMsg)
            {
                string screenShotName = "ExternalWarehouseAdded_NotSuccess";
                screenShot(screenShotName);
            }
            Assert.AreEqual(externalWarehourse.Msg_WarehouseNameAlreadyExistInGate, successMsg, successMsg);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);           
        }
        public void updateExternalWarehouse()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlCell>(PropertyType.InnerText, ExcelDataTable.ReadData(1, "Dispatch Gate"));
            int Mx2 = auto.MouseGetPosX();
            int My2 = auto.MouseGetPosY();
            Mx2 = Mx2 - 95;
            Thread.Sleep(min);
            auto.MouseMove(Mx2, My2);
            auto.MouseClick();
            Thread.Sleep(mid);
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "txtDispatchGate");
                auto.Send("{BACKSPACE 30}");//Existing Data Deletion
                auto.Send("{DEL 30}");
                EnterText<HtmlEdit>(PropertyType.Id, "txtDispatchGate", ExcelDataTable.ReadData(1, "UpdateDispatch Gate"));
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "txtWarehouseName");
                auto.Send("{BACKSPACE 30}");//Existing Data Deletion
                auto.Send("{DEL 30}");
                EnterText<HtmlEdit>(PropertyType.Id, "txtWarehouseName", ExcelDataTable.ReadData(1, "UpdateWarehouse Name"));

            }
            catch (Exception e) { }
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "txtPlantCode");
                auto.Send("{BACKSPACE 30}");//Existing Data Deletion
                auto.Send("{DEL 30}");
                EnterText<HtmlEdit>(PropertyType.Id, "txtPlantCode", ExcelDataTable.ReadData(1, "UpdateReceive Plant Code"));

            }
            catch (Exception e) { }
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "txtStorageLocation");
                auto.Send("{BACKSPACE 30}");//Existing Data Deletion
                auto.Send("{DEL 30}");
                EnterText<HtmlEdit>(PropertyType.Id, "txtStorageLocation", ExcelDataTable.ReadData(1, "UpdateReceive Storage Location"));

            }
            catch (Exception e) { }
            Thread.Sleep(mid);
            Click<HtmlCustom>(PropertyType.Id, "ContentPlaceHolder1_btnAddWarehouse");
            Thread.Sleep(max);
            var data = window.ExecuteScript("var data=document.getElementById('spnAddWarehouseError').innerHTML;  return  data");
            string successMsg = data.ToString().Trim();
            if (externalWarehourse.Msg_UpdateWarehouseSuccess != successMsg)
            {
                string screenShotName = "ExternalWarehouseupdated_NotSuccess";
                screenShot(screenShotName);
            }
            Assert.AreEqual(externalWarehourse.Msg_UpdateWarehouseSuccess, successMsg, successMsg);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void delete()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);

            var totalbefore = window.ExecuteScript("var data=document.getElementById('spnTotalRecords').innerHTML;  return  data");
            string tot = totalbefore.ToString().Trim();
            int totalbeforerecord = Convert.ToInt32(totalbefore);
            Thread.Sleep(min);

            Click<HtmlCell>(PropertyType.InnerText, ExcelDataTable.ReadData(1, "UpdateDispatch Gate"));
            int Mx2 = auto.MouseGetPosX();
            int My2 = auto.MouseGetPosY();
            Mx2 = Mx2 - 70;
            Thread.Sleep(min);
            auto.MouseMove(Mx2, My2);
            auto.MouseClick();
            Thread.Sleep(mid);
            auto.Send("{ENTER}");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);
            var afterTotal = window.ExecuteScript("var data=document.getElementById('spnTotalRecords').innerHTML;  return  data");
            string afterTot = afterTotal.ToString().Trim();
            int afterTotalRecords = Convert.ToInt32(afterTot);
            totalbeforerecord = totalbeforerecord - 1;
            Thread.Sleep(mid);
            if (afterTotalRecords != totalbeforerecord)
            {
                string screenShotName = "afterDeletedTotalRecords_NotProper";
                screenShot(screenShotName);
            }
            Assert.AreEqual(afterTotalRecords, totalbeforerecord, "Total Record value is Not Proper");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void AddButtonClick()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(max);
            auto.Send("{F5}");
            Thread.Sleep(max);
            /**************Without Enter  any Data Click on the Add Button*********/

            Click<HtmlCustom>(PropertyType.Id, "ContentPlaceHolder1_btnAddWarehouse");
            Thread.Sleep(max);
            var data = window.ExecuteScript("var data=document.getElementById('spnAddWarehouseError').innerHTML;  return  data");
            string msg = data.ToString().Trim();

            //Here Removining Some Extra thing
            msg = msg.Replace("*", "");
            msg = msg.Replace("<br>","");
            msg = msg.Replace(" ", "");

            string resMsg = externalWarehourse.Msg_EnterPlantCode + externalWarehourse.Msg_EnterWarehouseName + externalWarehourse.Msg_EnterDispatchGate;            
            resMsg = resMsg.Replace(" ", "");
            if (msg != resMsg)
            {
                string screenShotName = "NegativeTestCaseIs_Fail";
                screenShot(screenShotName);
            }
            Assert.AreEqual(resMsg, msg, msg);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);
            Click<HtmlCustom>(PropertyType.Id, "ContentPlaceHolder1_btnCancel");
        }
        public void screenShot(string imgName)
        {
            BrowserWindow window = new BrowserWindow();
            string path = ConfigurationSettings.AppSettings["ScreenShot"];
            path = path + @"\\iPAS_ManageExternalWarehouse";
            Directory.CreateDirectory(path);
            try
            {
                window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
                Image image = window.CaptureImage();
                image.Save(path + "\\" + imgName + ".jpeg", ImageFormat.Jpeg);
                image.Dispose();
            }
            catch (Exception e) { }
            Console.WriteLine("Screen Shot is Avaliable in " + path + "\t" + "Folder");
        }
        public void WindowButtonClick<T>(PropertyType type, string propertyvalue) where T : WinControl
        {
            WinControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Name)
                genericControl.SearchProperties[WinControl.PropertyNames.Name] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void PathEnterText<T>(PropertyType type, string propertyvalue, string text) where T : WinEdit
        {
            WinEdit genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            genericControl.FilterProperties[WinEdit.PropertyNames.Name] = propertyvalue;
            AutoItX3 auto = new AutoItX3();
            auto.WinActivate("Choose File to Upload");
            auto.Send(text);
            auto.Send("{ENTER}");
            Thread.Sleep(1000);
        }
        public void Click<T>(PropertyType type, string propertyvalue) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });

            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;
            else if (type == PropertyType.InnerText)
            {
                genericControl.SearchProperties[HtmlControl.PropertyNames.InnerText] = propertyvalue;
            }
            else if (type == PropertyType.TagInstance)
                genericControl.FilterProperties[HtmlControl.PropertyNames.TagInstance] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void EnterText<T>(PropertyType type, string propertyvalue, string text) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;

            Keyboard.SendKeys(genericControl, text);

        }
        private BrowserWindow mparentwindow { get; set; }
        public enum PropertyType
        {
            Id,
            Name,
            InnerText,
            TagInstance
        }
        public BrowserWindow TopParentWindow()
        {

            BrowserWindow window = new BrowserWindow();
            window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
            return window;
        }
        public BrowserWindow ParentWindow
        {
            get
            {
                if (this.mparentwindow == null)
                {
                    this.mparentwindow = TopParentWindow();
                }
                return this.mparentwindow;
            }
        }
    }

}
