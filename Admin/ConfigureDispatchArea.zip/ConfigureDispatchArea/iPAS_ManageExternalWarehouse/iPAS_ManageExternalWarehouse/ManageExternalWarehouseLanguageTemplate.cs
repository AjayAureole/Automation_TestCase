﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Text;
using System.Threading.Tasks;

namespace iPAS_ManageExternalWarehouse
{
    class ManageExternalWarehouseLanguageTemplate
    {
        static CultureInfo ci = null;
        static ResourceManager rm = null;
        static string resMsg_AddWarehouseSuccess = string.Empty;
        public string Msg_AddWarehouseSuccess
        {
            get { return resMsg_AddWarehouseSuccess; }
            set { resMsg_AddWarehouseSuccess = value; }
        }

        static string resMsg_WarehouseNameAlreadyExistInGate = string.Empty;
        public string Msg_WarehouseNameAlreadyExistInGate
        {
            get { return resMsg_WarehouseNameAlreadyExistInGate; }
            set { resMsg_WarehouseNameAlreadyExistInGate = value; }
        }

        static string resMsg_UpdateWarehouseSuccess = string.Empty;
        public string Msg_UpdateWarehouseSuccess
        {
            get { return resMsg_UpdateWarehouseSuccess; }
            set { resMsg_UpdateWarehouseSuccess = value; }
        }
        static string resMsg_EnterPlantCode = string.Empty;
        public string Msg_EnterPlantCode
        {
            get { return resMsg_EnterPlantCode; }
            set { resMsg_EnterPlantCode = value; }
        }
        static string resMsg_EnterWarehouseName = string.Empty;
        public string Msg_EnterWarehouseName
        {
            get { return resMsg_EnterWarehouseName; }
            set { resMsg_EnterWarehouseName = value; }
        }
        static string resMsg_EnterDispatchGate = string.Empty;
        public string Msg_EnterDispatchGate
        {
            get { return resMsg_EnterDispatchGate; }
            set { resMsg_EnterDispatchGate = value; }
        }

        public static void messageResource(string languageCode)
        {
            if (languageCode == "zh-CN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ManageExternalWarehouse.resource.ManageExternalWarehouseCN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ManageExternalWarehouse.resource.ManageExternalWarehouseEN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
        }
        public static void messageInitialize()
        {
            resMsg_AddWarehouseSuccess = rm.GetString("resMsg_AddWarehouseSuccess", ci).Trim();
            resMsg_WarehouseNameAlreadyExistInGate = rm.GetString("resMsg_WarehouseNameAlreadyExistInGate", ci).Trim();
            resMsg_UpdateWarehouseSuccess = rm.GetString("resMsg_UpdateWarehouseSuccess", ci).Trim();
            resMsg_EnterPlantCode = rm.GetString("resMsg_EnterPlantCode", ci).Trim();
            resMsg_EnterWarehouseName = rm.GetString("resMsg_EnterWarehouseName", ci).Trim();
            resMsg_EnterDispatchGate = rm.GetString("resMsg_EnterDispatchGate", ci).Trim();
        }
    }
}
