﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Text;
using System.Threading.Tasks;

namespace iPAS_DG_Pictogram
{
    class DGClassInfoLanguageTemplate
    {
        static CultureInfo ci = null;
        static ResourceManager rm = null;
        static string resMsg_DGClassAddedSuccessfully = string.Empty;
        public string Msg_DGClassAddedSuccessfully
        {
            get { return resMsg_DGClassAddedSuccessfully; }
            set { resMsg_DGClassAddedSuccessfully = value; }
        }
        static string resMsg_DGClassUpdatedSuccessfully = string.Empty;
        public string Msg_DGClassUpdatedSuccessfully
        {
            get { return resMsg_DGClassUpdatedSuccessfully; }
            set { resMsg_DGClassUpdatedSuccessfully = value; }
        }
        static string resMsg_NoRecordFound = string.Empty;
        public string Msg_NoRecordFound
        {
            get { return resMsg_NoRecordFound; }
            set { resMsg_NoRecordFound = value; }
        }
        static string resMsgDGClassImageAddedSuccessfully = string.Empty;
        public string MsgDGClassImageAddedSuccessfully
        {
            get { return resMsgDGClassImageAddedSuccessfully; }
            set { resMsgDGClassImageAddedSuccessfully = value; }
        }

        public static void messageResource(string languageCode)
        {
            if (languageCode == "zh-CN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_DG_Pictogram.resources.DGClassInfoResouceCN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "th-TH")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_DG_Pictogram.resources.DGClassInfoResouceTH", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "vi-VN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_DG_Pictogram.resources.DGClassInfoResouceVN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "ko-KR")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_DG_Pictogram.resources.DGClassInfoResouceKR", Assembly.GetExecutingAssembly());
                messageInitialize();
            }           
            else
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_DG_Pictogram.resources.DGClassInfoResouceEN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
        
    }
        public static void messageInitialize()
        {
            resMsg_DGClassAddedSuccessfully = rm.GetString("resMsg_DGClassAddedSuccessfully", ci).Trim();
            resMsg_DGClassUpdatedSuccessfully = rm.GetString("resMsg_DGClassUpdatedSuccessfully", ci).Trim();
            resMsg_NoRecordFound = rm.GetString("resMsg_NoRecordFound", ci).Trim();
            resMsgDGClassImageAddedSuccessfully = rm.GetString("resMsgDGClassImageAddedSuccessfully", ci).Trim();
        }
    }
}
