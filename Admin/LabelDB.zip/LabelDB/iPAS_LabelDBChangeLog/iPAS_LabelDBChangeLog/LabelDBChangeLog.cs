﻿using AutoItX3Lib;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using DataDrivenTesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;

namespace iPAS_LabelDBChangeLog
{
    class LabelDBChangeLog
    {
        string minsleep = ConfigurationSettings.AppSettings["min"];
        string midsleep = ConfigurationSettings.AppSettings["mid"];
        string maxsleep = ConfigurationSettings.AppSettings["max"];

       public void CheckDataAvailability()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "lnkAdmin");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnklabelDb");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkLabelDbChangeLog");
            Thread.Sleep(min);
            auto.MouseClick();
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            /*********Here Clicking on the Calendar Starting Date Text Box******/
            Click<HtmlEdit>(PropertyType.Id, "txtStartDate");
            try
            {
                //Here Select Month of the Calender Box
                EnterText<HtmlComboBox>(PropertyType.Class, "ui-datepicker-month", ExcelDataTable.ReadData(1, "StartMonth"));
             }
            catch (Exception e) { }
            try
            {

                //Here Select Year of the Calender Box
                Click<HtmlComboBox>(PropertyType.Class, "ui-datepicker-year");
                EnterText<HtmlComboBox>(PropertyType.Class, "ui-datepicker-year", ExcelDataTable.ReadData(1, "StartYear"));
                auto.Send("{TAB}");
            }
            catch (Exception e) { }
            try
            {
                // Here Click  the Date 
               Thread.Sleep(min);
               Click<HtmlHyperlink>(PropertyType.InnerText, ExcelDataTable.ReadData(1, "StartDate"));
               Click<HtmlHyperlink>(PropertyType.InnerText, ExcelDataTable.ReadData(1, "StartDate"));
           }
            catch (Exception e) { }
            /*********Here Clicking on the Calendar Ending Date Text Box******/
            Click<HtmlEdit>(PropertyType.Id, "txtEndDate");
            try
            {
                //Here Select Month of the Calender Box
                EnterText<HtmlComboBox>(PropertyType.Class, "ui-datepicker-month", ExcelDataTable.ReadData(1, "EndMonth"));
            }
            catch (Exception e) { }
            try
            {

                //Here Select Year of the Calender Box
                Click<HtmlComboBox>(PropertyType.Class, "ui-datepicker-year");
                //Thread.Sleep(min);
                EnterText<HtmlComboBox>(PropertyType.Class, "ui-datepicker-year", ExcelDataTable.ReadData(1, "EndYear"));
                auto.Send("{TAB}");
            }
            catch (Exception e) { }
            try
            {
                // Here Click  the Date 
                Thread.Sleep(min);
                Click<HtmlHyperlink>(PropertyType.InnerText, ExcelDataTable.ReadData(1, "EndDate"));
                Click<HtmlHyperlink>(PropertyType.InnerText, ExcelDataTable.ReadData(1, "EndDate"));
            }
            catch (Exception e) { }

            try {
                EnterText<HtmlEdit>(PropertyType.Id, "txtMaterial", ExcelDataTable.ReadData(1, "IDH"));

            }catch(Exception e) { }
            Thread.Sleep(min);
            Click<HtmlButton>(PropertyType.Id, "btnSearch");
            Thread.Sleep(mid);
            ////************Here validate on the Search TextBoX Data is Enter or Not**************///
            var data = window.ExecuteScript("var data=document.getElementById('spnSearchError').innerHTML;  return  data");
            string successMsg = data.ToString().Trim();
            if (successMsg!="")
            {
                string screenShotName = "Please_Enter_Criteria";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", successMsg, successMsg);
            Thread.Sleep(min);
            /*****************Here check Data is Availabele or Not*****************/
            bool b1 = SearchNoData();
            if (b1)
            {
                string pagePath = "AdminIndex_LabelDataBase_Label_DatabaseChangeLog";
                screenShot(pagePath);
                Assert.IsFalse(b1, "Data is Not Available");
            }
            Thread.Sleep(max);
            //Click<HtmlCustom>(PropertyType.Id, "showAll");
            //Thread.Sleep(max);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void pageNavigator()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlDiv>(PropertyType.Id, "footer");
            //try
            //{
            //    var pageCount = window.ExecuteScript("var data=document.getElementById('ctl01_divPager').getElementsByTagName('a');  return  data.length");
            //    string len = pageCount.ToString();
            //    int length = Convert.ToInt32(len);
            //    for (int i = 1; i <= length; i++)
            //    {
            //        string tagId = "ctl01_hrefNum" + i;
            //        Thread.Sleep(mid);
            //        if (i == 7)
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");

            Click<HtmlHyperlink>(PropertyType.Id, "ctl01_hrefLast");
            Thread.Sleep(max*2);
            validation();
            //    tagId = "";
            //}
            //}
            //catch (Exception e) { }

        }
        public void validation()
        {
            BrowserWindow window = new BrowserWindow();
            Thread.Sleep(1000);
            var len = window.ExecuteScript("var data=document.getElementById('tbLabelHistoryLog').getElementsByTagName('td');  return  data.length");
            string length = len.ToString().Trim();
            int Data = Convert.ToInt32(length);
            bool flag = true;
            if (Data == 0)
                flag = false;

            string error = "Data is Not there On Last Navigate page";
            if (!flag)
            {
                string pagePath = "DataIsNotThere_LastNavigatePage";
                screenShot(pagePath);
            }
            Assert.IsTrue(flag, error);
        }

        public void screenShot(string imgName)
        {
            BrowserWindow window = new BrowserWindow();
            string path = ConfigurationSettings.AppSettings["ScreenShot"];
            path = path + @"\\iPAS_LabelDBChangeLog";
            Directory.CreateDirectory(path);

            try
            {
                window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
                Image image = window.CaptureImage();
                image.Save(path + "\\" + imgName + ".jpeg", ImageFormat.Jpeg);
                image.Dispose();
            }
            catch (Exception e) { }
            Console.WriteLine("Screen Shot is Avaliable in " + path + "\t" + "Folder");
        }
        public bool SearchNoData()
        {
            BrowserWindow window = new BrowserWindow();
            Thread.Sleep(500);
            var data = window.ExecuteScript("var data=document.getElementById('tbLabelHistoryLog').getElementsByTagName('TD')[0];  return  data.innerHTML");
            string successMsg = data.ToString().Trim();
            bool b1 = successMsg.Equals("No records found");
            return b1;
        }
        public void PathEnterText<T>(PropertyType type, string propertyvalue, string text) where T : WinEdit
        {
            WinEdit genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            genericControl.FilterProperties[WinEdit.PropertyNames.Name] = propertyvalue;
            AutoItX3 auto = new AutoItX3();
            auto.WinActivate("Choose File to Upload");
            auto.Send(text);
            auto.Send("{ENTER}");
            Thread.Sleep(1000);
        }
        public void WindowButtonClick<T>(PropertyType type, string propertyvalue) where T : WinControl
        {
            WinControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Name)
                genericControl.SearchProperties[WinControl.PropertyNames.Name] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void Click<T>(PropertyType type, string propertyvalue) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });

            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;
            else if (type == PropertyType.InnerText)
            {
                genericControl.SearchProperties[HtmlControl.PropertyNames.InnerText] = propertyvalue;
            }
            else if (type == PropertyType.TagInstance)
                genericControl.FilterProperties[HtmlControl.PropertyNames.TagInstance] = propertyvalue;
            else if (type == PropertyType.Class)
            {
                genericControl.FilterProperties[HtmlControl.PropertyNames.Class] = propertyvalue;
            }

            Mouse.Click(genericControl);
        }
        public void EnterText<T>(PropertyType type, string propertyvalue, string text) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;
            else if (type == PropertyType.Class)
                genericControl.FilterProperties[HtmlControl.PropertyNames.Class] = propertyvalue;
           


            Keyboard.SendKeys(genericControl, text);

        }
        private BrowserWindow mparentwindow { get; set; }
        public enum PropertyType
        {
            Id,
            Name,
            InnerText,
            TagInstance,
            Class
        }
        public BrowserWindow TopParentWindow()
        {

            BrowserWindow window = new BrowserWindow();
            window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
            return window;
        }
        public BrowserWindow ParentWindow
        {
            get
            {
                if (this.mparentwindow == null)
                {
                    this.mparentwindow = TopParentWindow();
                }
                return this.mparentwindow;
            }
        }

    }
}
