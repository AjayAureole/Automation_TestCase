﻿using AutoItX3Lib;
using DataDrivenTesting;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace iPAS_GHS_Info2
{
    class DownloaderExcelFile
    {
        string minsleep = ConfigurationSettings.AppSettings["min"];
        string midsleep = ConfigurationSettings.AppSettings["mid"];
        string maxsleep = ConfigurationSettings.AppSettings["max"];
        public void downloadTemplate()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            mparentwindow = null;
            //auto.Send("{F5}");
            Thread.Sleep(min);
            try
            {

                Click<HtmlSpan>(PropertyType.InnerText, "GHS Information");
            }
            catch (Exception e)
            {
                Click<HtmlSpan>(PropertyType.InnerText, "GHS Information");
            }
            Thread.Sleep(min);
            int xCoodinate = auto.MouseGetPosX();
            int yCoodinate = auto.MouseGetPosY();
            xCoodinate = xCoodinate - 270;
            auto.MouseMove(xCoodinate, yCoodinate);
            yCoodinate = yCoodinate + 90;
            auto.MouseMove(xCoodinate, yCoodinate);
            auto.MouseClick();
            Click<HtmlHyperlink>(PropertyType.Id, "btnDownloadTemplate");
            Thread.Sleep(max * 7);
            Click<HtmlDiv>(PropertyType.Id, "footer");
            try {
                WindowButtonClick<WinToolBar>(PropertyType.Name, "Notification");
                WindowButtonClick<WinButton>(PropertyType.Name, "Open");
            }catch(Exception e) { }
            mparentwindow = null;
            Thread.Sleep(max * 10);
            auto.WinClose("Microsoft Excel");
            auto.WinClose("Excel");
            Thread.Sleep(min);
        }
        public void DownloadAllHCodes()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            mparentwindow = null;
            Thread.Sleep(min);
            try
            {

                Click<HtmlSpan>(PropertyType.InnerText, "GHS Information");
            }
            catch (Exception e)
            {
                Click<HtmlSpan>(PropertyType.InnerText, "GHS Information");
            }
            Thread.Sleep(min);
            int xCoodinate = auto.MouseGetPosX();
            int yCoodinate = auto.MouseGetPosY();
            xCoodinate = xCoodinate - 270;
            auto.MouseMove(xCoodinate, yCoodinate);
            yCoodinate = yCoodinate + 90;
            auto.MouseMove(xCoodinate, yCoodinate);
            auto.MouseClick();

            Click<HtmlCustom>(PropertyType.Id, "ContentPlaceHolder1_btnDownloadHCode");
            Thread.Sleep(max * 8);
            Click<HtmlDiv>(PropertyType.Id, "footer");
            try {
                WindowButtonClick<WinToolBar>(PropertyType.Name, "Notification");
                WindowButtonClick<WinButton>(PropertyType.Name, "Open");
            }catch(Exception e) { }
            mparentwindow = null;
            Thread.Sleep(max * 18);
            auto.WinClose("Microsoft Excel");
            auto.WinClose("Excel");
            Thread.Sleep(max);
            auto.Send("{F5}");
            Thread.Sleep(max);
        }
        public void pageNavigator()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep); 
            auto.Send("{F5}");
            Thread.Sleep(mid*2);
            try
            {
                Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnShowAll");
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlInputButton>(PropertyType.Id, "txtSearch");
                auto.Send("{F5}");
                Thread.Sleep(max);
                Click<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpLanguage");
                EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpLanguage", ExcelDataTable.ReadData(1, "UpLan1"));
            }
            catch(Exception e) { }
            
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);
            Click<HtmlDiv>(PropertyType.Id, "footer");
            //try
            //{
            //    var pageCount = window.ExecuteScript("var data=document.getElementById('ctl01_divPager').getElementsByTagName('a');  return  data.length");
            //    string len = pageCount.ToString();
            //    int length = Convert.ToInt32(len);
            //    for (int i = 1; i <= length; i++)
            //    {
            //        string tagId = "ctl01_hrefNum" + i;
            //        Thread.Sleep(mid);
            //        if (i == 7)
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Click<HtmlHyperlink>(PropertyType.Id, "pagerControl_hrefLast");
            Thread.Sleep(max*2);
            validation();
            Thread.Sleep(min);
            //    tagId = "";
            //}
            //}
            //catch (Exception e) { }
            auto.Send("{F5}");
            Thread.Sleep(min);
        }

        public void validation()
        {
            BrowserWindow window = new BrowserWindow();
            Thread.Sleep(1000);
            var len = window.ExecuteScript("var data=document.getElementById('tbHCodeBody').getElementsByTagName('td');  return  data.length");
            string length = len.ToString().Trim();
            int Data = Convert.ToInt32(length);
            bool flag = true;
            if (Data == 0)
                flag = false;

            string error = "Data is Not there On Last Navigate page";
            if (!flag)
            {
                string screenShotName = "DataIsNotThere_LastNavigatePage";
                screenShot(screenShotName);
            }

            Assert.IsTrue(flag, error);
        }
        public void screenShot(string imgName)
        {
            BrowserWindow window = new BrowserWindow();
            string path = ConfigurationSettings.AppSettings["ScreenShot"];
            path = path + @"\\iPAS_GHS_Info2";
            Directory.CreateDirectory(path);

            try
            {
                window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
                Image image = window.CaptureImage();
                image.Save(path + "\\" + imgName + ".jpeg", ImageFormat.Jpeg);
                image.Dispose();
            }
            catch (Exception e) { }
            Console.WriteLine("Screen Shot is Avaliable in " + path + "\t" + "Folder");
        }

        public bool SearchNoData()
        {
            BrowserWindow window = new BrowserWindow();

            var data = window.ExecuteScript("var data=document.getElementById('ContentPlaceHolder1_tbPrecautionaryBody').innerHTML;  return  data");
            string successMsg = data.ToString();
            bool b1 = successMsg.Contains("No records found");
            return b1;
        }
        public void WindowButtonClick<T>(PropertyType type, string propertyvalue) where T : WinControl
        {
            WinControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Name)
                genericControl.SearchProperties[WinControl.PropertyNames.Name] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void PathEnterText<T>(PropertyType type, string propertyvalue, string text) where T : WinEdit
        {
            WinEdit genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            genericControl.FilterProperties[WinEdit.PropertyNames.Name] = propertyvalue;
            AutoItX3 auto = new AutoItX3();
            auto.WinActivate("Choose File to Upload");
            auto.Send(text);
            auto.Send("{ENTER}");
            Thread.Sleep(1000);
        }
        public void Click<T>(PropertyType type, string propertyvalue) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });

            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;
            else if (type == PropertyType.InnerText)
            {
                genericControl.SearchProperties[HtmlControl.PropertyNames.InnerText] = propertyvalue;
            }
            else if (type == PropertyType.TagInstance)
                genericControl.FilterProperties[HtmlControl.PropertyNames.TagInstance] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void EnterText<T>(PropertyType type, string propertyvalue, string text) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;

            Keyboard.SendKeys(genericControl, text);

        }
        private BrowserWindow mparentwindow { get; set; }
        public enum PropertyType
        {
            Id,
            Name,
            InnerText,
            TagInstance
        }
        public BrowserWindow TopParentWindow()
        {

            BrowserWindow window = new BrowserWindow();
            window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
            return window;
        }
        public BrowserWindow ParentWindow
        {
            get
            {
                if (this.mparentwindow == null)
                {
                    this.mparentwindow = TopParentWindow();
                }
                return this.mparentwindow;
            }
        }

    }
}
