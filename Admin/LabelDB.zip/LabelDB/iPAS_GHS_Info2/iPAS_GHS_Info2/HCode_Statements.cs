﻿using AutoItX3Lib;
using DataDrivenTesting;
using iPAS_GHS_Info2;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace iPAS_GHS_Info
{
    class HCode_Statements
    {
        string minsleep = ConfigurationSettings.AppSettings["min"];
        string midsleep = ConfigurationSettings.AppSettings["mid"];
        string maxsleep = ConfigurationSettings.AppSettings["max"];
        public void UploadExcelHCodeInfo()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            //auto.Send("{F5}");
            Thread.Sleep(min);
            Click<HtmlHyperlink>(PropertyType.Id, "manageGHSCodeLink");
            // auto.Send("{F5}");
            mparentwindow = null;
            Thread.Sleep(max);
            /*Here Checking how Many record is there befor add */

            //var totalbefore = window.ExecuteScript("var data=document.getElementById('spnTotalRecords').innerHTML;  return  data");
            //string tot = totalbefore.ToString().Trim();
            //int totalbeforerecord = Convert.ToInt32(totalbefore);

            try
            {

                Click<HtmlSpan>(PropertyType.InnerText, "GHS Information");
            }
            catch (Exception e)
            {
                Click<HtmlSpan>(PropertyType.InnerText, "GHS Information");
            }
            Thread.Sleep(min);
            int xCoodinate = auto.MouseGetPosX();
            int yCoodinate = auto.MouseGetPosY();
            xCoodinate = xCoodinate - 270;
            auto.MouseMove(xCoodinate, yCoodinate);
            yCoodinate = yCoodinate + 90;
            auto.MouseMove(xCoodinate, yCoodinate);
            auto.MouseClick();

            Click<HtmlCustom>(PropertyType.Id, "btnUploadData");
            Click<HtmlFileInput>(PropertyType.Id, "ContentPlaceHolder1_uploadFile");
            PathEnterText<WinEdit>(PropertyType.Name, "File name:", ExcelDataTable.ReadData(1, "HCodeFilePath"));
            Thread.Sleep(mid*2);
            var data1 = window.ExecuteScript("var data=document.getElementById('lblUploadError').innerHTML;  return  data");
            string successMsg1 = data1.ToString().Trim();
            if (successMsg1!="")
            {
                string screenShotName = "FileUploading_Error";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", successMsg1, successMsg1);
            Thread.Sleep(mid*2);
            auto.Send("{F5}");
            Thread.Sleep(max*2);
            //var afterTotal = window.ExecuteScript("var data=document.getElementById('spnTotalRecords').innerHTML;  return  data");
            //string afterTot = afterTotal.ToString().Trim();
            //int afterTotalRecords = Convert.ToInt32(afterTot);
            //totalbeforerecord = totalbeforerecord + 1;
            //Thread.Sleep(mid);
            //if (afterTotalRecords != totalbeforerecord)
            //{
            //    string screenShotName = "afterTotalRecords_NotProper";
            //    screenShot(screenShotName);
            //}
            //Assert.AreEqual(afterTotalRecords, totalbeforerecord, "Total Record value Not Proper");
            //Thread.Sleep(min);
        }
        public void searchAndDeleteHCodeInfo()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            auto.Send("{F5}");
            Thread.Sleep(min);
            EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpLanguage", ExcelDataTable.ReadData(1, "Lan1"));
            Thread.Sleep(min);
            try {
                EnterText<HtmlEdit>(PropertyType.Id, "txtSearchHCodeKey", ExcelDataTable.ReadData(1, "HCode Key"));
            }catch(Exception e) { }
            Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearch");
            Thread.Sleep(mid*2);

            ////************Here validate on the Search TextBoX Data is Enter or Not**************///
            var data1 = window.ExecuteScript("var data=document.getElementById('spnSearchError').innerHTML;  return  data");
            string successMsg1 = data1.ToString().Trim();
            if (successMsg1 != "")
            {
                string screenShotName = "Please_EnterCriteria";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", successMsg1, successMsg1);

            /*************Here search and click Delete Button to Delete the HCode info Details*******/

            // string id = "ctl01_btnDelete";
            // id = "'" + id + "'";
            // Thread.Sleep(mid);
            // var xCoodinate = window.ExecuteScript("var data1=document.getElementById(" + id + "); var rect = data1.getBoundingClientRect(); return  rect.left");
            // var yCoodinate = window.ExecuteScript("var data1=document.getElementById(" + id + "); var rect = data1.getBoundingClientRect(); return  rect.top");

            // string x = xCoodinate.ToString();
            // string y = yCoodinate.ToString();
            // double x1 = Convert.ToDouble(x);
            // double y1 = Convert.ToDouble(y);
            // int Xco = Convert.ToInt32(x1);
            // int Yco = Convert.ToInt32(y1);
            // //Make sure Browser Window is Maximize
            // // Xco = Xco;
            // Yco = Yco + 60;
            // auto.MouseMove(Xco, Yco);
            // auto.MouseClick();
            // Thread.Sleep(min);
            // auto.Send("{ENTER}");
            //// auto.Send("{F5}");
            // Thread.Sleep(min);

            Click<HtmlSpan>(PropertyType.InnerText, ExcelDataTable.ReadData(1, "HCode Key"));
            int Mx2 = auto.MouseGetPosX();
            int My2 = auto.MouseGetPosY();
            Mx2 = Mx2 - 60;
            My2 = My2 - 3;
            Thread.Sleep(max);
            auto.MouseMove(Mx2, My2);
            auto.MouseClick();
            Thread.Sleep(min);
            mparentwindow = null;
            Click<HtmlButton>(PropertyType.InnerText, "Confirm");

           // auto.Send("{ENTER}");
            Thread.Sleep(min);
        }
        public void addHCodeStatementsInfoManually()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(max);
            auto.Send("{F5}");
            Thread.Sleep(min);
            
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtHCodeKey", ExcelDataTable.ReadData(1, "Hcode_Key"));
            }
            catch (Exception e) { }
                try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtHCode", ExcelDataTable.ReadData(1, "Hcode"));
             }catch (Exception e) { }
                try
                {
                EnterText<HtmlEdit>(PropertyType.Id, "txtClass", ExcelDataTable.ReadData(1, "Class"));
                }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtCategory", ExcelDataTable.ReadData(1, "Category"));
             }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlComboBox>(PropertyType.Id, "ucPrecautionStatementControl_1_drpLanguages", ExcelDataTable.ReadData(1, "Lan1"));
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlTextArea>(PropertyType.Id, "ucPrecautionStatementControl_1_txtPrecautionStatement", ExcelDataTable.ReadData(1, "Precaution1"));
            }
            catch (Exception e) { }
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            try
            {
                EnterText<HtmlComboBox>(PropertyType.Id, "ucPrecautionStatementControl_2_drpLanguages", ExcelDataTable.ReadData(1, "Lan2"));
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlTextArea>(PropertyType.Id, "ucPrecautionStatementControl_2_txtPrecautionStatement", ExcelDataTable.ReadData(1, "Precaution2"));
             }
            catch (Exception e) { }
            Thread.Sleep(max);
            /*******************Here Click Add More Button *******************/
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            mparentwindow = null;
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnAddMore");
            mparentwindow = null;
            Thread.Sleep(min);
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            try
            {
            EnterText<HtmlComboBox>(PropertyType.Id, "ucPrecautionStatementControl_3_drpLanguages", ExcelDataTable.ReadData(1, "Lan3"));
            }
            catch (Exception e) { }
            try
            {
            EnterText<HtmlTextArea>(PropertyType.Id, "ucPrecautionStatementControl_3_txtPrecautionStatement", ExcelDataTable.ReadData(1, "Precaution3"));
             }catch (Exception e) { }
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnAdd");
            Thread.Sleep(mid);
            ////************Here validate HCode is added or Not**************///
            var data1 = window.ExecuteScript("var data=document.getElementById('spnHCodeError').innerHTML;  return  data");
            string successMsg1 = data1.ToString().Trim();
            if (successMsg1 != "HCode information added successfully")
            {
                string screenShotName = "HCodeIs_NotAddded";
                screenShot(screenShotName);
            }
            Assert.AreEqual("HCode information added successfully", successMsg1, successMsg1);
            Thread.Sleep(min);
        }
        public void UpdateHCodeInfoManually()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            auto.Send("{F5}");
            Thread.Sleep(max);
            EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpLanguage", ExcelDataTable.ReadData(1, "Lan1"));
            Thread.Sleep(min);
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtSearchHCodeKey", ExcelDataTable.ReadData(1, "Hcode_Key"));
            }
            catch (Exception e) { }
            Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearch");
            Thread.Sleep(mid);

            ////************Here validate on the Search TextBoX Data is Enter or Not**************///
            var data1 = window.ExecuteScript("var data=document.getElementById('spnSearchError').innerHTML;  return  data");
            string successMsg1 = data1.ToString().Trim();
            if (successMsg1 != "")
            {
                string screenShotName = "PleaseEnter_Criteria";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", successMsg1, successMsg1);

            /*************Here search and click Delete Button to Delete the HCode info Details*******/

            //string id = "ctl01_btnEdit"; 
            // id = "'" + id + "'";
            //Thread.Sleep(mid);
            //var xCoodinate = window.ExecuteScript("var data1=document.getElementById(" + id + "); var rect = data1.getBoundingClientRect(); return  rect.left");
            //var yCoodinate = window.ExecuteScript("var data1=document.getElementById(" + id + "); var rect = data1.getBoundingClientRect(); return  rect.top");

            //string x = xCoodinate.ToString();
            //string y = yCoodinate.ToString();
            //double x1 = Convert.ToDouble(x);
            //double y1 = Convert.ToDouble(y);
            //int Xco = Convert.ToInt32(x1);
            //int Yco = Convert.ToInt32(y1);
            ////Make sure Browser Window is Maximize
            //// Xco = Xco;
            //Yco = Yco + 45;
            //auto.MouseMove(Xco, Yco);
            //auto.MouseClick();
            //Thread.Sleep(min);

            Click<HtmlSpan>(PropertyType.InnerText, ExcelDataTable.ReadData(1, "Hcode_Key"));
            int Mx2 = auto.MouseGetPosX();
            int My2 = auto.MouseGetPosY();
            Mx2 = Mx2 - 100;
            My2 = My2 - 3;
            Thread.Sleep(max);
            auto.MouseMove(Mx2, My2);
            auto.MouseClick();
            Thread.Sleep(min);
          
            /*********************Here Update the Data*****************/
            try {
                try
                {
                    Click<HtmlEdit>(PropertyType.Id, "txtHCodeKey");
                    auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                    auto.Send("{DEL 20}");
                    EnterText<HtmlEdit>(PropertyType.Id, "txtHCodeKey", ExcelDataTable.ReadData(1, "UpHcode_Key"));
                }
                catch (Exception e) { }
                try
                {
                    Click<HtmlEdit>(PropertyType.Id, "txtHCode");
                    auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                    auto.Send("{DEL 20}");
                    Thread.Sleep(min);
                    EnterText<HtmlEdit>(PropertyType.Id, "txtHCode", ExcelDataTable.ReadData(1, "UpHcode"));
                }
                catch (Exception e) { }
                try
                {
                    Click<HtmlEdit>(PropertyType.Id, "txtClass");
                    auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                    auto.Send("{DEL 20}");
                    Thread.Sleep(min);
                    EnterText<HtmlEdit>(PropertyType.Id, "txtClass", ExcelDataTable.ReadData(1, "UpClass"));
                }
                catch (Exception e) { }
                try
                {
                    Click<HtmlEdit>(PropertyType.Id, "txtCategory");
                    auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                    auto.Send("{DEL 20}");
                    Thread.Sleep(min);
                    EnterText<HtmlEdit>(PropertyType.Id, "txtCategory", ExcelDataTable.ReadData(1, "UpCategory"));
                }
                catch (Exception e) { }
                try
                {
                    EnterText<HtmlComboBox>(PropertyType.Id, "ucHStatementSummary_1_drpLanguages", ExcelDataTable.ReadData(1, "UpLan1"));
                }
                catch (Exception e) { }
                try
                {
                    Click<HtmlTextArea>(PropertyType.Id, "ucHStatementSummary_1_txtPrecautionStatement");
                    auto.Send("{BACKSPACE 40}");//Existing Data Deletion
                    auto.Send("{DEL 40}");
                    Thread.Sleep(min);
                    EnterText<HtmlTextArea>(PropertyType.Id, "ucHStatementSummary_1_txtPrecautionStatement", ExcelDataTable.ReadData(1, "UpPrecaution1"));
                }
                catch (Exception e) { }
                Thread.Sleep(min);
                auto.Send("{Down}");
                Thread.Sleep(min);
                auto.Send("{Down}");
                try
                {
                    EnterText<HtmlComboBox>(PropertyType.Id, "ucHStatementSummary_5_drpLanguages", ExcelDataTable.ReadData(1, "UpLan2"));
                }
                catch (Exception e) { }
                Thread.Sleep(min);
                auto.Send("{Down}");
                Thread.Sleep(min);
                auto.Send("{Down}");
                try
                {
                    Click<HtmlTextArea>(PropertyType.Id, "ucHStatementSummary_5_txtPrecautionStatement");
                    auto.Send("{BACKSPACE 40}");//Existing Data Deletion
                    auto.Send("{DEL 40}");
                    Thread.Sleep(min);
                    EnterText<HtmlTextArea>(PropertyType.Id, "ucHStatementSummary_5_txtPrecautionStatement", ExcelDataTable.ReadData(1, "UpPrecaution2"));
                }
                catch (Exception e) { }
                Thread.Sleep(min);
                auto.Send("{Down}");
                Thread.Sleep(min);
                auto.Send("{Down}");
                try
                {
                    EnterText<HtmlComboBox>(PropertyType.Id, "ucHStatementSummary_23_drpLanguages", ExcelDataTable.ReadData(1, "UpLan3"));
                }
                catch (Exception e) { }
                Thread.Sleep(min);
                auto.Send("{Down}");
                Thread.Sleep(min);
                auto.Send("{Down}");
                try
                {
                    Click<HtmlTextArea>(PropertyType.Id, "ucHStatementSummary_23_txtPrecautionStatement");
                    auto.Send("{BACKSPACE 40}");//Existing Data Deletion
                    auto.Send("{DEL 40}");
                    Thread.Sleep(min);
                    EnterText<HtmlTextArea>(PropertyType.Id, "ucHStatementSummary_23_txtPrecautionStatement", ExcelDataTable.ReadData(1, "UpPrecaution3"));
                }
                catch (Exception e) { }
                /*******************Here Click Add More Button *******************/
                Thread.Sleep(min);
                auto.Send("{Down}");
                Thread.Sleep(min);
                Click<HtmlDiv>(PropertyType.Id,"footer");
                Thread.Sleep(min);
                auto.Send("{Down}");
                Thread.Sleep(min);
                auto.Send("{Down}");
                Thread.Sleep(min);
                mparentwindow = null;
                Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnAddMore");
                Thread.Sleep(min);
                auto.Send("{Down}");
                Click<HtmlDiv>(PropertyType.Id, "footer");
                Thread.Sleep(min);
                auto.Send("{Down}");
                Thread.Sleep(min);
                auto.Send("{Down}");
                Thread.Sleep(min);
                auto.Send("{Down}");
                Thread.Sleep(min);
                auto.Send("{Down}");
                mparentwindow = null;
                Thread.Sleep(min);
                try
                {
                    EnterText<HtmlComboBox>(PropertyType.Id, "ucPrecautionStatementControl_2_drpLanguages", ExcelDataTable.ReadData(1, ""));
                } catch (Exception e) { }
                try
                {
                    EnterText<HtmlTextArea>(PropertyType.Id, "ucPrecautionStatementControl_2_txtPrecautionStatement", ExcelDataTable.ReadData(1, "UpPrecaution3"));

                } catch (Exception e) { }
            }catch(Exception ex) { }
            Thread.Sleep(min);
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnAdd");
            Thread.Sleep(mid);
            ////************Here validate HCode is Updating or Not**************///
            var data = window.ExecuteScript("var data=document.getElementById('spnHCodeError').innerHTML;  return  data");
            string successMsg = data.ToString().Trim();
            if (successMsg1 != "HCode information updated successfully")
            {
                string screenShotName = "HCode_NotUpdate";
                screenShot(screenShotName);
            }
            Assert.AreEqual("HCode information updated successfully", successMsg, successMsg);
            Thread.Sleep(min);
        }
        public void searchAndDeleteHCodeInfoManually()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            auto.Send("{F5}");
            Thread.Sleep(min);
            EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpLanguage", ExcelDataTable.ReadData(1, "UpLan1"));
            Thread.Sleep(min);
            try
            {
                
                EnterText<HtmlEdit>(PropertyType.Id, "txtSearchHCodeKey", ExcelDataTable.ReadData(1, "UpHcode_Key"));
            }
            catch (Exception e) { }
            Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearch");
            Thread.Sleep(mid);

            ////************Here validate on the Search TextBoX Data is Enter or Not**************///
            var data1 = window.ExecuteScript("var data=document.getElementById('spnSearchError').innerHTML;  return  data");
            string successMsg1 = data1.ToString().Trim();
            if (successMsg1 != "")
            {
                string screenShotName = "PleaseEnterCriteria";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", successMsg1, successMsg1);

            /*************Here search and click Delete Button to Delete the HCode info Details*******/

            //string id = "ctl01_btnDelete";
            //id = "'" + id + "'";
            //Thread.Sleep(mid);
            //var xCoodinate = window.ExecuteScript("var data1=document.getElementById(" + id + "); var rect = data1.getBoundingClientRect(); return  rect.left");
            //var yCoodinate = window.ExecuteScript("var data1=document.getElementById(" + id + "); var rect = data1.getBoundingClientRect(); return  rect.top");

            //string x = xCoodinate.ToString();
            //string y = yCoodinate.ToString();
            //double x1 = Convert.ToDouble(x);
            //double y1 = Convert.ToDouble(y);
            //int Xco = Convert.ToInt32(x1);
            //int Yco = Convert.ToInt32(y1);
            ////Make sure Browser Window is Maximize
            //// Xco = Xco;
            //Yco = Yco + 60;
            //auto.MouseMove(Xco, Yco);
            //auto.MouseClick();
            //Thread.Sleep(min);
            //auto.Send("{ENTER}");
            //auto.Send("{F5}");

            Thread.Sleep(min);
            mparentwindow = null;
            Click<HtmlSpan>(PropertyType.InnerText, ExcelDataTable.ReadData(1, "UpHcode_Key"));
            int Mx2 = auto.MouseGetPosX();
            int My2 = auto.MouseGetPosY();
            Mx2 = Mx2 - 60;
            My2 = My2 - 3;
            Thread.Sleep(max);
            auto.MouseMove(Mx2, My2);
            auto.MouseClick();
            Thread.Sleep(min);
            mparentwindow = null;
            Click<HtmlButton>(PropertyType.InnerText, "Confirm");
           // auto.Send("{ENTER}");
            Thread.Sleep(min);
        }
        public bool SearchNoData()
        {
            BrowserWindow window = new BrowserWindow();

            var data = window.ExecuteScript("var data=document.getElementById('ContentPlaceHolder1_tbPrecautionaryBody').innerHTML;  return  data");
            string successMsg = data.ToString();
            /*Here use singalWord language Resouce key*/
            bool b1 = successMsg.Contains(SignalWordLanguageTemplate.Msg_NoRecordsFound);
            return b1;
        }
        public void screenShot(string imgName)
        {
            BrowserWindow window = new BrowserWindow();
            string path = ConfigurationSettings.AppSettings["ScreenShot"];
            path = path + @"\\iPAS_GHS_Info2";
            Directory.CreateDirectory(path);

            try
            {
                window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
                Image image = window.CaptureImage();
                image.Save(path + "\\" + imgName + ".jpeg", ImageFormat.Jpeg);
                image.Dispose();
            }
            catch (Exception e) { }
            Console.WriteLine("Screen Shot is Avaliable in " + path + "\t" + "Folder");
        }
        public void WindowButtonClick<T>(PropertyType type, string propertyvalue) where T : WinControl
        {
            WinControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Name)
                genericControl.SearchProperties[WinControl.PropertyNames.Name] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void PathEnterText<T>(PropertyType type, string propertyvalue, string text) where T : WinEdit
        {
            WinEdit genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            genericControl.FilterProperties[WinEdit.PropertyNames.Name] = propertyvalue;
            AutoItX3 auto = new AutoItX3();
            auto.WinActivate("Choose File to Upload");
            auto.Send(text);
            auto.Send("{ENTER}");
            Thread.Sleep(1000);
        }
        public void Click<T>(PropertyType type, string propertyvalue) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });

            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;
            else if (type == PropertyType.InnerText)
            {
                genericControl.SearchProperties[HtmlControl.PropertyNames.InnerText] = propertyvalue;
            }
            else if (type == PropertyType.TagInstance)
                genericControl.FilterProperties[HtmlControl.PropertyNames.TagInstance] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void EnterText<T>(PropertyType type, string propertyvalue, string text) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;

            Keyboard.SendKeys(genericControl, text);

        }
        private BrowserWindow mparentwindow { get; set; }
        public enum PropertyType
        {
            Id,
            Name,
            InnerText,
            TagInstance
        }
        public BrowserWindow TopParentWindow()
        {

            BrowserWindow window = new BrowserWindow();
            window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
            return window;
        }
        public BrowserWindow ParentWindow
        {
            get
            {
                if (this.mparentwindow == null)
                {
                    this.mparentwindow = TopParentWindow();
                }
                return this.mparentwindow;
            }
        }
    }
}
