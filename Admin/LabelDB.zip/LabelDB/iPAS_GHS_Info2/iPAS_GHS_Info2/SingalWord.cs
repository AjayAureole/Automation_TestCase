﻿using AutoItX3Lib;
using DataDrivenTesting;
using iPAS_GHS_Info2;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace iPAS_GHS_Info
{
    class SingalWord
    {
        string minsleep = ConfigurationSettings.AppSettings["min"];
        string midsleep = ConfigurationSettings.AppSettings["mid"];
        string maxsleep = ConfigurationSettings.AppSettings["max"];
        SignalWordLanguageTemplate languageResouce = new SignalWordLanguageTemplate();

        public void addSignalWord()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            auto.Send("{F5}");
            Thread.Sleep(min);
            Click<HtmlHyperlink>(PropertyType.Id, "lnkAdmin");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnklabelDb");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkHazardInfo");
            auto.MouseClick();
            Thread.Sleep(min);
            Click<HtmlHyperlink>(PropertyType.Id, "SignaWordlLink");
            // auto.Send("{F5}");
            mparentwindow = null;
            Thread.Sleep(mid*2);

            /*Here Checking how Many record is there befor add */

            //var totalbefore = window.ExecuteScript("var data=document.getElementById('spnTotalRecords').innerHTML;  return  data");
            //string tot = totalbefore.ToString().Trim();
            //int totalbeforerecord = Convert.ToInt32(totalbefore);

            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtSignalWord", ExcelDataTable.ReadData(1, "Signal_Word"));
             }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpPriority", ExcelDataTable.ReadData(1, "Priority"));
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlComboBox>(PropertyType.Id, "ucPrecautionStatementControl_1_drpLanguages", ExcelDataTable.ReadData(1, "Lang1"));
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlTextArea>(PropertyType.Id, "ucPrecautionStatementControl_1_txtPrecautionStatement", ExcelDataTable.ReadData(1, "PrecautionSt1"));
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlComboBox>(PropertyType.Id, "ucPrecautionStatementControl_2_drpLanguages", ExcelDataTable.ReadData(1, "Lang2"));
           }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlTextArea>(PropertyType.Id, "ucPrecautionStatementControl_2_txtPrecautionStatement", ExcelDataTable.ReadData(1, "PrecautionSt2"));
            }
            catch (Exception e) { }
            /*****************Her clicking Add more Button**********************/
            mparentwindow = null;
            Thread.Sleep(min);
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnAddMore");
            mparentwindow = null;
            try
            {
                EnterText<HtmlComboBox>(PropertyType.Id, "ucPrecautionStatementControl_3_drpLanguages", ExcelDataTable.ReadData(1, "Lang3"));
             }
            catch (Exception e) { }
            try
            {

            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlTextArea>(PropertyType.Id, "ucPrecautionStatementControl_3_txtPrecautionStatement", ExcelDataTable.ReadData(1, "PrecautionSt3"));
            }
            catch (Exception e) { }
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnAddSignalWord");
            Thread.Sleep(max*2);
            ////************ Here Validation Signal word is added successfully or Not **************///
            var data = window.ExecuteScript("var data=document.getElementById('spnSignalWordError').innerHTML;  return  data");
            string successMsg = data.ToString().Trim();
            string str = languageResouce.Msg_SignalWordAddedSuccessfully;
            if (languageResouce.Msg_SignalWordAddedSuccessfully!= successMsg)
            {
                string screenShotName = "SignalWord_NotAddedSuccessfully";
                screenShot(screenShotName);
            }
            Assert.AreEqual(languageResouce.Msg_SignalWordAddedSuccessfully, successMsg, successMsg);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max*3);            
            //var afterTotal = window.ExecuteScript("var data=document.getElementById('spnTotalRecords').innerHTML;  return  data");
            //string afterTot = afterTotal.ToString().Trim();
            //int afterTotalRecords = Convert.ToInt32(afterTot);
            //totalbeforerecord = totalbeforerecord + 1;
            //Thread.Sleep(mid);
            //if (afterTotalRecords != totalbeforerecord)
            //{
            //    string screenShotName = "afterTotalRecords_NotProper";
            //    screenShot(screenShotName);
            //}
            //Assert.AreEqual(afterTotalRecords, totalbeforerecord, "Total Record value Not Proper");
            //Thread.Sleep(min);
        }
        public void updateSignalWord()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            //auto.Send("{F5}");
            //Thread.Sleep(mid);
            /****************Here search ythe Data using Visible Data**********/
            Click<HtmlSpan>(PropertyType.InnerText,ExcelDataTable.ReadData(1, "Signal_Word"));
            int Mx2 = auto.MouseGetPosX();
            int My2 = auto.MouseGetPosY();
            Mx2 = Mx2 - 70;
            My2 = My2 - 3;
            Thread.Sleep(max);
            auto.MouseMove(Mx2, My2);
            auto.MouseClick();
            Thread.Sleep(min);
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "txtSignalWord");
                auto.Send("{BACKSPACE 20}");
                auto.Send("{DEL 20}");
                EnterText<HtmlEdit>(PropertyType.Id, "txtSignalWord", ExcelDataTable.ReadData(1, "UpSignal_Word"));

            }
            catch (Exception e) { }
            try
            {
                
                EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpPriority", ExcelDataTable.ReadData(1, "UpPriority"));

            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlComboBox>(PropertyType.Id, "ucSiganlWordDescriptionDetail0_drpLanguages", ExcelDataTable.ReadData(1, "UpLang1"));

            }
            catch (Exception e) { }
            try
            {
                Click<HtmlTextArea>(PropertyType.Id, "ucSiganlWordDescriptionDetail0_txtPrecautionStatement");
                auto.Send("{BACKSPACE 20}");
                auto.Send("{DEL 20}");
                EnterText<HtmlTextArea>(PropertyType.Id, "ucSiganlWordDescriptionDetail0_txtPrecautionStatement", ExcelDataTable.ReadData(1, "UpPrecautionSt1"));

            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlComboBox>(PropertyType.Id, "ucSiganlWordDescriptionDetail1_drpLanguages", ExcelDataTable.ReadData(1, "UpLang2"));

            }
            catch (Exception e) { }
            try
            {
                Click<HtmlTextArea>(PropertyType.Id, "ucSiganlWordDescriptionDetail1_txtPrecautionStatement");
                auto.Send("{BACKSPACE 30}");
                auto.Send("{DEL 30}");
                EnterText<HtmlTextArea>(PropertyType.Id, "ucSiganlWordDescriptionDetail1_txtPrecautionStatement", ExcelDataTable.ReadData(1, "UpPrecautionSt2"));

            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlComboBox>(PropertyType.Id, "ucSiganlWordDescriptionDetail2_drpLanguages", ExcelDataTable.ReadData(1, "UpLang3"));

            }
            catch (Exception e) { }
            try
            {
                Click<HtmlTextArea>(PropertyType.Id, "ucSiganlWordDescriptionDetail2_txtPrecautionStatement");
                auto.Send("{BACKSPACE 30}");
                auto.Send("{DEL 30}");
                EnterText<HtmlTextArea>(PropertyType.Id, "ucSiganlWordDescriptionDetail2_txtPrecautionStatement", ExcelDataTable.ReadData(1, "UpPrecautionSt3"));

            }
            catch (Exception e) { }

            /****************Here Clicking Add more Button**************************/
            Thread.Sleep(min);
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnAddMore");
            mparentwindow = null;
            try
            {
                EnterText<HtmlComboBox>(PropertyType.Id, "ucPrecautionStatementControl_4_drpLanguages", ExcelDataTable.ReadData(1, "UpLang4"));

            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlTextArea>(PropertyType.Id, "ucPrecautionStatementControl_4_txtPrecautionStatement", ExcelDataTable.ReadData(1, "UpPrecautionSt4"));

            }
            catch (Exception e) { }
            Thread.Sleep(min);
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnAddSignalWord");
            Thread.Sleep(mid);

            /***********************Here validate Signal word is updated successfully or Not****************/
            var data = window.ExecuteScript("var data=document.getElementById('spnSignalWordError').innerHTML;  return  data");
            string successMsg = data.ToString().Trim();
            Thread.Sleep(min);
            if (languageResouce.Msg_SignalWordUpdateSuccess != successMsg)
            {
                string screenShotName = "SignalWord_NotUpdateSuccess";
                screenShot(screenShotName);
            }
            Assert.AreEqual(languageResouce.Msg_SignalWordUpdateSuccess, successMsg, successMsg);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(min);
        }
        public void deleteSingalWord()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            //auto.Send("{F5}");
            //Thread.Sleep(mid);

            Click<HtmlSpan>(PropertyType.InnerText, ExcelDataTable.ReadData(1, "UpSignal_Word"));
            int Mx2 = auto.MouseGetPosX();
            int My2 = auto.MouseGetPosY();
            Mx2 = Mx2 - 60;
            My2 = My2 - 3;
            Thread.Sleep(max);
            auto.MouseMove(Mx2, My2);
            auto.MouseClick();
            Thread.Sleep(min);
            mparentwindow = null;
            Click<HtmlButton>(PropertyType.InnerText, "Confirm");
           // auto.Send("{ENTER}");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);
        }
        public bool SearchNoData()
        {
            BrowserWindow window = new BrowserWindow();

            var data = window.ExecuteScript("var data=document.getElementById('ContentPlaceHolder1_tbPrecautionaryBody').innerHTML;  return  data");
            string successMsg = data.ToString();
            bool b1 = successMsg.Contains(SignalWordLanguageTemplate.Msg_NoRecordsFound);
            return b1;
        }
        public void screenShot(string imgName)
        {
            BrowserWindow window = new BrowserWindow();
            string path = ConfigurationSettings.AppSettings["ScreenShot"];
            path = path + @"\\iPAS_GHS_Info2";
            Directory.CreateDirectory(path);
            try
            {
                window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
                Image image = window.CaptureImage();
                image.Save(path + "\\" + imgName + ".jpeg", ImageFormat.Jpeg);
                image.Dispose();
            }
            catch (Exception e) { }
            Console.WriteLine("Screen Shot is Avaliable in " + path + "\t" + "Folder");
        }

        public void WindowButtonClick<T>(PropertyType type, string propertyvalue) where T : WinControl
        {
            WinControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Name)
                genericControl.SearchProperties[WinControl.PropertyNames.Name] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void PathEnterText<T>(PropertyType type, string propertyvalue, string text) where T : WinEdit
        {
            WinEdit genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            genericControl.FilterProperties[WinEdit.PropertyNames.Name] = propertyvalue;
            AutoItX3 auto = new AutoItX3();
            auto.WinActivate("Choose File to Upload");
            auto.Send(text);
            auto.Send("{ENTER}");
            Thread.Sleep(1000);
        }
        public void Click<T>(PropertyType type, string propertyvalue) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });

            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;
            else if (type == PropertyType.InnerText)
            {
                genericControl.SearchProperties[HtmlControl.PropertyNames.InnerText] = propertyvalue;
            }
            else if (type == PropertyType.TagInstance)
                genericControl.FilterProperties[HtmlControl.PropertyNames.TagInstance] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void EnterText<T>(PropertyType type, string propertyvalue, string text) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;

            Keyboard.SendKeys(genericControl, text);

        }
        private BrowserWindow mparentwindow { get; set; }
        public enum PropertyType
        {
            Id,
            Name,
            InnerText,
            TagInstance
        }
        public BrowserWindow TopParentWindow()
        {

            BrowserWindow window = new BrowserWindow();
            window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
            return window;
        }
        public BrowserWindow ParentWindow
        {
            get
            {
                if (this.mparentwindow == null)
                {
                    this.mparentwindow = TopParentWindow();
                }
                return this.mparentwindow;
            }
        }
    }
}
