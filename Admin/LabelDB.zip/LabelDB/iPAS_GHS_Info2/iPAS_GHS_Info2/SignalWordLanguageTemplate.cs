﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Text;
using System.Threading.Tasks;

namespace iPAS_GHS_Info2
{
    class SignalWordLanguageTemplate
    {
        static CultureInfo ci = null;
        static ResourceManager rm = null;
        static string resMsg_SignalWordAddedSuccessfully = string.Empty;
        public string Msg_SignalWordAddedSuccessfully
        {
            get { return resMsg_SignalWordAddedSuccessfully; }
            set { resMsg_SignalWordAddedSuccessfully = value; }
        }
        static string resMsg_SignalWordUpdateSuccess = string.Empty;
        public string Msg_SignalWordUpdateSuccess
        {
            get { return resMsg_SignalWordUpdateSuccess; }
            set { resMsg_SignalWordUpdateSuccess = value; }
        }
        static string resMsg_NoRecordsFound = string.Empty;
        public static string Msg_NoRecordsFound
        {
            get { return resMsg_NoRecordsFound; }
            set { resMsg_NoRecordsFound = value; }
        }
        
        public static void messageResource(string languageCode)
        {
            if (languageCode == "zh-CN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_GHS_Info2.resouces.SignalWordResourceCN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "th-TH")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_GHS_Info2.resouces.SignalWordResourceTH", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "vi-VN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_GHS_Info2.resouces.SignalWordResourceVN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "ko-KR")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_GHS_Info2.resouces.SignalWordResourceKR", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "ja-JP")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_GHS_Info2.resouces.SignalWordResourceJP", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "id-ID")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_GHS_Info2.resouces.SignalWordResourceID", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_GHS_Info2.resouces.SignalWordResourceEN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }

        }
        public static void messageInitialize()
        {
            resMsg_SignalWordAddedSuccessfully = rm.GetString("resMsg_SignalWordAddedSuccessfully", ci).Trim();
            resMsg_SignalWordUpdateSuccess = rm.GetString("resMsg_SignalWordUpdateSuccess", ci).Trim();
            resMsg_NoRecordsFound = rm.GetString("resMsg_NoRecordsFound", ci).Trim();
        }
    }
}
