﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Text;
using System.Threading.Tasks;

namespace iPAS_ManageLabelDB
{
    class DynamicLabelDBLanguageTemplate
    {
        static CultureInfo ci = null;
        static ResourceManager rm = null;
        static string resMsg_Confirm = string.Empty;
        public string Msg_Confirm
        {
            get { return resMsg_Confirm; }
            set { resMsg_Confirm = value; }
        }
        static string resMsg_Ok = string.Empty;
        public string Msg_Ok
        {
            get { return resMsg_Ok; }
            set { resMsg_Ok = value; }
        }
        static string resMsg_NoRecordFound = string.Empty;
        public string Msg_NoRecordFound
        {
            get { return resMsg_NoRecordFound; }
            set { resMsg_NoRecordFound = value; }
        }
       
        public static void messageResource(string languageCode)
        {
            if (languageCode == "zh-CN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ManageLabelDB.resources.DynamicLabelDBResourceCN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "th-TH")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ManageLabelDB.resources.DynamicLabelDBResourceTH", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "vi-VN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ManageLabelDB.resources.DynamicLabelDBResourceVN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "ko-KR")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ManageLabelDB.resources.DynamicLabelDBResourceKR", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "ja-JP")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ManageLabelDB.resources.DynamicLabelDBResourceJP", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ManageLabelDB.resources.DynamicLabelDBResourceEN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
        }
        public static void messageInitialize()
        {
            resMsg_Confirm = rm.GetString("resMsg_Confirm", ci).Trim();
            resMsg_Ok = rm.GetString("resMsg_Ok", ci).Trim();
            resMsg_NoRecordFound = rm.GetString("resMsg_NoRecordFound", ci).Trim();
        }

    }
}
