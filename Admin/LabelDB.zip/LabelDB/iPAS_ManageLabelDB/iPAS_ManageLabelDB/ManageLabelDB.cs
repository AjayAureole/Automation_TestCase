﻿using AutoItX3Lib;
using DataDrivenTesting;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace iPAS_ManageLabelDB
{
    class ManageLabelDB
    {
        string minsleep = ConfigurationSettings.AppSettings["min"];
        string midsleep = ConfigurationSettings.AppSettings["mid"];
        string maxsleep = ConfigurationSettings.AppSettings["max"];
        DynamicLabelDBLanguageTemplate langauageResource = new DynamicLabelDBLanguageTemplate();
        public void manageLabelDBDetails()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "lnkAdmin");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnklabelDb");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlDiv>(PropertyType.Id,"footer");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkMangeLabelDB");
            Thread.Sleep(min);
            auto.MouseClick();
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            try
            {

                Click<HtmlSpan>(PropertyType.InnerText, "Manage Dynamic Label Database");
            }
            catch (Exception e)
            {
                Click<HtmlSpan>(PropertyType.InnerText, "Manage Dynamic Label Database");
            }
            Thread.Sleep(min);
            int xCoodinate = auto.MouseGetPosX();
            int yCoodinate = auto.MouseGetPosY();
            xCoodinate = xCoodinate - 320;
            auto.MouseMove(xCoodinate, yCoodinate);
            yCoodinate = yCoodinate + 40;
            auto.MouseMove(xCoodinate, yCoodinate);
            auto.MouseClick();


            Click<HtmlCustom>(PropertyType.Id, "btnUploadData");
            Click<HtmlFileInput>(PropertyType.Id, "ContentPlaceHolder1_uploadFile");
            PathEnterText<WinEdit>(PropertyType.Name, "File name:", ExcelDataTable.ReadData(1, "filePath"));
            Thread.Sleep(max*10);
            var data1 = window.ExecuteScript("var data=document.getElementById('lblUploadError').innerHTML;  return  data");
            string successMsg1 = data1.ToString().Trim();
            if (successMsg1!="")
            {
                string screenShotName = "FileIs_NotUploading";
                screenShot(screenShotName);
            }

            Assert.AreEqual("", successMsg1, successMsg1);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);           
        }
        public void SearchAndRefresh()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtMaterialNumber", ExcelDataTable.ReadData(1, "UploadedMaterial_No"));
            }
            catch (Exception e) { }
            Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearch");
            Thread.Sleep(mid);
            ////************Here validate on the Search TextBoX Data is Enter or Not**************///
            var data1 = window.ExecuteScript("var data=document.getElementById('spnSearchError').innerHTML;  return  data");
            string successMsg1 = data1.ToString().Trim();
            if (successMsg1 != "")
            {
                string screenShotName = "PleaseEnterSearch_Criteria";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", successMsg1, successMsg1);
            Thread.Sleep(min);

            /******************Here search and click Refresh Button************************/
           
            //string material_No = ExcelDataTable.ReadData(1, "UploadedMaterial_No");
            //string refreshId = "ContentPlaceHolder1_ulabelDataBaseSummary"+ material_No + "_liManualSync";
            //refreshId = "'" + refreshId + "'";
            //Thread.Sleep(mid);
            //var xCoodinate = window.ExecuteScript("var data1=document.getElementById(" + refreshId + "); var rect = data1.getBoundingClientRect(); return  rect.left");
            //var yCoodinate = window.ExecuteScript("var data1=document.getElementById(" + refreshId + "); var rect = data1.getBoundingClientRect(); return  rect.top");

            //string x = xCoodinate.ToString();
            //string y = yCoodinate.ToString();
            //double x1 = Convert.ToDouble(x);
            //double y1 = Convert.ToDouble(y);
            //int Xco = Convert.ToInt32(x1);
            //int Yco = Convert.ToInt32(y1);
            ////Make sure Browser Window is Maximize
            //// Xco = Xco;
            //Yco = Yco + 60;
            //Xco = Xco + 5;
            //auto.MouseMove(Xco, Yco);
            //auto.MouseClick();
            //Thread.Sleep(max);
            //mparentwindow = null;
            //Click<HtmlButton>(PropertyType.InnerText, "OK");
            //auto.Send("{F5}");
            //Thread.Sleep(mid);

            mparentwindow = null;
            Click<HtmlSpan>(PropertyType.InnerText, ExcelDataTable.ReadData(1, "UploadedMaterial_No"));
            int Mx1 = auto.MouseGetPosX();
            int My1 = auto.MouseGetPosY();
            Mx1 = Mx1 - 125;
            My1 = My1 - 3;
            Thread.Sleep(max);
            auto.MouseMove(Mx1, My1);
            auto.MouseClick();
            Thread.Sleep(min);
            mparentwindow = null;
            Click<HtmlButton>(PropertyType.InnerText, langauageResource.Msg_Ok);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void SearchAndDelete()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtMaterialNumber", ExcelDataTable.ReadData(1, "UploadedMaterial_No"));
            }
            catch (Exception e) { }
            Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearch");
            Thread.Sleep(mid);
            ////************Here validate on the Search TextBoX Data is Enter or Not**************///
            var data1 = window.ExecuteScript("var data=document.getElementById('spnSearchError').innerHTML;  return  data");
            string successMsg1 = data1.ToString().Trim();
            if (successMsg1 != "")
            {
                string screenShotName = "PleaseEnterSearch_Criteria";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", successMsg1, successMsg1);
            Thread.Sleep(min);
            /******************Here search and click Delete Button************************/
            //string material_No = ExcelDataTable.ReadData(1, "UploadedMaterial_No");
            //string refreshId = "ContentPlaceHolder1_ulabelDataBaseSummary" + material_No + "_Delete";
            //refreshId = "'" + refreshId + "'";
            //Thread.Sleep(mid);
            //var xCoodinate = window.ExecuteScript("var data1=document.getElementById(" + refreshId + "); var rect = data1.getBoundingClientRect(); return  rect.left");
            //var yCoodinate = window.ExecuteScript("var data1=document.getElementById(" + refreshId + "); var rect = data1.getBoundingClientRect(); return  rect.top");

            //string x = xCoodinate.ToString();
            //string y = yCoodinate.ToString();
            //double x1 = Convert.ToDouble(x);
            //double y1 = Convert.ToDouble(y);
            //int Xco = Convert.ToInt32(x1);
            //int Yco = Convert.ToInt32(y1);
            ////Make sure Browser Window is Maximize
            //// Xco = Xco;
            //Yco = Yco + 60;
            //Xco = Xco + 5;
            //auto.MouseMove(Xco, Yco);
            //auto.MouseClick();
            //Thread.Sleep(mid);
            //mparentwindow = null;
            //Click<HtmlButton>(PropertyType.InnerText, "Confirm");
            //Thread.Sleep(min);
            //auto.Send("{F5}");
            //Thread.Sleep(mid);

            mparentwindow = null;
            Click<HtmlSpan>(PropertyType.InnerText, ExcelDataTable.ReadData(1, "UploadedMaterial_No"));
            int Mx1 = auto.MouseGetPosX();
            int My1 = auto.MouseGetPosY();
            Mx1 = Mx1 - 50;
            My1 = My1 - 3;
            Thread.Sleep(max);
            auto.MouseMove(Mx1, My1);
            auto.MouseClick();
            Thread.Sleep(min);
            mparentwindow = null;
            Click<HtmlButton>(PropertyType.InnerText, langauageResource.Msg_Confirm);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void checkAvailablity()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtMaterialNumber", ExcelDataTable.ReadData(1, "UploadedMaterial_No"));
            }
            catch (Exception e) { }
            Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearch");
            Thread.Sleep(mid);
            ////************Here validate on the Search TextBoX Data is Enter or Not**************///
            var data1 = window.ExecuteScript("var data=document.getElementById('spnSearchError').innerHTML;  return  data");
            string successMsg1 = data1.ToString().Trim();
            if (successMsg1 != "")
            {
                string screenShotName = "PleaseEnterSearch_Criteria";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", successMsg1, successMsg1);
            Thread.Sleep(mid);
            bool b1 = SearchNoData();
            if (!b1)
            {
                string screenShotName = "DataIs_NotDeteted";
                screenShot(screenShotName);
            }
            Assert.IsTrue(b1,"Data is Not Deleted");
            Thread.Sleep(max);
            try
            {
                Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearchAll");
            }catch(Exception e) { }
            Thread.Sleep(max);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void screenShot(string imgName)
        {
            BrowserWindow window = new BrowserWindow();
            string path = ConfigurationSettings.AppSettings["ScreenShot"];
            path = path + @"\\iPAS_ManageLabelDB";
            Directory.CreateDirectory(path);

            try
            {
                window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
                Image image = window.CaptureImage();
                image.Save(path + "\\" + imgName + ".jpeg", ImageFormat.Jpeg);
                image.Dispose();
            }
            catch (Exception e) { }
            Console.WriteLine("Screen Shot is Avaliable in " + path + "\t" + "Folder");
        }

        public bool SearchNoData()
        {
            BrowserWindow window = new BrowserWindow();
            Thread.Sleep(500);
            var data = window.ExecuteScript("var data=document.getElementById('ContentPlaceHolder1_tbLabelDataBase').getElementsByTagName('span')[0];  return  data.innerHTML");
            string successMsg = data.ToString().Trim();
            bool b1 = successMsg.Equals(langauageResource.Msg_NoRecordFound);
            return b1;
        }

        public void PathEnterText<T>(PropertyType type, string propertyvalue, string text) where T : WinEdit
        {
            WinEdit genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            genericControl.FilterProperties[WinEdit.PropertyNames.Name] = propertyvalue;
            AutoItX3 auto = new AutoItX3();
            auto.WinActivate("Choose File to Upload");
            auto.Send(text);
            auto.Send("{ENTER}");
            Thread.Sleep(1000);
        }
        public void WindowButtonClick<T>(PropertyType type, string propertyvalue) where T : WinControl
        {
            WinControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Name)
                genericControl.SearchProperties[WinControl.PropertyNames.Name] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void Click<T>(PropertyType type, string propertyvalue) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });

            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;
            else if (type == PropertyType.InnerText)
            {
                genericControl.SearchProperties[HtmlControl.PropertyNames.InnerText] = propertyvalue;
            }
            else if (type == PropertyType.TagInstance)
                genericControl.FilterProperties[HtmlControl.PropertyNames.TagInstance] = propertyvalue;
            else if (type == PropertyType.Class)
            {
                genericControl.FilterProperties[HtmlControl.PropertyNames.Class] = propertyvalue;
            }

            Mouse.Click(genericControl);
        }
        public void EnterText<T>(PropertyType type, string propertyvalue, string text) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;
            else if (type == PropertyType.Class)
                genericControl.FilterProperties[HtmlControl.PropertyNames.Class] = propertyvalue;



            Keyboard.SendKeys(genericControl, text);

        }
        private BrowserWindow mparentwindow { get; set; }
        public enum PropertyType
        {
            Id,
            Name,
            InnerText,
            TagInstance,
            Class
        }
        public BrowserWindow TopParentWindow()
        {

            BrowserWindow window = new BrowserWindow();
            window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
            return window;
        }
        public BrowserWindow ParentWindow
        {
            get
            {
                if (this.mparentwindow == null)
                {
                    this.mparentwindow = TopParentWindow();
                }
                return this.mparentwindow;
            }
        }

    }

}
