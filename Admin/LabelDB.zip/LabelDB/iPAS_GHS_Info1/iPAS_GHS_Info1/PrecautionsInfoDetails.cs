﻿using AutoItX3Lib;
using DataDrivenTesting;
using iPAS_GHS_Info1;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace iPAS_GHS_Info
{
    class PrecautionsInfoDetails
    {
        string minsleep = ConfigurationSettings.AppSettings["min"];
        string midsleep = ConfigurationSettings.AppSettings["mid"];
        string maxsleep = ConfigurationSettings.AppSettings["max"];
        PrecautionInfoLanguageTemplate languageResource = new PrecautionInfoLanguageTemplate();

        public void precautionUploadedInfo()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);
            Click<HtmlHyperlink>(PropertyType.Id, "precautionsLink");
            auto.MouseClick();
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);
            /*Here Checking how Many record is there befor add */
            //var totalbefore = window.ExecuteScript("var data=document.getElementById('spnTotalRecords').innerHTML;  return  data");
            //string tot = totalbefore.ToString().Trim();
            //int totalbeforerecord = Convert.ToInt32(totalbefore);

            /****************************Clicking on the Upload and Download Button*********************/

            try
            {

                Click<HtmlSpan>(PropertyType.InnerText, "GHS Information");
            }
            catch (Exception e)
            {
                Click<HtmlSpan>(PropertyType.InnerText, "GHS Information");
            }
            Thread.Sleep(min);
            int xCoodinate = auto.MouseGetPosX();
            int yCoodinate = auto.MouseGetPosY();
            xCoodinate = xCoodinate - 270;
            auto.MouseMove(xCoodinate, yCoodinate);
            yCoodinate = yCoodinate + 90;
            auto.MouseMove(xCoodinate, yCoodinate);
            auto.MouseClick();


            Click<HtmlCustom>(PropertyType.Id, "btnUploadPrecaution");
            Click<HtmlFileInput>(PropertyType.Id, "ContentPlaceHolder1_uploadFile");
            PathEnterText<WinEdit>(PropertyType.Name, "File name:", ExcelDataTable.ReadData(1, "precautionFilePath"));
            Thread.Sleep(max*5);
            var data1 = window.ExecuteScript("var data=document.getElementById('lblUploadError').innerHTML;  return  data");
            string successMsg1 = data1.ToString().Trim();
            if (successMsg1!="")
            {
                string screenShotName = "FileIs_NotUploaded";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", successMsg1, successMsg1);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max*2);
            //var afterTotal = window.ExecuteScript("var data=document.getElementById('spnTotalRecords').innerHTML;  return  data");
            //string afterTot = afterTotal.ToString().Trim();
            //int afterTotalRecords = Convert.ToInt32(afterTot);
            //totalbeforerecord = totalbeforerecord + 1;
            //Thread.Sleep(mid);
            //if (afterTotalRecords != totalbeforerecord)
            //{
            //    string screenShotName = "afterTotalRecords_NotProper";
            //    screenShot(screenShotName);
            //}
            //Assert.AreEqual(afterTotalRecords, totalbeforerecord, "Total Record value Not Proper");
            //Thread.Sleep(min);
        }
        public void deleteUploadedInfo()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtSearchPrecautionaryCode", ExcelDataTable.ReadData(1, "UploadedPrecaution Code"));
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_ddlSearchByPrecautionType", ExcelDataTable.ReadData(1, "UploadedPrecaution Type"));
            }
            catch (Exception e) { }
            Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearch");
            Thread.Sleep(mid);

            ////************Here validate on the Search TextBoX Data is Enter or Not**************///
            var data1 = window.ExecuteScript("var data=document.getElementById('spnSearchError').innerHTML;  return  data");
            string successMsg1 = data1.ToString().Trim();
            if (successMsg1 != "")
            {
                string screenShotName = "PleaseEnterSearch_Criteria";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", successMsg1, successMsg1);


            /*************Here search and click Edit Button to Update the Precaution info Details*******/

            //string id = "ucPrecautionSummary_0_btnEdit";
            //id = "'" + id + "'";
            //Thread.Sleep(mid);
            //var xCoodinate = window.ExecuteScript("var data1=document.getElementById(" + id + "); var rect = data1.getBoundingClientRect(); return  rect.left");
            //var yCoodinate = window.ExecuteScript("var data1=document.getElementById(" + id + "); var rect = data1.getBoundingClientRect(); return  rect.top");

            //string x = xCoodinate.ToString();
            //string y = yCoodinate.ToString();
            //double x1 = Convert.ToDouble(x);
            //double y1 = Convert.ToDouble(y);
            //int Xco = Convert.ToInt32(x1);
            //int Yco = Convert.ToInt32(y1);
            ////Make sure Browser Window is Maximize
            //// Xco = Xco;
            //Yco = Yco + 50;
            //Xco = Xco + 25;
            //auto.MouseMove(Xco, Yco);
            //auto.MouseClick();
            //Thread.Sleep(min);
            //auto.Send("{ENTER}");
            //Thread.Sleep(min);
            //auto.Send("{F5}");
            //Thread.Sleep(mid);

            mparentwindow = null;
            Click<HtmlSpan>(PropertyType.InnerText, ExcelDataTable.ReadData(1, "PCode Key"));
            int Mx1 = auto.MouseGetPosX();
            int My1 = auto.MouseGetPosY();
            Mx1 = Mx1 - 55;
            My1 = My1 - 3;
            Thread.Sleep(max);
            auto.MouseMove(Mx1, My1);
            auto.MouseClick();
            Thread.Sleep(min);
            Click<HtmlButton>(PropertyType.InnerText,"Confirm");
           // auto.Send("{ENTER}");
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);

            /**************validate data is deleted or Not*************/
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtSearchPrecautionaryCode", ExcelDataTable.ReadData(1, "UploadedPrecaution Code"));
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_ddlSearchByPrecautionType", ExcelDataTable.ReadData(1, "UploadedPrecaution Type"));
            }
            catch (Exception e) { }
            Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearch");
            Thread.Sleep(mid);

            ////************Here validate on the Search TextBoX Data is Enter or Not**************///
            var data = window.ExecuteScript("var data=document.getElementById('spnSearchError').innerHTML;  return  data");
            string successMsg = data.ToString().Trim();
            if (successMsg != "")
            {
                string screenShotName = "PleaseEnterSearch_Criteria";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", successMsg, successMsg);
            bool b1 = SearchNoData();
            if (!b1)
            {
                string screenShotName = "DataIsNot_Deleted";
                screenShot(screenShotName);
            }
            Assert.IsTrue(b1, "Data is Not Deleted");
            Thread.Sleep(max);
            Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnShowAll");
            Thread.Sleep(max);
        }
        public void addPrecautionInfoManually()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtPCodeKey", ExcelDataTable.ReadData(1, "addPcode Key"));
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtPrecautionaryCode", ExcelDataTable.ReadData(1, "addPrecaution Code"));
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_ddlPrecautionType", ExcelDataTable.ReadData(1, "addPrecaution Type"));
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlComboBox>(PropertyType.Id, "ucPrecautionStatementControl_1_drpLanguages", ExcelDataTable.ReadData(1, "addLanguage Code1"));
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlTextArea>(PropertyType.Id, "ucPrecautionStatementControl_1_txtPrecautionStatement", ExcelDataTable.ReadData(1, "addPrecaution Statement1"));
            }
            catch (Exception e) { }
            auto.Send("{Down}");
            Thread.Sleep(min);
            try
            {
                EnterText<HtmlComboBox>(PropertyType.Id, "ucPrecautionStatementControl_2_drpLanguages", ExcelDataTable.ReadData(1, "addLanguage Code2"));
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlTextArea>(PropertyType.Id, "ucPrecautionStatementControl_2_txtPrecautionStatement", ExcelDataTable.ReadData(1, "addPrecaution Statement2"));
            }
            catch (Exception e) { }
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            /*******************Add More Button is Clicking Here*********************/
            Thread.Sleep(min);
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnAddMore");
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            mparentwindow = null;
            try
            {
                EnterText<HtmlComboBox>(PropertyType.Id, "ucPrecautionStatementControl_3_drpLanguages", ExcelDataTable.ReadData(1, "addLanguage Code3"));
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlTextArea>(PropertyType.Id, "ucPrecautionStatementControl_3_txtPrecautionStatement", ExcelDataTable.ReadData(1, "addPrecaution Statement3"));
            }catch(Exception e) { }
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);

            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnAddPrecautionaryStatement");
            Thread.Sleep(mid);
            ////************Here validate Precaution info is added successfully or Not **************///
            var data = window.ExecuteScript("var data=document.getElementById('spnPrecautionError').innerHTML;  return  data");
            string successMsg = data.ToString().Trim();
            if (languageResource.Msg_PrecautionInfoAddedSuccessfully!= successMsg)
            {
                string screenShotName = "PrecautionInfoAdded_NotSuccessfully";
                screenShot(screenShotName);
            }
            Assert.AreEqual(languageResource.Msg_PrecautionInfoAddedSuccessfully, successMsg, successMsg);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void updatePrecautionInfoManually()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);
            auto.Send("{F5}");
            Thread.Sleep(max*2);
            try
            {
                Thread.Sleep(max);
                auto.Send("{F5}");
                Thread.Sleep(max * 2);
                Click<HtmlHyperlink>(PropertyType.Id, "precautionsLink");
                Thread.Sleep(max);
                auto.Send("{F5}");
                Thread.Sleep(max * 2);
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtSearchPrecautionaryCode", ExcelDataTable.ReadData(1, "addPrecaution Code"));
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_ddlSearchByPrecautionType", ExcelDataTable.ReadData(1, "addPrecaution Type"));
            }
            catch (Exception e) { }
            Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearch");
            Thread.Sleep(mid);

            ////************Here validate on the Search TextBoX Data is Enter or Not**************///
            var data = window.ExecuteScript("var data=document.getElementById('spnSearchError').innerHTML;  return  data");
            string successMsg = data.ToString().Trim();
            if (successMsg != "")
            {
                string screenShotName = "PleaseEnterSearch_Criteria";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", successMsg, successMsg);

            /*****************Here Clicking on the Edit Button to update the Data*************/
            // string id = "ucPrecautionSummary_0_btnEdit";
            // id = "'" + id + "'";
            // Thread.Sleep(mid);
            // var xCoodinate = window.ExecuteScript("var data1=document.getElementById(" + id + "); var rect = data1.getBoundingClientRect(); return  rect.left");
            // var yCoodinate = window.ExecuteScript("var data1=document.getElementById(" + id + "); var rect = data1.getBoundingClientRect(); return  rect.top");

            // string x = xCoodinate.ToString();
            // string y = yCoodinate.ToString();
            // double x1 = Convert.ToDouble(x);
            // double y1 = Convert.ToDouble(y);
            // int Xco = Convert.ToInt32(x1);
            // int Yco = Convert.ToInt32(y1);
            // //Make sure Browser Window is Maximize
            // Yco = Yco + 50;
            //// Xco = Xco + 25;
            // auto.MouseMove(Xco, Yco);
            // auto.MouseClick();
            // Thread.Sleep(min);

            mparentwindow = null;
            Click<HtmlSpan>(PropertyType.InnerText, ExcelDataTable.ReadData(1, "addPcode Key"));
            int Mx1 = auto.MouseGetPosX();
            int My1 = auto.MouseGetPosY();
            Mx1 = Mx1 - 85;
            My1 = My1 - 3;
            Thread.Sleep(max);
            auto.MouseMove(Mx1, My1);
            auto.MouseClick();
            Thread.Sleep(mid);

            /*********************Upadate PrecautionInfo Manually added PrecautionInfo ********************/

            try
            {
                Click<HtmlEdit>(PropertyType.Id, "txtPCodeKey");
                auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                auto.Send("{DEL 20}");
                EnterText<HtmlEdit>(PropertyType.Id, "txtPCodeKey", ExcelDataTable.ReadData(1, "updatePcode Key"));
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtPrecautionaryCode");
                auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                auto.Send("{DEL 20}");
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtPrecautionaryCode", ExcelDataTable.ReadData(1, "updatePrecaution Code"));
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_ddlPrecautionType", ExcelDataTable.ReadData(1, "updatePrecaution Type"));
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlComboBox>(PropertyType.Id, "ucPrecautionStatementDetail_0_1_drpLanguages", ExcelDataTable.ReadData(1, "updateLanguage Code1"));
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlTextArea>(PropertyType.Id, "ucPrecautionStatementDetail_0_1_txtPrecautionStatement");
                auto.Send("{BACKSPACE 40}");//Existing Data Deletion
                auto.Send("{DEL 40}");
                EnterText<HtmlTextArea>(PropertyType.Id, "ucPrecautionStatementDetail_0_1_txtPrecautionStatement", ExcelDataTable.ReadData(1, "updatePrecaution Statement1"));
            }
            catch (Exception e) { }
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            try
            { 
                EnterText<HtmlComboBox>(PropertyType.Id, "ucPrecautionStatementDetail_1_2_drpLanguages", ExcelDataTable.ReadData(1, "updateLanguage Code2"));
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlTextArea>(PropertyType.Id, "ucPrecautionStatementDetail_1_2_txtPrecautionStatement");
                auto.Send("{BACKSPACE 40}");//Existing Data Deletion
                auto.Send("{DEL 40}");
                EnterText<HtmlTextArea>(PropertyType.Id, "ucPrecautionStatementDetail_1_2_txtPrecautionStatement", ExcelDataTable.ReadData(1, "updatePrecaution Statement2"));
            }
            catch (Exception e) { }
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);

            try
            {
                EnterText<HtmlComboBox>(PropertyType.Id, "ucPrecautionStatementDetail_2_4_drpLanguages", ExcelDataTable.ReadData(1, "updateLanguage Code3"));
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlTextArea>(PropertyType.Id, "ucPrecautionStatementDetail_2_4_txtPrecautionStatement");
                auto.Send("{BACKSPACE 40}");//Existing Data Deletion
                auto.Send("{DEL 40}");
                EnterText<HtmlTextArea>(PropertyType.Id, "ucPrecautionStatementDetail_2_4_txtPrecautionStatement", ExcelDataTable.ReadData(1, "updatePrecaution Statement3"));
            }
            catch (Exception e) { }
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            /*******************Add More Button is Clicking Here*********************/
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnAddMore");
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            mparentwindow = null;
            try
            {
                EnterText<HtmlComboBox>(PropertyType.Id, "ucPrecautionStatementControl_4_drpLanguages", ExcelDataTable.ReadData(1, "updateLanguage Code4"));
            }
            catch (Exception e) { }
            try
            {
                
                EnterText<HtmlTextArea>(PropertyType.Id, "ucPrecautionStatementControl_4_txtPrecautionStatement", ExcelDataTable.ReadData(1, "updatePrecaution Statement4"));
            }
            catch (Exception e) { }
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnAddPrecautionaryStatement");
            Thread.Sleep(mid);
            ////************Here  check Precaution info is  updated successfully  or Not**************///
            var data1 = window.ExecuteScript("var data=document.getElementById('spnPrecautionError').innerHTML;  return  data");
            string successMsg1 = data1.ToString().Trim();
            if (languageResource.Msg_PrecautionInfoUpdateSuccess != successMsg1)
            {
                string screenShotName = "PrecautionInfoUpdate_NotSuccess";
                screenShot(screenShotName);
            }
            Assert.AreEqual(languageResource.Msg_PrecautionInfoUpdateSuccess, successMsg1, successMsg1);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(min);
        }
        public void deletePrecautionInfoManually()
        {

            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);
            Click<HtmlHyperlink>(PropertyType.Id, "precautionsLink");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtSearchPrecautionaryCode", ExcelDataTable.ReadData(1, "updatePrecaution Code"));
            }
            catch (Exception e) { }
            try
            {
               // EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_ddlSearchByPrecautionType", ExcelDataTable.ReadData(1, "updatePrecaution Type"));
            }
            catch (Exception e) { }
            Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearch");
            Thread.Sleep(mid);

            ////************Here validate on the Search TextBoX Data is Enter or Not**************///
            var data1 = window.ExecuteScript("var data=document.getElementById('spnSearchError').innerHTML;  return  data");
            string successMsg1 = data1.ToString().Trim();
            if (successMsg1!="")
            {
                string screenShotName = "PleaseEnterSearch_Criteria";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", successMsg1, successMsg1);


            /*************Here search and click Delete Button to Update the Precaution info Details*******/

            //string id = "ucPrecautionSummary_0_btnEdit";
            //id = "'" + id + "'";
            //Thread.Sleep(mid);
            //var xCoodinate = window.ExecuteScript("var data1=document.getElementById(" + id + "); var rect = data1.getBoundingClientRect(); return  rect.left");
            //var yCoodinate = window.ExecuteScript("var data1=document.getElementById(" + id + "); var rect = data1.getBoundingClientRect(); return  rect.top");

            //string x = xCoodinate.ToString();
            //string y = yCoodinate.ToString();
            //double x1 = Convert.ToDouble(x);
            //double y1 = Convert.ToDouble(y);
            //int Xco = Convert.ToInt32(x1);
            //int Yco = Convert.ToInt32(y1);
            ////Make sure Browser Window is Maximize
            //// Xco = Xco;
            //Yco = Yco + 50;
            //Xco = Xco + 25;
            //auto.MouseMove(Xco, Yco);
            //auto.MouseClick();
            //Thread.Sleep(min);
            //auto.Send("{ENTER}");
            //Thread.Sleep(min);
            //auto.Send("{F5}");
            //Thread.Sleep(min);
            mparentwindow = null;
            Click<HtmlSpan>(PropertyType.InnerText, ExcelDataTable.ReadData(1, "updatePcode Key"));
            int Mx1 = auto.MouseGetPosX();
            int My1 = auto.MouseGetPosY();
            Mx1 = Mx1 - 55;
            My1 = My1 - 3;
            Thread.Sleep(max);
            auto.MouseMove(Mx1, My1);
            auto.MouseClick();
            Thread.Sleep(min);
            Click<HtmlButton>(PropertyType.InnerText, "Confirm");
          //  auto.Send("{ENTER}");
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);

            /**************validate data is deleted or Not*************/
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtSearchPrecautionaryCode", ExcelDataTable.ReadData(1, "updatePrecaution Code"));
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_ddlSearchByPrecautionType", ExcelDataTable.ReadData(1, "updatePrecaution Type"));
            }
            catch (Exception e) { }
            Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearch");
            Thread.Sleep(mid);

            ////************Here validate on the Search TextBoX Data is Enter or Not**************///
            var data = window.ExecuteScript("var data=document.getElementById('spnSearchError').innerHTML;  return  data");
            string successMsg = data.ToString().Trim();
            if (successMsg != "")
            {
                string screenShotName = "PleaseEnterSearch_Criteria";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", successMsg, successMsg);
            bool b1 = SearchNoData();
            if (!b1)
            {
                string screenShotName = "DataIs_NotDeleted";
                screenShot(screenShotName);
            }
            Assert.IsTrue(b1, "Data is Not Deleted");
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void pageNavigator()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlDiv>(PropertyType.Id, "footer");
            //try
            //{
            //    var pageCount = window.ExecuteScript("var data=document.getElementById('ctl01_divPager').getElementsByTagName('a');  return  data.length");
            //    string len = pageCount.ToString();
            //    int length = Convert.ToInt32(len);
            //    for (int i = 1; i <= length; i++)
            //    {
            //        string tagId = "ctl01_hrefNum" + i;
            //        Thread.Sleep(mid);
            //        if (i == 7)
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            Click<HtmlHyperlink>(PropertyType.Id, "pagerControl_hrefLast");
            Thread.Sleep(max);
            validation();
            Thread.Sleep(min);

            //    tagId = "";
            //}
            //}
            //catch (Exception e) { }
            auto.Send("{F5}");
            Thread.Sleep(min);
        }
        public void validation()
        {
            BrowserWindow window = new BrowserWindow();
            Thread.Sleep(1000);
            var len = window.ExecuteScript("var data=document.getElementById('ContentPlaceHolder1_tbPrecautionaryBody').getElementsByTagName('td');  return  data.length");
            string length = len.ToString().Trim();
            int Data = Convert.ToInt32(length);
            bool flag = true;
            if (Data == 0)
                flag = false;

            string error = "Data is Not there On Last Navigate page";
            if (!flag)
            {
                string screenShotName = "DataIsNotThere_LastNavigatePage";
                screenShot(screenShotName);
            }
            Assert.IsTrue(flag, error);
        }
        public void screenShot(string imgName)
        {
            BrowserWindow window = new BrowserWindow();
            string path = ConfigurationSettings.AppSettings["ScreenShot"];
            path = path + @"\\iPAS_GHS_Info1";
            Directory.CreateDirectory(path);
            try
            {
                window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
                Image image = window.CaptureImage();
                image.Save(path + "\\" + imgName + ".jpeg", ImageFormat.Jpeg);
                image.Dispose();
            }
            catch (Exception e) { }
            Console.WriteLine("Screen Shot is Avaliable in " + path + "\t" + "Folder");
        }
        public bool SearchNoData()
        {
            BrowserWindow window = new BrowserWindow();

            var data = window.ExecuteScript("var data=document.getElementById('ContentPlaceHolder1_tbPrecautionaryBody').getElementsByTagName('span')[0];  return  data.innerHTML");
            string successMsg = data.ToString().Trim();
            bool b1 = successMsg.Equals(languageResource.Msg_NoRecordsFound);
            return b1;
        }
        public void WindowButtonClick<T>(PropertyType type, string propertyvalue) where T : WinControl
        {
            WinControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Name)
                genericControl.SearchProperties[WinControl.PropertyNames.Name] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void PathEnterText<T>(PropertyType type, string propertyvalue, string text) where T : WinEdit
        {
            WinEdit genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            genericControl.FilterProperties[WinEdit.PropertyNames.Name] = propertyvalue;
            AutoItX3 auto = new AutoItX3();
            auto.WinActivate("Choose File to Upload");
            auto.Send(text);
            auto.Send("{ENTER}");
            Thread.Sleep(1000);
        }
        public void Click<T>(PropertyType type, string propertyvalue) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });

            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;
            else if (type == PropertyType.InnerText)
            {
                genericControl.SearchProperties[HtmlControl.PropertyNames.InnerText] = propertyvalue;
            }
            else if (type == PropertyType.TagInstance)
                genericControl.FilterProperties[HtmlControl.PropertyNames.TagInstance] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void EnterText<T>(PropertyType type, string propertyvalue, string text) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;

            Keyboard.SendKeys(genericControl, text);

        }
        private BrowserWindow mparentwindow { get; set; }
        public enum PropertyType
        {
            Id,
            Name,
            InnerText,
            TagInstance
        }
        public BrowserWindow TopParentWindow()
        {

            BrowserWindow window = new BrowserWindow();
            window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
            return window;
        }
        public BrowserWindow ParentWindow
        {
            get
            {
                if (this.mparentwindow == null)
                {
                    this.mparentwindow = TopParentWindow();
                }
                return this.mparentwindow;
            }
        }

    }
}
