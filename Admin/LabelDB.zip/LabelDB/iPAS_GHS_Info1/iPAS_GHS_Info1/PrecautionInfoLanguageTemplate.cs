﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Text;
using System.Threading.Tasks;

namespace iPAS_GHS_Info1
{
    class PrecautionInfoLanguageTemplate
    {
        static CultureInfo ci = null;
        static ResourceManager rm = null;
        static string resMsg_PrecautionInfoAddedSuccessfully = string.Empty;
        public string Msg_PrecautionInfoAddedSuccessfully
        {
            get { return resMsg_PrecautionInfoAddedSuccessfully; }
            set { resMsg_PrecautionInfoAddedSuccessfully = value; }
        }
        static string resMsg_PrecautionInfoUpdateSuccess = string.Empty;
        public string Msg_PrecautionInfoUpdateSuccess
        {
            get { return resMsg_PrecautionInfoUpdateSuccess; }
            set { resMsg_PrecautionInfoUpdateSuccess = value; }
        }
        static string resMsg_NoRecordsFound = string.Empty;
        public string Msg_NoRecordsFound
        {
            get { return resMsg_NoRecordsFound; }
            set { resMsg_NoRecordsFound = value; }
                  
        }        
        public static void messageResource(string languageCode)
        {
            if (languageCode == "zh-CN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_GHS_Info1.resources.PrecautionInfoResourceCN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "th-TH")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_GHS_Info1.resources.PrecautionInfoResourceTH", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "vi-VN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_GHS_Info1.resources.PrecautionInfoResourceVN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "ko-KR")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_GHS_Info1.resources.PrecautionInfoResourceKR", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "ja-JP")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_GHS_Info1.resources.PrecautionInfoResourceJP", Assembly.GetExecutingAssembly());
                messageInitialize();
            }           
            else
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_GHS_Info1.resources.PrecautionInfoResourceEN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }

        }
        public static void messageInitialize()
        {
            resMsg_PrecautionInfoAddedSuccessfully = rm.GetString("resMsg_PrecautionInfoAddedSuccessfully", ci).Trim();
            resMsg_PrecautionInfoUpdateSuccess = rm.GetString("resMsg_PrecautionInfoUpdateSuccess", ci).Trim();
            resMsg_NoRecordsFound = rm.GetString("resMsg_NoRecordsFound", ci).Trim();
        }
    }
}
