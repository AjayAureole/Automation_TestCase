﻿using AutoItX3Lib;
using DataDrivenTesting;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace iPAS_BalanceInfo
{
    class BalanceInfo
    {
        string minsleep = ConfigurationSettings.AppSettings["min"];
        string midsleep = ConfigurationSettings.AppSettings["mid"];
        string maxsleep = ConfigurationSettings.AppSettings["max"];
        BalanceTypeLanguageTemplate languageResource = new BalanceTypeLanguageTemplate();
        public void banalceType()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(min);
            Click<HtmlHyperlink>(PropertyType.Id, "lnkAdmin");
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkConfigPLine");
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(max);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkBalanceInfo");
            auto.MouseClick();
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtBalanceType", ExcelDataTable.ReadData(1, "Balance Type"));
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtBalanceDescription", ExcelDataTable.ReadData(1, "Short Name"));
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtTolerenceValue", ExcelDataTable.ReadData(1, "Tolerance (%)"));
            }
            catch (Exception e) { }
            Thread.Sleep(mid);
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnAdd");
            Thread.Sleep(mid);
            var data = window.ExecuteScript("var data=document.getElementById('spnAddBalanceError').innerHTML; return data;");
            string msg = data.ToString().Trim();
            if (languageResource.Msg_AddBalanceSuccess!= msg)
            {
                string screenShotName = "BalanceInfo_NotAdded";
                screenShot(screenShotName);
            }
            Assert.AreEqual(languageResource.Msg_AddBalanceSuccess, msg, msg);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void updateBanalceType()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlHeaderCell>(PropertyType.InnerText,languageResource.Msg_Action);
            Thread.Sleep(min);
            int xCoodinate1 = auto.MouseGetPosX();
            int yCoodinate1 = auto.MouseGetPosY();
            yCoodinate1 = yCoodinate1 + 30;
            xCoodinate1 = xCoodinate1 - 30;
            auto.MouseMove(xCoodinate1, yCoodinate1);
            Thread.Sleep(min);
            auto.MouseClick();
            Thread.Sleep(min);
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "txtBalanceType");
                auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                auto.Send("{DEL 20}");
                EnterText<HtmlEdit>(PropertyType.Id, "txtBalanceType", ExcelDataTable.ReadData(1, "UpBalance Type"));
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "txtBalanceDescription");
                auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                auto.Send("{DEL 20}");
                EnterText<HtmlEdit>(PropertyType.Id, "txtBalanceDescription", ExcelDataTable.ReadData(1, "UpShort Name"));
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "txtTolerenceValue");
                auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                auto.Send("{DEL 20}");
                EnterText<HtmlEdit>(PropertyType.Id, "txtTolerenceValue", ExcelDataTable.ReadData(1, "UpTolerance (%)"));
            }
            catch (Exception e) { }
            Thread.Sleep(mid);
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnAdd");
            Thread.Sleep(mid);
            var data = window.ExecuteScript("var data=document.getElementById('spnAddBalanceError').innerHTML; return data;");
            string msg = data.ToString().Trim();
            if (languageResource.Msg_BalanceUpdateSuccess != msg)
            {
                string screenShotName = "BalanceUpdate_NotSuccess";
                screenShot(screenShotName);
            }
            Assert.AreEqual(languageResource.Msg_BalanceUpdateSuccess, msg, msg);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void deleteBalanceType()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlHeaderCell>(PropertyType.InnerText, languageResource.Msg_Action);
            Thread.Sleep(min);
            int xCoodinate1 = auto.MouseGetPosX();
            int yCoodinate1 = auto.MouseGetPosY();
            yCoodinate1 = yCoodinate1 + 30;
            xCoodinate1 = xCoodinate1 +10;
            auto.MouseMove(xCoodinate1, yCoodinate1);
            Thread.Sleep(min);
            auto.MouseClick();
            Thread.Sleep(min);
            auto.Send("{ENTER}");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void balanceGroup()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);
            Click<HtmlHyperlink>(PropertyType.Id, "lnkBalanceGroup");
            Thread.Sleep(max);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtBalanceGroupName", ExcelDataTable.ReadData(1, "AddGroup Name"));
            }catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtBalancePercentage", ExcelDataTable.ReadData(1, "AddBalance (%)"));

            }catch (Exception e) { }
            try
            {
                EnterText<HtmlTextArea>(PropertyType.Id, "txtBalanceInsruction", ExcelDataTable.ReadData(1, "AddBalance Instructions"));
            }catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtOrder", ExcelDataTable.ReadData(1, "AddPriority"));
            }catch (Exception e) { }
            Thread.Sleep(mid);
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnAdd");
            Thread.Sleep(mid);
            var data = window.ExecuteScript("var data=document.getElementById('spnAddBalanceError').innerHTML; return data;");
            string msg = data.ToString().Trim();
            if (msg != "")
            {
                string screenShotName = "BalanceGroup_NotAdded";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", msg, msg);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void updateBanalceGroup()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlCell>(PropertyType.InnerText, ExcelDataTable.ReadData(1, "AddGroup Name"));
            Thread.Sleep(min);
            int xCoodinate1 = auto.MouseGetPosX();
            int yCoodinate1 = auto.MouseGetPosY();
            xCoodinate1 = xCoodinate1 - 135;
            yCoodinate1 = yCoodinate1 - 13;
            auto.MouseMove(xCoodinate1, yCoodinate1);
            Thread.Sleep(min);
            auto.MouseClick();
            Thread.Sleep(min);
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "txtBalanceGroupName");
                auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                auto.Send("{DEL 20}");
                EnterText<HtmlEdit>(PropertyType.Id, "txtBalanceGroupName", ExcelDataTable.ReadData(1, "UpGroup Name"));
            }catch (Exception e) { }
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "txtBalancePercentage");
                auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                auto.Send("{DEL 20}");
                EnterText<HtmlEdit>(PropertyType.Id, "txtBalancePercentage", ExcelDataTable.ReadData(1, "UpBalance (%)"));
            }catch (Exception e) { }
            try
            {
                Click<HtmlTextArea>(PropertyType.Id, "txtBalanceInsruction");
                auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                auto.Send("{DEL 20}");
                EnterText<HtmlTextArea>(PropertyType.Id, "txtBalanceInsruction", ExcelDataTable.ReadData(1, "UpBalance Instructions"));
            }catch (Exception e) { }
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "txtOrder");
                auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                auto.Send("{DEL 20}");
                EnterText<HtmlEdit>(PropertyType.Id, "txtOrder", ExcelDataTable.ReadData(1, "UpPriority"));
            }catch (Exception e) { }
            Thread.Sleep(mid);
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnAdd");
            Thread.Sleep(mid);
            var data = window.ExecuteScript("var data=document.getElementById('spnAddBalanceError').innerHTML; return data;");
            string msg = data.ToString().Trim();
            if (msg != "")
            {
                string screenShotName = "BalanceGroup_NotUpdate";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", msg, msg);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void deleteBanalceGroup()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlCell>(PropertyType.InnerText, ExcelDataTable.ReadData(1, "UpGroup Name"));
            Thread.Sleep(min);
            int xCoodinate1 = auto.MouseGetPosX();
            int yCoodinate1 = auto.MouseGetPosY();
            xCoodinate1 = xCoodinate1 - 95;
            yCoodinate1 = yCoodinate1 - 13;
            auto.MouseMove(xCoodinate1, yCoodinate1);
            Thread.Sleep(min);
            auto.MouseClick();
            Thread.Sleep(min);
            auto.Send("{ENTER}");
            Thread.Sleep(mid);
        }
        public void screenShot(string imgName)
        {
            BrowserWindow window = new BrowserWindow();
            string path = ConfigurationSettings.AppSettings["ScreenShot"];
            path = path + @"\\iPAS_BalanceInfo";
            Directory.CreateDirectory(path);
            try
            {
                window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
                Image image = window.CaptureImage();
                image.Save(path + "\\" + imgName + ".jpeg", ImageFormat.Jpeg);
                image.Dispose();
            }
            catch (Exception e) { }
            Console.WriteLine("Screen Shot is Avaliable in " + path + "\t" + "Folder");
        }

        public void PathEnterText<T>(PropertyType type, string propertyvalue, string text) where T : WinEdit
        {
            WinEdit genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            genericControl.FilterProperties[WinEdit.PropertyNames.Name] = propertyvalue;
            AutoItX3 auto = new AutoItX3();
            auto.WinActivate("Choose File to Upload");
            auto.Send(text);
            auto.Send("{ENTER}");
            Thread.Sleep(1000);
        }
        public void WindowButtonClick<T>(PropertyType type, string propertyvalue) where T : WinControl
        {
            WinControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Name)
                genericControl.SearchProperties[WinControl.PropertyNames.Name] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void Click<T>(PropertyType type, string propertyvalue) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });

            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;
            else if (type == PropertyType.InnerText)
            {
                genericControl.SearchProperties[HtmlControl.PropertyNames.InnerText] = propertyvalue;
            }
            else if (type == PropertyType.TagInstance)
                genericControl.FilterProperties[HtmlControl.PropertyNames.TagInstance] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void EnterText<T>(PropertyType type, string propertyvalue, string text) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;

            Keyboard.SendKeys(genericControl, text);

        }
        private BrowserWindow mparentwindow { get; set; }
        public enum PropertyType
        {
            Id,
            Name,
            InnerText,
            TagInstance
        }
        public BrowserWindow TopParentWindow()
        {

            BrowserWindow window = new BrowserWindow();
            window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
            return window;
        }
        public BrowserWindow ParentWindow
        {
            get
            {
                if (this.mparentwindow == null)
                {
                    this.mparentwindow = TopParentWindow();
                }
                return this.mparentwindow;
            }
        }

    }
}
