﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Text;
using System.Threading.Tasks;

namespace iPAS_BalanceInfo
{
    class BalanceTypeLanguageTemplate
    {
        static CultureInfo ci = null;
        static ResourceManager rm = null;
        static string resMsg_AddBalanceSuccess = string.Empty;
        public string Msg_AddBalanceSuccess
        {
            get { return resMsg_AddBalanceSuccess; }
            set { resMsg_AddBalanceSuccess = value; }
        }
        static string resMsg_BalanceUpdateSuccess = string.Empty;
        public string Msg_BalanceUpdateSuccess
        {
            get { return resMsg_BalanceUpdateSuccess; }
            set { resMsg_BalanceUpdateSuccess = value; }
        }
        static string resMsg_Action = string.Empty;
        public string Msg_Action
        {
            get { return resMsg_Action; }
            set { resMsg_Action = value; }
        }

        public static void messageResource(string languageCode)
        {
            if (languageCode == "zh-CN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_BalanceInfo.resources.BalanceTypeResourceCN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "th-TH")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_BalanceInfo.resources.BalanceTypeResourceTH", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_BalanceInfo.resources.BalanceTypeResourceEN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
        }

        public static void messageInitialize()
        {
            
            resMsg_AddBalanceSuccess = rm.GetString("resMsg_AddBalanceSuccess", ci).Trim();
            resMsg_BalanceUpdateSuccess = rm.GetString("resMsg_BalanceUpdateSuccess", ci).Trim();
            resMsg_Action = rm.GetString("resMsg_Action", ci).Trim();

        }
    }
}
