﻿using AutoItX3Lib;
using DataDrivenTesting;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace iPAS_ManageProductPackageInfo
{
    class ManageProductPackageInfo
    {
        string minsleep = ConfigurationSettings.AppSettings["min"];
        string midsleep = ConfigurationSettings.AppSettings["mid"];
        string maxsleep = ConfigurationSettings.AppSettings["max"];
        public void uploadingExcelInfo()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(min);
            Click<HtmlHyperlink>(PropertyType.Id, "lnkAdmin");
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkConfigPLine");
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(max);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkManagePackageProductInfo");
            auto.MouseClick();
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);

            //var totalbefore = window.ExecuteScript("var data=document.getElementById('spnTotalRecords').innerHTML;  return  data");
            //string tot = totalbefore.ToString().Trim();
            //int totalbeforerecord = Convert.ToInt32(totalbefore);

            try
            {

                Click<HtmlSpan>(PropertyType.InnerText, "Manage Product Package Information");
            }
            catch (Exception e)
            {
                Click<HtmlSpan>(PropertyType.InnerText, "Manage Product Package Information");
            }
            Thread.Sleep(min);
            int xCoodinate = auto.MouseGetPosX();
            int yCoodinate = auto.MouseGetPosY();
            xCoodinate = xCoodinate - 320;
            auto.MouseMove(xCoodinate, yCoodinate);
            yCoodinate = yCoodinate + 40;
            auto.MouseMove(xCoodinate, yCoodinate);
            auto.MouseClick();




            Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnUploadZipFiles");
            Click<HtmlFileInput>(PropertyType.Id, "ContentPlaceHolder1_uploadZipFileItems");
            PathEnterText<WinEdit>(PropertyType.Name, "File name:", ExcelDataTable.ReadData(1, "zipFilePath"));
            Thread.Sleep(max * 20);
            //****************Here check Validate File is Uploaded or not******************/
            var data = window.ExecuteScript("var data=document.getElementById('lblZipUploadError').innerHTML; return data;");
            string msg = data.ToString().Trim();
            if (msg!="")
            {
                string screenShotName = "FileIs_NotUploading";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", msg, msg);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            //var afterTotal = window.ExecuteScript("var data=document.getElementById('spnTotalRecords').innerHTML;  return  data");
            //string afterTot = afterTotal.ToString().Trim();
            //int afterTotalRecords = Convert.ToInt32(afterTot);
            //totalbeforerecord = totalbeforerecord + 1;
            //Thread.Sleep(mid);
            //if (afterTotalRecords != totalbeforerecord)
            //{
            //    string screenShotName = "afterTotalRecords_NotProper";
            //    screenShot(screenShotName);
            //}
            //Assert.AreEqual(afterTotalRecords, totalbeforerecord, "Total Record value is Not Proper");
            //Thread.Sleep(min);
        }
        public void searchAndUpdate()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtProductCode", ExcelDataTable.ReadData(1, "product code1"));
            }catch(Exception e) { }
            Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearch");
            Thread.Sleep(min);
            var data = window.ExecuteScript("var data=document.getElementById('spnSearchError').innerHTML; return data;");
            string msg = data.ToString().Trim();
            if (msg != "")
            {
                string screenShotName = "PleaseEnterSearchCriteria";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", msg, msg);
            Thread.Sleep(min);

            /************Clicking Edit Button*****************/
            Click<HtmlHeaderCell>(PropertyType.InnerText, "Action");
            int Mx = auto.MouseGetPosX();
            int My = auto.MouseGetPosY();
            My = My + 30;
            Mx = Mx - 20;
            Thread.Sleep(mid);
            auto.MouseMove(Mx, My);
            auto.MouseClick();
            Thread.Sleep(mid);
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "txtSausageWeight");
                auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                auto.Send("{DEL 20}");
                EnterText<HtmlEdit>(PropertyType.Id, "txtSausageWeight",ExcelDataTable.ReadData(1, "SausageWeight"));
            }catch(Exception e) { }
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "txtSausageUOM");
                auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                auto.Send("{DEL 20}");
                EnterText<HtmlEdit>(PropertyType.Id, "txtSausageUOM", ExcelDataTable.ReadData(1, "SausageUOM"));
            }catch (Exception e) { }
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "txtSausageColor");
                auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                auto.Send("{DEL 20}");
                EnterText<HtmlEdit>(PropertyType.Id, "txtSausageColor", ExcelDataTable.ReadData(1, "SausageColor"));
            }catch (Exception e) { }
            Thread.Sleep(min);
            Click<HtmlFileInput>(PropertyType.Id, "Sausage");
            PathEnterText<WinEdit>(PropertyType.Name, "File name:", ExcelDataTable.ReadData(1, "SausageImageFilePath"));
            Thread.Sleep(max);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            //****************Here check Validate File is Uploaded or not******************/
            var dataSausage = window.ExecuteScript("var data=document.getElementById('lblFGUploadError').innerHTML; return data;");
            string msgSausage = dataSausage.ToString().Trim();
            if (msgSausage != "")
            {
                string screenShotName = "SausageFileIs_NotUploading";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", msgSausage, msgSausage);
            Thread.Sleep(min);

            ////////////////Packaging Info File Uploading////////////////////////

            Click<HtmlFileInput>(PropertyType.Id, "Package");
            PathEnterText<WinEdit>(PropertyType.Name, "File name:", ExcelDataTable.ReadData(1, "PackageImageFilePath"));
            Thread.Sleep(mid);
            Click<HtmlDiv>(PropertyType.Id, "footer");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            //****************Here check Validate File is Uploaded or not******************/
            var dataPackingInfo = window.ExecuteScript("var data=document.getElementById('lblPackageImageError').innerHTML; return data;");
            string msgPackingInfo = dataPackingInfo.ToString().Trim();
            if (msgPackingInfo != "")
            {
                string screenShotName = "PackingInfoFileIs_NotUploading";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", msgPackingInfo, msgPackingInfo);
            Thread.Sleep(min);
            ////////////////Pallet   Info File Uploading////////////////////////
            Thread.Sleep(min);
            Click<HtmlFileInput>(PropertyType.Id, "Label");
            PathEnterText<WinEdit>(PropertyType.Name, "File name:", ExcelDataTable.ReadData(1, "LabelImageFilePath"));
            Thread.Sleep(max);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            //****************Here check Validate File is Uploaded or not******************/
            var dataLabelInfo = window.ExecuteScript("var data=document.getElementById('lblLabelImageError').innerHTML; return data;");
            string msgLabelInfo = dataLabelInfo.ToString().Trim();
            if (msgLabelInfo != "")
            {
                string screenShotName = "LabelInfoFileIs_NotUploading";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", msgLabelInfo, msgLabelInfo);
            Thread.Sleep(min);

            ////////////////Label  Info File Uploading////////////////////////
            Thread.Sleep(min);
            Click<HtmlFileInput>(PropertyType.Id, "Pallet");
            PathEnterText<WinEdit>(PropertyType.Name, "File name:", ExcelDataTable.ReadData(1, "PalletImageFilePath"));
            Thread.Sleep(max);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            //****************Here check Validate File is Uploaded or not******************/
            var dataPalletInfo = window.ExecuteScript("var data=document.getElementById('lblPalletImageError').innerHTML; return data;");
            string msgPalletInfo = dataPalletInfo.ToString().Trim();
            if (msgPalletInfo != "")
            {
                string screenShotName = "PalletInfoFileIs_NotUploading";
                screenShot(screenShotName);
            }
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Assert.AreEqual("", msgPalletInfo, msgPalletInfo);
            Thread.Sleep(min);
            Click<HtmlCustom>(PropertyType.Id, "ContentPlaceHolder1_btnSave");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void searchAndDelete()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            try
            {
                Click<HtmlHeaderCell>(PropertyType.InnerText, "Action");
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtProductCode", ExcelDataTable.ReadData(1, "product code1"));
            }
            catch (Exception e) { }
            Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearch");
            Thread.Sleep(min);
            var data = window.ExecuteScript("var data=document.getElementById('spnSearchError').innerHTML; return data;");
            string msg = data.ToString().Trim();
            if (msg != "")
            {
                string screenShotName = "PleaseEnterSearch_Criteria";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", msg, msg);
            Thread.Sleep(min);

            /************Clicking Edit Button*****************/
            Click<HtmlHeaderCell>(PropertyType.InnerText, "Action");
            int Mx = auto.MouseGetPosX();
            int My = auto.MouseGetPosY();
            My = My + 30;
            Mx = Mx + 10;
            Thread.Sleep(mid);
            auto.MouseMove(Mx, My);
            auto.MouseClick();
            Thread.Sleep(min);
            auto.Send("{ENTER}");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void addNewPackageInfo()
        {
            BrowserWindow window = new BrowserWindow();
          //IWebDriver driver = new InternetExplorerDriver();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnAddNew");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);
            try {
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtIDHCode", ExcelDataTable.ReadData(1, "addProduct Code"));
            }catch(Exception e) { }
            Thread.Sleep(max*2);
            auto.Send("{TAB}");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);

            /**********************************Search the Material No**********************************/
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtProductCode", ExcelDataTable.ReadData(1, "addProduct Code"));
            }
            catch (Exception e) { }
            Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearch");
            Thread.Sleep(min);
            var data = window.ExecuteScript("var data=document.getElementById('spnSearchError').innerHTML; return data;");
            string msg = data.ToString().Trim();
            if (msg != "")
            {
                string screenShotName = "PleaseEnterSearchCriteria";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", msg, msg);
            Thread.Sleep(min);

            /************Clicking Edit Button*****************/
            Click<HtmlHeaderCell>(PropertyType.InnerText, "Action");
            int Mx = auto.MouseGetPosX();
            int My = auto.MouseGetPosY();
            My = My + 30;
            Mx = Mx - 20;
            Thread.Sleep(mid);
            auto.MouseMove(Mx, My);
            auto.MouseClick();
            Thread.Sleep(mid);
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtSausageWeight", ExcelDataTable.ReadData(1, "addSausage Weight"));
            }catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtSausageUOM", ExcelDataTable.ReadData(1, "addSausageUOM"));
            }catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtSausageColor", ExcelDataTable.ReadData(1, "addSausageColor"));
            }
            catch (Exception e) { }
            Thread.Sleep(min);
            Click<HtmlFileInput>(PropertyType.Id, "Sausage");
            PathEnterText<WinEdit>(PropertyType.Name, "File name:", ExcelDataTable.ReadData(1, "SausageImageFilePath"));
            Thread.Sleep(max);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");

            //****************Here check Validate File is Uploaded or not******************/
            var dataSausage = window.ExecuteScript("var data=document.getElementById('lblFGUploadError').innerHTML; return data;");
            string msgSausage = dataSausage.ToString().Trim();
            if (msgSausage != "")
            {
                string screenShotName = "SausageFileIs_NotUploading";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", msgSausage, msgSausage);
            Thread.Sleep(min);

            ////////////////Packaging Info File Uploading////////////////////////
            mparentwindow = null;

            Click<HtmlFileInput>(PropertyType.Id, "Package");
            PathEnterText<WinEdit>(PropertyType.Name, "File name:", ExcelDataTable.ReadData(1, "PackageImageFilePath"));
            Thread.Sleep(mid);
            Click<HtmlDiv>(PropertyType.Id, "footer");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            //****************Here check Validate File is Uploaded or not******************/
            var dataPackingInfo = window.ExecuteScript("var data=document.getElementById('lblPackageImageError').innerHTML; return data;");
            string msgPackingInfo = dataPackingInfo.ToString().Trim();
            if (msgPackingInfo != "")
            {
                string screenShotName = "PackingInfoFileIs_NotUploading";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", msgPackingInfo, msgPackingInfo);
            Thread.Sleep(min);
            ////////////////Pallet   Info File Uploading////////////////////////
            Thread.Sleep(min);
            Click<HtmlFileInput>(PropertyType.Id, "Label");
            PathEnterText<WinEdit>(PropertyType.Name, "File name:", ExcelDataTable.ReadData(1, "LabelImageFilePath"));
            Thread.Sleep(max);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            //****************Here check Validate File is Uploaded or not******************/
            var dataLabelInfo = window.ExecuteScript("var data=document.getElementById('lblLabelImageError').innerHTML; return data;");
            string msgLabelInfo = dataLabelInfo.ToString().Trim();
            if (msgLabelInfo != "")
            {
                string screenShotName = "LabelInfoFileIs_NotUploading";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", msgLabelInfo, msgLabelInfo);
            Thread.Sleep(min);

            ////////////////Label  Info File Uploading////////////////////////
            Thread.Sleep(min);
            Click<HtmlFileInput>(PropertyType.Id, "Pallet");
            PathEnterText<WinEdit>(PropertyType.Name, "File name:", ExcelDataTable.ReadData(1, "PalletImageFilePath"));
            Thread.Sleep(max);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            //****************Here check Validate File is Uploaded or not******************/
            var dataPalletInfo = window.ExecuteScript("var data=document.getElementById('lblPalletImageError').innerHTML; return data;");
            string msgPalletInfo = dataPalletInfo.ToString().Trim();
            if (msgPalletInfo != "")
            {
                string screenShotName = "PalletInfoIs_NotUploading";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", msgPalletInfo, msgPalletInfo);
            Thread.Sleep(min);
            Click<HtmlDiv>(PropertyType.Id, "footer");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Click<HtmlCustom>(PropertyType.Id, "ContentPlaceHolder1_btnSave");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void deleteaddNewPackageInfo()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            try
            {
                Click<HtmlHeaderCell>(PropertyType.InnerText, "Action");
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtProductCode", ExcelDataTable.ReadData(1, "addProduct Code"));
            }
            catch (Exception e) { }
            Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearch");
            Thread.Sleep(min);
            var data = window.ExecuteScript("var data=document.getElementById('spnSearchError').innerHTML; return data;");
            string msg = data.ToString().Trim();
            if (msg != "")
            {
                string screenShotName = "PleaseEnterSearchCriteria";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", msg, msg);
            Thread.Sleep(min);

            /************Clicking Edit Button*****************/
            Click<HtmlHeaderCell>(PropertyType.InnerText, "Action");
            int Mx = auto.MouseGetPosX();
            int My = auto.MouseGetPosY();
            My = My + 30;
            Mx = Mx + 10;
            Thread.Sleep(mid);
            auto.MouseMove(Mx, My);
            auto.MouseClick();
            Thread.Sleep(mid);
            mparentwindow = null;
            Click<HtmlButton>(PropertyType.InnerText, "Confirm");
            //auto.Send("{ENTER}");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);           
        }
        public void SearchNoData()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);            
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtProductCode", ExcelDataTable.ReadData(1, "addProduct Code"));
            }
            catch (Exception e) { }
            Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearch");
            Thread.Sleep(min);
            var data = window.ExecuteScript("var data=document.getElementById('spnSearchError').innerHTML; return data;");
            string msg = data.ToString().Trim();
            if (msg != "")
            {
                string screenShotName = "PleaseEnterSearchCriteria";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", msg, msg);
            Thread.Sleep(max);
            /************Checking Data is deleted or Not*************/
            var data1 = window.ExecuteScript("var data=document.getElementById('ContentPlaceHolder1_tbdPackingProduct').getElementsByTagName('td')[0];  return  data.innerHTML");
            string successMsg1 = data1.ToString().Trim();
            bool b1 = successMsg1.Equals("No records found");
            if (!b1)
            {
                string screenShotName = "DataIs_NotDeleted";
                screenShot(screenShotName);
            }
            Assert.IsTrue(b1,"Data is Not Deleted");
        }

        public void pageNavigator()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlDiv>(PropertyType.Id, "footer");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");

            Click<HtmlHyperlink>(PropertyType.Id, "ctl01_hrefLast");
            Thread.Sleep(min);
            validation();
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);

            /**************Downloading Template Zip File*************/

            try
            {

                Click<HtmlSpan>(PropertyType.InnerText, "Manage Product Package Information");
            }
            catch (Exception e)
            {
                Click<HtmlSpan>(PropertyType.InnerText, "Manage Product Package Information");
            }
            Thread.Sleep(min);
            int xCoodinate = auto.MouseGetPosX();
            int yCoodinate = auto.MouseGetPosY();
            xCoodinate = xCoodinate - 320;
            auto.MouseMove(xCoodinate, yCoodinate);
            yCoodinate = yCoodinate + 40;
            auto.MouseMove(xCoodinate, yCoodinate);
            auto.MouseClick();

           
            Click<HtmlCustom>(PropertyType.Id, "ContentPlaceHolder1_btnDownloadZipTemplate");
            Thread.Sleep(max);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void validation()
        {
            BrowserWindow window = new BrowserWindow();
            Thread.Sleep(1000);
            var len = window.ExecuteScript("var data=document.getElementById('ContentPlaceHolder1_tbdPackingProduct').getElementsByTagName('td');  return  data.length");
            string length = len.ToString().Trim();
            int Data = Convert.ToInt32(length);
            bool flag = true;
            if (Data == 0)
                flag = false;

            string error = "Data is Not there On Last Navigate page";
            if (!flag)
            {
                string screenShotName = "DataI_NotThereOnLastNavigatePage";
                screenShot(screenShotName);
            }
            Assert.IsTrue(flag, error);
        }
        public void screenShot(string imgName)
        {
            BrowserWindow window = new BrowserWindow();
            string path = ConfigurationSettings.AppSettings["ScreenShot"];
            path = path + @"\\iPAS_ManageProductPackageInfo";
            Directory.CreateDirectory(path);
            try
            {
                window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
                Image image = window.CaptureImage();
                image.Save(path + "\\" + imgName + ".jpeg", ImageFormat.Jpeg);
                image.Dispose();
            }
            catch (Exception e) { }
            Console.WriteLine("Screen Shot is Avaliable in " + path + "\t" + "Folder");
        }
        public void PathEnterText<T>(PropertyType type, string propertyvalue, string text) where T : WinEdit
        {
            WinEdit genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            genericControl.FilterProperties[WinEdit.PropertyNames.Name] = propertyvalue;
            AutoItX3 auto = new AutoItX3();
            auto.WinActivate("Choose File to Upload");
            auto.Send(text);
            auto.Send("{ENTER}");
            Thread.Sleep(1000);
        }
        public void WindowButtonClick<T>(PropertyType type, string propertyvalue) where T : WinControl
        {
            WinControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Name)
                genericControl.SearchProperties[WinControl.PropertyNames.Name] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void Click<T>(PropertyType type, string propertyvalue) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });

            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;
            else if (type == PropertyType.InnerText)
            {
                genericControl.SearchProperties[HtmlControl.PropertyNames.InnerText] = propertyvalue;
            }
            else if (type == PropertyType.TagInstance)
                genericControl.FilterProperties[HtmlControl.PropertyNames.TagInstance] = propertyvalue;
            else if (type == PropertyType.Class)
                genericControl.FilterProperties[HtmlControl.PropertyNames.Class] = propertyvalue;
            Mouse.Click(genericControl);
        }
        public void EnterText<T>(PropertyType type, string propertyvalue, string text) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;

            Keyboard.SendKeys(genericControl, text);

        }
        private BrowserWindow mparentwindow { get; set; }
        public enum PropertyType
        {
            Id,
            Name,
            InnerText,
            TagInstance,
            Class
        }
        public BrowserWindow TopParentWindow()
        {

            BrowserWindow window = new BrowserWindow();
            window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
            return window;
        }
        public BrowserWindow ParentWindow
        {
            get
            {
                if (this.mparentwindow == null)
                {
                    this.mparentwindow = TopParentWindow();
                }
                return this.mparentwindow;
            }
        }

    }
}
