﻿using AutoItX3Lib;
using DataDrivenTesting;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace iPAS_ManageChangeOverInfo
{
    class ChangeOverSOP
    {
        string minsleep = ConfigurationSettings.AppSettings["min"];
        string midsleep = ConfigurationSettings.AppSettings["mid"];
        string maxsleep = ConfigurationSettings.AppSettings["max"];
        public void UploadingChangeOverSOPExcelFile()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(min);
            Click<HtmlHyperlink>(PropertyType.Id, "lnkAdmin");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkConfigPLine");
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(max);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkChangeOverInfo");
            auto.MouseClick();
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            try
            {

                Click<HtmlSpan>(PropertyType.InnerText, "Manage ChangeOver Information");
            }
            catch (Exception e)
            {
                Click<HtmlSpan>(PropertyType.InnerText, "Manage ChangeOver Information");
            }
            Thread.Sleep(min);
            int xCoodinate = auto.MouseGetPosX();
            int yCoodinate = auto.MouseGetPosY();
            xCoodinate = xCoodinate - 320;
            auto.MouseMove(xCoodinate, yCoodinate);
            yCoodinate = yCoodinate + 80;
            auto.MouseMove(xCoodinate, yCoodinate);
            auto.MouseClick();

            Click<HtmlCustom>(PropertyType.Id, "btnUploadData");
            Click<HtmlFileInput>(PropertyType.Id, "ContentPlaceHolder1_uploadFile");
            PathEnterText<WinEdit>(PropertyType.Name, "File name:", ExcelDataTable.ReadData(1, "filePath"));
            Thread.Sleep(max * 3);
            //****************Here check Validate File is Uploaded or not******************/
            var data = window.ExecuteScript("var data=document.getElementById('lblUploadError').innerHTML; return data;");
            string msg = data.ToString().Trim();
            if (msg != "")
            {
                string screenShotName = "FileIs_NotUploading";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", msg, msg);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void addProductionLine()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtChangeOverName", ExcelDataTable.ReadData(1, "ChangeOver_Name"));
            }catch(Exception e) { }
            Thread.Sleep(min);
            Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearch");
            Thread.Sleep(mid);
            //var EditId1 = window.ExecuteScript("var data=document.querySelectorAll('td'); return data;");
            //var EditId = window.ExecuteScript("var data=document.querySelectorAll('td'); return data[1].id;");
            //string id = EditId.ToString();
            //string temp = string.Empty;
            //int val=0;

            //for (int i = 0; i < id.Length; i++)
            //{
            //    if (Char.IsDigit(id[i]))
            //        temp += id[i];
            //}
            //if (temp.Length > 0)
            //    val = int.Parse(temp);//Accessing the ID value 

            //Thread.Sleep(mid); 

            Click<HtmlCell>(PropertyType.InnerText, ExcelDataTable.ReadData(1, "ChangeOver_Name"));
            int Mx = auto.MouseGetPosX();
            int My = auto.MouseGetPosY();
            Mx = Mx + 210;
            Thread.Sleep(mid);
            auto.MouseMove(Mx, My);
            auto.MouseClick();          
            Thread.Sleep(min);
            mparentwindow = null;
            Thread.Sleep(mid);
            try {
                Click<HtmlCheckBox>(PropertyType.Id, "chkPline_7");
            }catch(Exception e) { }
            Thread.Sleep(mid);
            //Here Check Production Line is added Or Not
            var data = window.ExecuteScript("var data=document.getElementById('spnFooterMessage').innerHTML; return data;");
            string msg = data.ToString().Trim();
            if (msg != "Production line added successfully")
            {
                string screenShotName = "ProductionLine_NotAddedSuccessfully";
                screenShot(screenShotName);
            }
            Assert.AreEqual("Production line added successfully", msg, msg);

            try { 
            Click<HtmlCheckBox>(PropertyType.Id, "chkPline_4");
            }catch (Exception e) { }
            Thread.Sleep(min);
            Click<HtmlCheckBox>(PropertyType.Id, "chkPline_3");
            Thread.Sleep(min);
            try { 
            Click<HtmlButton>(PropertyType.Id, "closeModal");
            }catch (Exception e) { }
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
          ///  addStep(val);
        }
        public void addStep()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtChangeOverName", ExcelDataTable.ReadData(1, "ChangeOver_Name"));
            }
            catch (Exception e) { }
            Thread.Sleep(min);
            Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearch");
            Thread.Sleep(min);
            Click<HtmlHeaderCell>(PropertyType.InnerText,  "Action");
            int Mx = auto.MouseGetPosX();
            int My = auto.MouseGetPosY();
            My = My + 30;
            Mx = Mx - 30;
            Thread.Sleep(mid);
            auto.MouseMove(Mx, My);
            auto.MouseClick();
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            /* Adding Step*/
            Click<HtmlCustom>(PropertyType.Id, "ContentPlaceHolder1_addStepButton");
            mparentwindow = null;
            Thread.Sleep(min);
            try {
                EnterText<HtmlEdit>(PropertyType.Id, "ucChangeOverControl_1_txtStepName", ExcelDataTable.ReadData(1, "Step Name"));
            }catch(Exception e) { }
            try {
                EnterText<HtmlEdit>(PropertyType.Id, "ucChangeOverControl_1_txtStandaredTime",ExcelDataTable.ReadData(1, "Standard Time"));
             }catch(Exception e) { }
            try
            {
                EnterText<HtmlComboBox>(PropertyType.Id, "ucChangeOverControl_1_drpUnits", ExcelDataTable.ReadData(1, "Unit"));
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlTextArea>(PropertyType.Id, "ucChangeOverControl_1_txtChangeOverWhat", ExcelDataTable.ReadData(1, "What"));
            }
            catch (Exception e) { }           
            try
            {                           
                EnterText<HtmlTextArea>(PropertyType.Id, "ucChangeOverControl_1_txtChangeOverWhy", ExcelDataTable.ReadData(1, "Why"));
            }
            catch (Exception e) { }
            Click<HtmlDiv>(PropertyType.Id, "footer");
            try
            {
                EnterText<HtmlTextArea>(PropertyType.Id, "ucChangeOverControl_1_txtSafetyInstructions", ExcelDataTable.ReadData(1, "Safety Instructions"));
            }
            catch (Exception e) { }
            try {
                Click<HtmlCheckBox>(PropertyType.Id, "chkPPEImage_1");
            }catch (Exception e) { }           
            try
            {
                Click<HtmlCheckBox>(PropertyType.Id, "chkPPEImage_3");
            }catch (Exception e) { }
            try
            {
                EnterText<HtmlTextArea>(PropertyType.Id, "ucChangeOverControl_1_txtKeyPoint", ExcelDataTable.ReadData(1, "Key Point"));
            }
            catch (Exception e) { }

          //  Click<HtmlSpan>(PropertyType.Id, "spanShowMessage");
            Thread.Sleep(min);
            try
            {
                Click<HtmlFileInput>(PropertyType.Id, "ucChangeOverControl_1_fileToUpload");
                PathEnterText<WinEdit>(PropertyType.Name, "File name:", ExcelDataTable.ReadData(1, "whatFile"));
            }
            catch (Exception e) { }
            //mparentwindow = null;
            Thread.Sleep(mid);
            //****************Here check Validate File is Uploaded or not******************/
            var data = window.ExecuteScript("var data=document.getElementById('spnUploadMessage').innerHTML; return data;");
            string msg = data.ToString().Trim();
            if (msg != "")
            {
                string screenShotName = "FileIs_NotUploading";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", msg, msg);
            Thread.Sleep(mid);
            mparentwindow = null;
            Thread.Sleep(min);
            
            Click<HtmlDiv>(PropertyType.Id, "footer");
            Thread.Sleep(mid);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);

            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnSaveChangeOver");
            Thread.Sleep(max);
            var data1 = window.ExecuteScript("var data=document.getElementById('spnAddEditMessage').innerHTML; return data;");
            string msg1 = data1.ToString().Trim();
            if (msg1 != "")
            {
                string screenShotName = "_NotAddChangeOver";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", msg1, msg1);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            //string id = string.Empty;
            //id = "ucNonEditChangeOverInfo_" + val + "_deletePhaseInfoLink";
            //Click<HtmlCustom>(PropertyType.Id,id);
            //Thread.Sleep(min);
            //auto.Send("{ENTER}");
            //Thread.Sleep(min);
            //auto.Send("{F5}");
            //Thread.Sleep(mid);
        }
        public void printUploadingSOPExcelFile()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
           // Click<HtmlHyperlink>(PropertyType.InnerText, "ContentPlaceHolder1_lnkAdminTab");
            Click<HtmlCustom>(PropertyType.Id, "lnkAdminTab");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtChangeOverName", ExcelDataTable.ReadData(1, "ChangeOver_Name"));
            }
            catch (Exception e) { }
            Thread.Sleep(min);
            Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearch");
            Thread.Sleep(min);
            Click<HtmlHeaderCell>(PropertyType.InnerText, "Action");
            int Mx = auto.MouseGetPosX();
            int My = auto.MouseGetPosY();
            My = My + 30;
            Mx = Mx + 25;
            Thread.Sleep(mid);
            auto.MouseMove(Mx, My);
            auto.MouseClick();
            Thread.Sleep(max * 10);
            Click<HtmlDiv>(PropertyType.Id, "footer");
            try {
                WindowButtonClick<WinToolBar>(PropertyType.Name, "Notification");
                WindowButtonClick<WinButton>(PropertyType.Name, "Open");
            }catch(Exception e) { }
            mparentwindow = null;
            Thread.Sleep(max * 15);
            auto.WinClose("Adobe Reader");
            auto.Send("{ALT}{SPACE}");
            Thread.Sleep(min);
            auto.Send("{C}");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);            
            
        }
        public void deleteUploadingSOPExcelFile() {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            /******************Deleting The Data****************/
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "txtChangeOverName");
                auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                auto.Send("{DEL 20}");
                EnterText<HtmlEdit>(PropertyType.Id, "txtChangeOverName", ExcelDataTable.ReadData(1, "ChangeOver_Name"));
            }
            catch (Exception e) { }
            Thread.Sleep(min);
            Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearch");
            Thread.Sleep(min);
            Click<HtmlHeaderCell>(PropertyType.InnerText, "Action");
            int Mx1 = auto.MouseGetPosX();
            int My1 = auto.MouseGetPosY();
            My1 = My1 + 30;
            Mx1 = Mx1 - 5;
            Thread.Sleep(mid);
            auto.MouseMove(Mx1, My1);
            auto.MouseClick();
            Thread.Sleep(min);           
            auto.Send("{ENTER}");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void screenShot(string imgName)
        {
            BrowserWindow window = new BrowserWindow();
            string path = ConfigurationSettings.AppSettings["ScreenShot"];
            path = path + @"\\iPAS_ManageChangeOverInfo";
            Directory.CreateDirectory(path);
            try
            {
                window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
                Image image = window.CaptureImage();
                image.Save(path + "\\" + imgName + ".jpeg", ImageFormat.Jpeg);
                image.Dispose();
            }
            catch (Exception e) { }
            Console.WriteLine("Screen Shot is Avaliable in " + path + "\t" + "Folder");
        }

        public void PathEnterText<T>(PropertyType type, string propertyvalue, string text) where T : WinEdit
        {
            WinEdit genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            genericControl.FilterProperties[WinEdit.PropertyNames.Name] = propertyvalue;
            AutoItX3 auto = new AutoItX3();
            auto.WinActivate("Choose File to Upload");
            auto.Send(text);
            auto.Send("{ENTER}");
            Thread.Sleep(1000);
        }
        public void WindowButtonClick<T>(PropertyType type, string propertyvalue) where T : WinControl
        {
            WinControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Name)
                genericControl.SearchProperties[WinControl.PropertyNames.Name] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void Click<T>(PropertyType type, string propertyvalue) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });

            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;
            else if (type == PropertyType.InnerText)
            {
                genericControl.SearchProperties[HtmlControl.PropertyNames.InnerText] = propertyvalue;
            }
            else if (type == PropertyType.TagInstance)
                genericControl.FilterProperties[HtmlControl.PropertyNames.TagInstance] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void EnterText<T>(PropertyType type, string propertyvalue, string text) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;

            Keyboard.SendKeys(genericControl, text);

        }
        private BrowserWindow mparentwindow { get; set; }
        public enum PropertyType
        {
            Id,
            Name,
            InnerText,
            TagInstance
        }
        public BrowserWindow TopParentWindow()
        {

            BrowserWindow window = new BrowserWindow();
            window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
            return window;
        }
        public BrowserWindow ParentWindow
        {
            get
            {
                if (this.mparentwindow == null)
                {
                    this.mparentwindow = TopParentWindow();
                }
                return this.mparentwindow;
            }
        }


    }
}
