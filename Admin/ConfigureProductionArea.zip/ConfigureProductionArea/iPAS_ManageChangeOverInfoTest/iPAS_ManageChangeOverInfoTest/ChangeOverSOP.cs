﻿using AutoItX3Lib;
using DataDrivenTesting;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace iPAS_ManageChangeOverInfo
{
    class ChangeOverSOP
    {
        string minsleep = ConfigurationSettings.AppSettings["min"];
        string midsleep = ConfigurationSettings.AppSettings["mid"];
        string maxsleep = ConfigurationSettings.AppSettings["max"];
        public void UploadingChangeOverSOPExcelFile()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(min);
            Click<HtmlHyperlink>(PropertyType.Id, "lnkAdmin");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkConfigPLine");
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(max);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkChangeOverInfo");
            auto.MouseClick();
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            try
            {

                Click<HtmlSpan>(PropertyType.InnerText, "Manage ChangeOver Information");
            }
            catch (Exception e)
            {
                Click<HtmlSpan>(PropertyType.InnerText, "Manage ChangeOver Information");
            }
            Thread.Sleep(min);
            int xCoodinate = auto.MouseGetPosX();
            int yCoodinate = auto.MouseGetPosY();
            xCoodinate = xCoodinate - 320;
            auto.MouseMove(xCoodinate, yCoodinate);
            yCoodinate = yCoodinate + 90;
            auto.MouseMove(xCoodinate, yCoodinate);
            auto.MouseClick();

            Click<HtmlCustom>(PropertyType.Id, "btnUploadData");
            Click<HtmlFileInput>(PropertyType.Id, "ContentPlaceHolder1_uploadFile");
            PathEnterText<WinEdit>(PropertyType.Name, "File name:", ExcelDataTable.ReadData(1, "filePath"));
            Thread.Sleep(max * 10);
            //****************Here check Validate File is Uploaded or not******************/
            var data = window.ExecuteScript("var data=document.getElementById('lblUploadError').innerHTML; return data;");
            string msg = data.ToString().Trim();
            if (msg!="")
            {
                string screenShotName = "FileIs_NotUploading";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", msg, msg);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }     
       public void checkAvailability()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "txtChangeOverName");
                auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                auto.Send("{DEL 20}");
                EnterText<HtmlEdit>(PropertyType.Id, "txtChangeOverName", ExcelDataTable.ReadData(1, "ChangeOver_Name"));
            }
            catch (Exception e) { }
            Thread.Sleep(min);
            Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearch");
            Thread.Sleep(mid);

            bool b1 = SearchNoData();
            if (!b1)
            {
                string screenShotName = "DataIs_NotUploaded";
                screenShot(screenShotName);
            }
            Assert.IsTrue(b1, "Data is Not Uploaded");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public bool SearchNoData()
        {
            BrowserWindow window = new BrowserWindow();
            Thread.Sleep(500);
            string successMsg = string.Empty;
            try {
                var data = window.ExecuteScript("var data=document.getElementById('ContentPlaceHolder1_tbChangeOverInfo').getElementsByTagName('span')[0];  return  data.innerHTML");
                successMsg = data.ToString().Trim();
            }
            catch (Exception e) { }
            bool b1 = successMsg.Equals("");
            return b1;
        }
        public void deleteUploadingSOPExcelFile() {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid*2);
            /******************Deleting The Data****************/
            Click<HtmlHyperlink>(PropertyType.Id, "changeOverSOPLink");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "txtChangeOverName");
                auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                auto.Send("{DEL 20}");
                EnterText<HtmlEdit>(PropertyType.Id, "txtChangeOverName", ExcelDataTable.ReadData(1, "ChangeOver_Name"));
            }
            catch (Exception e) { }
            Thread.Sleep(min);
            Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearch");
            Thread.Sleep(min);
            Click<HtmlHeaderCell>(PropertyType.InnerText, "Action");
            int Mx1 = auto.MouseGetPosX();
            int My1 = auto.MouseGetPosY();
            My1 = My1 + 30;
            Mx1 = Mx1 - 5;
            Thread.Sleep(mid);
            auto.MouseMove(Mx1, My1);
            auto.MouseClick();
            Thread.Sleep(min);           
            auto.Send("{ENTER}");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }

        public void screenShot(string imgName)
        {
            BrowserWindow window = new BrowserWindow();
            string path = ConfigurationSettings.AppSettings["ScreenShot"];
            path = path + @"\\iPAS_ManageChangeOverInfoTest";
            Directory.CreateDirectory(path);
            try
            {
                window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
                Image image = window.CaptureImage();
                image.Save(path + "\\" + imgName + ".jpeg", ImageFormat.Jpeg);
                image.Dispose();
            }
            catch (Exception e) { }
            Console.WriteLine("Screen Shot is Avaliable in " + path + "\t" + "Folder");
        }
        public void PathEnterText<T>(PropertyType type, string propertyvalue, string text) where T : WinEdit
        {
            WinEdit genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            genericControl.FilterProperties[WinEdit.PropertyNames.Name] = propertyvalue;
            AutoItX3 auto = new AutoItX3();
            auto.WinActivate("Choose File to Upload");
            auto.Send(text);
            auto.Send("{ENTER}");
            Thread.Sleep(1000);
        }
        public void WindowButtonClick<T>(PropertyType type, string propertyvalue) where T : WinControl
        {
            WinControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Name)
                genericControl.SearchProperties[WinControl.PropertyNames.Name] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void Click<T>(PropertyType type, string propertyvalue) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });

            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;
            else if (type == PropertyType.InnerText)
            {
                genericControl.SearchProperties[HtmlControl.PropertyNames.InnerText] = propertyvalue;
            }
            else if (type == PropertyType.TagInstance)
                genericControl.FilterProperties[HtmlControl.PropertyNames.TagInstance] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void EnterText<T>(PropertyType type, string propertyvalue, string text) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;

            Keyboard.SendKeys(genericControl, text);

        }
        private BrowserWindow mparentwindow { get; set; }
        public enum PropertyType
        {
            Id,
            Name,
            InnerText,
            TagInstance
        }
        public BrowserWindow TopParentWindow()
        {

            BrowserWindow window = new BrowserWindow();
            window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
            return window;
        }
        public BrowserWindow ParentWindow
        {
            get
            {
                if (this.mparentwindow == null)
                {
                    this.mparentwindow = TopParentWindow();
                }
                return this.mparentwindow;
            }
        }


    }
}
