﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Text;
using System.Threading.Tasks;

namespace iPAS_ProductGroups
{
    class ProductGroupLanguageTemplate
    {
        static CultureInfo ci = null;
        static ResourceManager rm = null;
        static string resMsg_AddProductGroupSuccess = string.Empty;
        public string Msg_AddProductGroupSuccess
        {
            get { return resMsg_AddProductGroupSuccess; }
            set { resMsg_AddProductGroupSuccess = value; }
        }

        static string resMsg_ProductGroupUpdatedSuccess = string.Empty;
        public string Msg_ProductGroupUpdatedSuccess
        {
            get { return resMsg_ProductGroupUpdatedSuccess; }
            set { resMsg_ProductGroupUpdatedSuccess = value; }
        }
        static string resMsg_NoRecordsFound = string.Empty;
        public string Msg_NoRecordsFound
        {
            get { return resMsg_NoRecordsFound; }
            set { resMsg_NoRecordsFound = value; }
        }
        public static void messageResource(string languageCode)
        {
            if (languageCode == "zh-CN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ManageChangeOverInfoTest.resources.ProductGroupCN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "th-TH")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ManageChangeOverInfoTest.resources.ProductGroupTH", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ManageChangeOverInfoTest.resources.ProductGroupEN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
        }
        public static void messageInitialize()
        {
            resMsg_AddProductGroupSuccess = rm.GetString("resMsg_AddProductGroupSuccess", ci).Trim();
            resMsg_ProductGroupUpdatedSuccess = rm.GetString("resMsg_ProductGroupUpdatedSuccess", ci).Trim();
            resMsg_NoRecordsFound = rm.GetString("resMsg_NoRecordsFound", ci).Trim();
        }
    }
}
