﻿using AutoItX3Lib;
using Microsoft.VisualStudio.TestTools.UITesting;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using DataDrivenTesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using System.Drawing;
using System.Drawing.Imaging;

namespace iPAS_ManageProductionLine
{
    class UploadingExcelFile
    {
        string minsleep = ConfigurationSettings.AppSettings["min"];
        string midsleep = ConfigurationSettings.AppSettings["mid"];
        string maxsleep = ConfigurationSettings.AppSettings["max"];
        AddPLineLanguageTemplate languageResouce = new AddPLineLanguageTemplate();
        public void uploadExcel()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(min);
            Click<HtmlHyperlink>(PropertyType.Id, "lnkAdmin");
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkConfigPLine");
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkPline");
            Thread.Sleep(min);
            auto.MouseClick();
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);

            try
            {

                Click<HtmlSpan>(PropertyType.InnerText, "Manage production Line");
            }
            catch (Exception e)
            {
                Click<HtmlSpan>(PropertyType.InnerText, "Manage production Line");
            }
            Thread.Sleep(min);
            int xCoodinate = auto.MouseGetPosX();
            int yCoodinate = auto.MouseGetPosY();
            xCoodinate = xCoodinate - 320;
            auto.MouseMove(xCoodinate, yCoodinate);
            yCoodinate = yCoodinate + 40;
            auto.MouseMove(xCoodinate, yCoodinate);
            auto.MouseClick();


            try
            {
                EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpUploadType", ExcelDataTable.ReadData(1, "Upload Type"));
            }catch(Exception e) { }
            Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnUploadLabels");
            Click<HtmlFileInput>(PropertyType.Id, "ContentPlaceHolder1_uploadFile");
            PathEnterText<WinEdit>(PropertyType.Name, "File name:", ExcelDataTable.ReadData(1, "filePath"));
            Thread.Sleep(mid);
            /****************Here check Validate File is Uploaded or not******************/
            var data = window.ExecuteScript("var data=document.getElementById('lblUploadError').innerHTML; return data;");
            string msg = data.ToString().Trim();

            if (msg!="")
            {
                string screenShotName = "FileIs_NotUploading";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", msg, msg);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);

            try
            {

                Click<HtmlSpan>(PropertyType.InnerText, "Manage production Line");
            }
            catch (Exception e)
            {
                Click<HtmlSpan>(PropertyType.InnerText, "Manage production Line");
            }
            Thread.Sleep(min);
            int xCoodinate1 = auto.MouseGetPosX();
            int yCoodinate1 = auto.MouseGetPosY();
            xCoodinate1 = xCoodinate1 - 320;
            auto.MouseMove(xCoodinate1, yCoodinate1);
            yCoodinate1 = yCoodinate1 + 40;
            auto.MouseMove(xCoodinate1, yCoodinate1);
            auto.MouseClick();

            /*Another Excel file is uploading*/
            EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpUploadType", ExcelDataTable.ReadData(1, "Upload Type1"));
            Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnUploadLabels");
            Click<HtmlFileInput>(PropertyType.Id, "ContentPlaceHolder1_uploadFile");
            PathEnterText<WinEdit>(PropertyType.Name, "File name:", ExcelDataTable.ReadData(1, "filePath1"));
            Thread.Sleep(mid);
            /****************Here check Validate File is Uploaded or not******************/
            var data1 = window.ExecuteScript("var data=document.getElementById('lblUploadError').innerHTML; return data;");
            string msg1 = data1.ToString().Trim();
            if (msg1 != "")
            {
                string screenShotName = "FileIs_NotUploading";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", msg1, msg1);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void UpdateUploadedExcelFile()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);

            /*Here clicking on Edit Button to Update the Data*/

            mparentwindow = null;
            Click<HtmlDiv>(PropertyType.InnerText, ExcelDataTable.ReadData(1, "Production Line"));
            Thread.Sleep(min);
            int xCoodinate = auto.MouseGetPosX();
            int yCoodinate = auto.MouseGetPosY();
            xCoodinate = xCoodinate - 127;
            auto.MouseMove(xCoodinate, yCoodinate);
            Thread.Sleep(mid);
            auto.MouseClick();
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);

            try
            {
                Click<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtWorkshop");
                auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                auto.Send("{DEL 20}");
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtWorkshop", ExcelDataTable.ReadData(1, "UpWorkshop"));
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlRadioButton>(PropertyType.Id, "ContentPlaceHolder1_rbWorkingDays_2");
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlRadioButton>(PropertyType.Id, "ContentPlaceHolder1_rbShift_2");
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtShiftLength");
                auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                auto.Send("{DEL 20}");
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtShiftLength", ExcelDataTable.ReadData(1, "UpShift Length"));
            }
            catch (Exception e) { }

            try
            {
                EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpWeekDays", ExcelDataTable.ReadData(1, "UpWeek Start Day"));

            }catch (Exception e) { }
             try
            {
                EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_PickStartTime_lstHour", "07");
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_PickStartTime_lstmin", "45");
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtSupplyArea");
                auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                auto.Send("{DEL 20}");
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtSupplyArea", ExcelDataTable.ReadData(1, "UpStorage Type"));
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtSupplyBin");
                auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                auto.Send("{DEL 20}");
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtSupplyBin", ExcelDataTable.ReadData(1, "UpSupply Bin"));
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtBulkArea");
                auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                auto.Send("{DEL 20}");
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtBulkArea", ExcelDataTable.ReadData(1, "UpBulk Supply Area"));
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtBulkBin");
                auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                auto.Send("{DEL 20}");
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtBulkBin", ExcelDataTable.ReadData(1, "UpBulk Supply Bin"));
            }
            catch (Exception e) { }
            try
            {

                Click<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtStagingArea");
                auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                auto.Send("{DEL 20}");
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtStagingArea", ExcelDataTable.ReadData(1, "UpStaging Area"));
            }

            catch (Exception e) { }
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtStagingBin");
                auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                auto.Send("{DEL 20}");
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtStagingBin", ExcelDataTable.ReadData(1, "UpStaging Bin"));
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtStorageType");
                auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                auto.Send("{DEL 20}");
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtStorageType", ExcelDataTable.ReadData(1, "UpEnable Kanban Staging"));
            }
            catch (Exception e) { }
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtMaxPOGroup");
                auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                auto.Send("{DEL 20}");
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtMaxPOGroup", ExcelDataTable.ReadData(1, "UpMaximum No Of POGroup"));
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtFGStorageType");
                auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                auto.Send("{DEL 20}");
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtFGStorageType", ExcelDataTable.ReadData(1, "UpFG Storage Type"));
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtFGPutAwayLocation");
                auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                auto.Send("{DEL 20}");
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtFGPutAwayLocation", ExcelDataTable.ReadData(1, "UpFG Put Away Location"));
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlDiv>(PropertyType.Id, "footer");
            }catch (Exception e) { }
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            try
            {
                mparentwindow = null;
                EnterText<HtmlEdit>(PropertyType.Id, "txtProductionLineManager", ExcelDataTable.ReadData(1, "UpProduction line Manager"));
                Thread.Sleep(min);
                auto.Send("{DOWN}");
                Thread.Sleep(min);
                auto.Send("{ENTER}");
            }
            catch (Exception e) { }
            try
            {
                mparentwindow = null;
                EnterText<HtmlEdit>(PropertyType.Id, "txtProductionLineSupervisor", ExcelDataTable.ReadData(1, "UpProduction line Supervisor"));
                Thread.Sleep(min);
                auto.Send("{DOWN}");
                Thread.Sleep(min);
                auto.Send("{ENTER}");
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlDiv>(PropertyType.Id, "footer");
            }
            catch (Exception e) { }
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            Thread.Sleep(min);
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnUpdate");
            Thread.Sleep(mid);
            /*Here Check Production Line ia added or not*/
            var data = window.ExecuteScript("var data=document.getElementById('ContentPlaceHolder1_lblErrorMessage').innerHTML; return data;");
            string msg = data.ToString().Trim();
            string str = languageResouce.MsgsuccessfullyUpdatedProductionLineInfo;
            if (languageResouce.MsgsuccessfullyUpdatedProductionLineInfo != msg)
            {
                string screenShotName = "successfully_NotUpdatedProductionLineInfo";
                screenShot(screenShotName);
            }
            Assert.AreEqual(languageResouce.MsgsuccessfullyUpdatedProductionLineInfo, msg, msg);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void ProductionLineCheckList()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid*2);
            auto.Send("{UP}");
            Thread.Sleep(min);
            auto.Send("{UP}");
            Thread.Sleep(min);
            auto.Send("{UP}");
            Thread.Sleep(min);
            auto.Send("{UP}");
            Thread.Sleep(min);
            auto.Send("{UP}");
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "lnkShowPLineCheckListInfo");
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            try {
                EnterText<HtmlTextArea>(PropertyType.Id, "txtPreCheckList", ExcelDataTable.ReadData(1, "Pre-Check List Info"));
            }catch(Exception e) { }
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnAddPLineCheckList");
            Thread.Sleep(mid);
            var data = window.ExecuteScript("var data=document.getElementById('lblPLineCheckListError').innerHTML; return data;");
            string msg = data.ToString().Trim();
            if (languageResouce.MsgRecordInsert != msg)
            {
                string screenShotName = "RecordIs_NotInsert";
                screenShot(screenShotName);
            }
            Assert.AreEqual(languageResouce.MsgRecordInsert, msg, msg);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            /*Here clicking Edit Button in Production Line Check List page */
            mparentwindow = null;
            Click<HtmlCell>(PropertyType.InnerText, ExcelDataTable.ReadData(1, "Pre-Check List Info"));
            Thread.Sleep(min);
            int xCoodinate = auto.MouseGetPosX();
            int yCoodinate = auto.MouseGetPosY();
            xCoodinate = xCoodinate - 660;
            auto.MouseMove(xCoodinate, yCoodinate);
            Thread.Sleep(mid);
            auto.MouseClick();
            Thread.Sleep(min);
            try
            {
                Click<HtmlTextArea>(PropertyType.Id, "txtPreCheckList");
                auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                auto.Send("{DEL 20}");
                EnterText<HtmlTextArea>(PropertyType.Id, "txtPreCheckList", ExcelDataTable.ReadData(1, "UpPre-Check List Info"));
            }
            catch (Exception e) { }
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnAddPLineCheckList");
            Thread.Sleep(mid);
            var data1 = window.ExecuteScript("var data=document.getElementById('lblPLineCheckListError').innerHTML; return data;");
            string msg1 = data1.ToString().Trim();
            if (languageResouce.MsgRecordInsert != msg1)
            {
                string screenShotName = "RecordIs_NotUpdate";
                screenShot(screenShotName);
            }
            Assert.AreEqual(languageResouce.MsgRecordUpdate, msg1, msg1);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);

            /*Here clicking Delete Button t delete the Data*/
            //ExcelDataTable.ReadData(1, " UpPre - Check List Info")
            Click<HtmlHeaderCell>(PropertyType.InnerText, languageResouce.MsgAction);
            Thread.Sleep(min);
            int xCoodinate1 = auto.MouseGetPosX();
            int yCoodinate1 = auto.MouseGetPosY();
            yCoodinate1 = yCoodinate1 + 30;
            xCoodinate1 = xCoodinate1 + 10;
            auto.MouseMove(xCoodinate1, yCoodinate1);
            Thread.Sleep(mid);
            auto.MouseClick();
            Thread.Sleep(min);
            auto.Send("{ENTER}");
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void deleteUploadedFile()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);
           
            Click<HtmlHyperlink>(PropertyType.InnerText, "Manage Production Line");
          //  Click<HtmlHyperlink>(PropertyType.Id, "lnkShowPlineInfoInfo");
            Thread.Sleep(max);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            /*Here delete Button is clicking*/
            mparentwindow = null;
            Click<HtmlDiv>(PropertyType.InnerText, ExcelDataTable.ReadData(1, "Production Line"));
            Thread.Sleep(min);
            int xCoodinate = auto.MouseGetPosX();
            int yCoodinate = auto.MouseGetPosY();
            xCoodinate = xCoodinate - 102;
            auto.MouseMove(xCoodinate, yCoodinate);
            Thread.Sleep(mid);
            auto.MouseClick();
            Thread.Sleep(min);
            auto.Send("{ENTER}");
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void addProductionLine()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_addNewPLineButton");
            Thread.Sleep(mid);
            auto.Send("F5");
            Thread.Sleep(mid);
            Thread.Sleep(mid);
            auto.Send("F5");
            Thread.Sleep(max);
            try {
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtProdLine", ExcelDataTable.ReadData(1, "addProduction Line1"));
            }catch(Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtWorkshop", ExcelDataTable.ReadData(1, "Workshop"));
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlRadioButton>(PropertyType.Id, "ContentPlaceHolder1_rbWorkingDays_1");
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlRadioButton>(PropertyType.Id, "ContentPlaceHolder1_rbShift_1");
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtShiftLength", ExcelDataTable.ReadData(1, "Shift Length"));
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpWeekDays", ExcelDataTable.ReadData(1, "Week Start Day"));

            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_PickStartTime_lstHour", "08");
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_PickStartTime_lstmin", "30");
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtSupplyArea", ExcelDataTable.ReadData(1, "Storage Type"));
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtSupplyBin", ExcelDataTable.ReadData(1, "Supply Bin"));
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtBulkArea", ExcelDataTable.ReadData(1, "Bulk Supply Area"));
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtBulkBin", ExcelDataTable.ReadData(1, "Bulk Supply Bin"));
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtStagingArea", ExcelDataTable.ReadData(1, "Staging Area"));
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtStagingBin", ExcelDataTable.ReadData(1, "Staging Bin"));
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtStorageType", ExcelDataTable.ReadData(1, "Enable Kanban Staging"));
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtMaxPOGroup", ExcelDataTable.ReadData(1, "Maximum No Of POGroup"));
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtFGStorageType", ExcelDataTable.ReadData(1, "FG Storage Type"));
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtFGPutAwayLocation", ExcelDataTable.ReadData(1, "FG Put Away Location"));
            }
            catch (Exception e) { }
            try {
                Click<HtmlDiv>(PropertyType.Id, "footer");
            }catch(Exception e) { }
            try
            {
                mparentwindow = null;
                EnterText<HtmlEdit>(PropertyType.Id, "txtProductionLineManager", ExcelDataTable.ReadData(1, "Production line Manager"));
                Thread.Sleep(min);
                auto.Send("{DOWN}");
                Thread.Sleep(min);
               // auto.Send("{TAB}");

              auto.Send("{ENTER}");
            }
            catch (Exception e) { }
            try
            {
                mparentwindow = null;
                EnterText<HtmlEdit>(PropertyType.Id, "txtProductionLineSupervisor", ExcelDataTable.ReadData(1, "Production line Supervisor"));
                Thread.Sleep(min);
                auto.Send("{DOWN}");
                Thread.Sleep(min);
               // auto.Send("{TAB}");
              auto.Send("{ENTER}");
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlDiv>(PropertyType.Id, "footer");
                Thread.Sleep(min);
                auto.Send("{Down}");
                Thread.Sleep(min);
                auto.Send("{Down}");
                Thread.Sleep(min);
                auto.Send("{Down}");
                Thread.Sleep(min);
                auto.Send("{Down}");
                Thread.Sleep(min);
                auto.Send("{Down}");
                Thread.Sleep(min);
                auto.Send("{Down}");

            }
            catch (Exception e) { }
            Thread.Sleep(min);
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnAddProdLine");
            Thread.Sleep(mid);
            /*Here Check Production Line is added or not*/
            var data = window.ExecuteScript("var data=document.getElementById('ContentPlaceHolder1_lblErrorMessage').innerHTML; return data;");
            Thread.Sleep(min);
            string msg = data.ToString().Trim();
            if (msg!="")
            {
                string screenShotName = "ProductionLine_NotAdding ";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", msg, msg);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);
            auto.Send("{UP}");
            Thread.Sleep(min);
            auto.Send("{UP}");
            Thread.Sleep(min);
            auto.Send("{UP}");
            Thread.Sleep(min);
            auto.Send("{UP}");
            Click<HtmlHyperlink>(PropertyType.InnerText, "Manage Production Line");
            // Click<HtmlHyperlink>(PropertyType.Id, "lnkManageProductionLine");
            Thread.Sleep(max);
            auto.Send("{F5}");
            Thread.Sleep(mid);

            /*Here clicking on Edit Button to Update the Data*/

            mparentwindow = null;
            Click<HtmlDiv>(PropertyType.InnerText, ExcelDataTable.ReadData(1, "addProduction Line1"));
            Thread.Sleep(min);
            int xCoodinate = auto.MouseGetPosX();
            int yCoodinate = auto.MouseGetPosY();
            xCoodinate = xCoodinate - 127;
            auto.MouseMove(xCoodinate, yCoodinate);
            Thread.Sleep(mid);
            auto.MouseClick();
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void UpdateProductionLine()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);

            try
            {
                Click<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtWorkshop");
                auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                auto.Send("{DEL 20}");
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtWorkshop", ExcelDataTable.ReadData(1, "UpWorkshop"));
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlRadioButton>(PropertyType.Id, "ContentPlaceHolder1_rbWorkingDays_2");
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlRadioButton>(PropertyType.Id, "ContentPlaceHolder1_rbShift_2");
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtShiftLength");
                auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                auto.Send("{DEL 20}");
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtShiftLength", ExcelDataTable.ReadData(1, "UpShift Length"));
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpWeekDays", ExcelDataTable.ReadData(1, "UpWeek Start Day"));

            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_PickStartTime_lstHour", "07");
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_PickStartTime_lstmin", "45");
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtSupplyArea");
                auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                auto.Send("{DEL 20}");
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtSupplyArea", ExcelDataTable.ReadData(1, "UpStorage Type"));
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtSupplyBin");
                auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                auto.Send("{DEL 20}");
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtSupplyBin", ExcelDataTable.ReadData(1, "UpSupply Bin"));
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtBulkArea");
                auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                auto.Send("{DEL 20}");
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtBulkArea", ExcelDataTable.ReadData(1, "UpBulk Supply Area"));
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtBulkBin");
                auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                auto.Send("{DEL 20}");
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtBulkBin", ExcelDataTable.ReadData(1, "UpBulk Supply Bin"));
            }
            catch (Exception e) { }
            try
            {

                Click<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtStagingArea");
                auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                auto.Send("{DEL 20}");
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtStagingArea", ExcelDataTable.ReadData(1, "UpStaging Area"));
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtStagingBin");
                auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                auto.Send("{DEL 20}");
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtStagingBin", ExcelDataTable.ReadData(1, "UpStaging Bin"));
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtStorageType");
                auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                auto.Send("{DEL 20}");
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtStorageType", ExcelDataTable.ReadData(1, "UpEnable Kanban Staging"));
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtMaxPOGroup");
                auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                auto.Send("{DEL 20}");
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtMaxPOGroup", ExcelDataTable.ReadData(1, "UpMaximum No Of POGroup"));
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtFGStorageType");
                auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                auto.Send("{DEL 20}");
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtFGStorageType", ExcelDataTable.ReadData(1, "UpFG Storage Type"));
            }
            catch (Exception e) { }

            try
            {
                Click<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtFGPutAwayLocation");
                auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                auto.Send("{DEL 20}");
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtFGPutAwayLocation", ExcelDataTable.ReadData(1, "UpFG Put Away Location"));
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlDiv>(PropertyType.Id, "footer");
            }
            catch (Exception e) { }
            try
            {
                mparentwindow = null;
               Click<HtmlLabel>(PropertyType.InnerText, "Production line Manager");
                int x = auto.MouseGetPosX();
                int y = auto.MouseGetPosY();
                y = y + 40;
                auto.MouseMove(x,y);
                auto.MouseClick();
                EnterText<HtmlEdit>(PropertyType.Id, "txtProductionLineManager", ExcelDataTable.ReadData(1, "UpProduction line Manager"));
                Thread.Sleep(min);
                auto.Send("{DOWN}");
                Thread.Sleep(min);
                //auto.Send("{TAB}");
                auto.Send("{ENTER}");
                Thread.Sleep(min);
            }
            catch (Exception e) { }
            try
            {
                mparentwindow = null;
                Click<HtmlLabel>(PropertyType.InnerText, "Production line Supervisor");
                int x = auto.MouseGetPosX();
                int y = auto.MouseGetPosY();
                y = y + 40;
                auto.MouseMove(x, y);
                auto.MouseClick();

                //Click<HtmlImage>(PropertyType.Id, "divProductionLineSupervisor");
                EnterText<HtmlEdit>(PropertyType.Id, "txtProductionLineSupervisor", ExcelDataTable.ReadData(1, "UpProduction line Supervisor"));
                Thread.Sleep(min);
                auto.Send("{DOWN}");
                Thread.Sleep(min);
               // auto.Send("{TAB}");

                auto.Send("{ENTER}");
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlDiv>(PropertyType.Id, "footer");
                Thread.Sleep(min);
                auto.Send("{Down}");
                Thread.Sleep(min);
                auto.Send("{Down}");
                Thread.Sleep(min);
                auto.Send("{Down}");
            }
            catch (Exception e) { }
            Thread.Sleep(min);
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnUpdate");
            Thread.Sleep(mid);
            /*Here Check Production Line ia added or not*/
            var data = window.ExecuteScript("var data=document.getElementById('ContentPlaceHolder1_lblErrorMessage').innerHTML; return data;");
            string msg = data.ToString().Trim();
            string str = languageResouce.MsgsuccessfullyUpdatedProductionLineInfo;
            if (languageResouce.MsgsuccessfullyUpdatedProductionLineInfo != msg)
            {
                string screenShotName = "Successfully_NotUpdatedProductionLineInfo ";
                screenShot(screenShotName);
            }
            Assert.AreEqual(languageResouce.MsgsuccessfullyUpdatedProductionLineInfo, msg, msg);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);
            Click<HtmlHyperlink>(PropertyType.InnerText, "Manage Production Line");
          //  Click<HtmlHyperlink>(PropertyType.Id, "lnkManageProductionLine");
            Thread.Sleep(max);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            /*Here clicking on Delete Button to Delete the Data*/
            mparentwindow = null;
            Click<HtmlDiv>(PropertyType.InnerText, ExcelDataTable.ReadData(1, "addProduction Line1"));
            Thread.Sleep(min);
            int xCoodinate = auto.MouseGetPosX();
            int yCoodinate = auto.MouseGetPosY();
            xCoodinate = xCoodinate - 102;
            auto.MouseMove(xCoodinate, yCoodinate);
            Thread.Sleep(mid);
            auto.MouseClick();
            Thread.Sleep(min);
            auto.Send("{ENTER}");
            Thread.Sleep(min);
        }
        public void DownloadExcel()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            try
            {

                Click<HtmlSpan>(PropertyType.InnerText, "Manage production Line");
            }
            catch (Exception e)
            {
                Click<HtmlSpan>(PropertyType.InnerText, "Manage production Line");
            }
            Thread.Sleep(min);
            int xCoodinate = auto.MouseGetPosX();
            int yCoodinate = auto.MouseGetPosY();
            xCoodinate = xCoodinate - 320;
            auto.MouseMove(xCoodinate, yCoodinate);
            yCoodinate = yCoodinate + 40;
            auto.MouseMove(xCoodinate, yCoodinate);
            auto.MouseClick();


            EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpUploadType", ExcelDataTable.ReadData(1, "Upload Type"));
            Click<HtmlCustom>(PropertyType.Id, "ContentPlaceHolder1_downLoadTemplateLink");
            Click<HtmlDiv>(PropertyType.Id, "footer");
            Thread.Sleep(max*4);
            try {
                WindowButtonClick<WinToolBar>(PropertyType.Name, "Notification");
                WindowButtonClick<WinButton>(PropertyType.Name, "Open");
            }catch(Exception e) { }            
            mparentwindow = null;
            Thread.Sleep(max * 10);
            auto.WinClose("Microsoft Excel");
            auto.WinClose("Excel");
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void navigatePage()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            int i = 1;
            try
            {
                var pageCount = window.ExecuteScript("var data=document.getElementById('pagerControl_divPager').getElementsByTagName('a');  return  data.length");
                string len = pageCount.ToString();
                int length = Convert.ToInt32(len);
                for (i = 1; i <= length; i++)
                {
                    Click<HtmlDiv>(PropertyType.Id, "footer");
                    string tagId = "pagerControl_hrefNum" + i;
                    Thread.Sleep(mid);
                    auto.Send("{Down}");
                    Thread.Sleep(min);
                    Click<HtmlHyperlink>(PropertyType.Id, tagId);
                    validation(i);
                    Thread.Sleep(mid);
                    tagId = "";
                }
            }
            catch (Exception e) {
                string error = "Data is Not there On Navigate page No:" + i;
                Assert.IsTrue(false, error);
            }
        }
        public void validation(int i)
        {
            BrowserWindow window = new BrowserWindow();
            Thread.Sleep(1000);
            var len = window.ExecuteScript("var data=document.getElementById('ContentPlaceHolder1_productionLineListBody').getElementsByTagName('td');  return  data.length");
            string length = len.ToString().Trim();
            int Data = Convert.ToInt32(length);
            bool flag = true;
            if (Data == 0)
                flag = false;

            string error = "Data is Not there On Navigate page No:" + i;

            if (!flag)
            {
                string screenShotName = "DataIs_NotThereNavigatePageNo:"+i;
                screenShot(screenShotName);
            }
            Assert.IsTrue(flag, error);
        }
        public void screenShot(string imgName)
        {
            BrowserWindow window = new BrowserWindow();
            string path = ConfigurationSettings.AppSettings["ScreenShot"];
            path = path + @"\\iPAS_ManageProductionLine";
            Directory.CreateDirectory(path);

            try
            {
                window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
                Image image = window.CaptureImage();
                image.Save(path + "\\" + imgName + ".jpeg", ImageFormat.Jpeg);
                image.Dispose();
            }
            catch (Exception e) { }
            Console.WriteLine("Screen Shot is Avaliable in " + path + "\t" + "Folder");
        }


        public void PathEnterText<T>(PropertyType type, string propertyvalue, string text) where T : WinEdit
        {
            WinEdit genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            genericControl.FilterProperties[WinEdit.PropertyNames.Name] = propertyvalue;
            AutoItX3 auto = new AutoItX3();
            auto.WinActivate("Choose File to Upload");
            auto.Send(text);
            auto.Send("{ENTER}");
            Thread.Sleep(1000);
        }
        public void WindowButtonClick<T>(PropertyType type, string propertyvalue) where T : WinControl
        {
            WinControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Name)
                genericControl.SearchProperties[WinControl.PropertyNames.Name] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void Click<T>(PropertyType type, string propertyvalue) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });

            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;
            else if (type == PropertyType.InnerText)
            {
                genericControl.SearchProperties[HtmlControl.PropertyNames.InnerText] = propertyvalue;
            }
            else if (type == PropertyType.TagInstance)
                genericControl.FilterProperties[HtmlControl.PropertyNames.TagInstance] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void EnterText<T>(PropertyType type, string propertyvalue, string text) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;

            Keyboard.SendKeys(genericControl, text);

        }
        private BrowserWindow mparentwindow { get; set; }
        public enum PropertyType
        {
            Id,
            Name,
            InnerText,
            TagInstance
        }
        public BrowserWindow TopParentWindow()
        {

            BrowserWindow window = new BrowserWindow();
            window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
            return window;
        }
        public BrowserWindow ParentWindow
        {
            get
            {
                if (this.mparentwindow == null)
                {
                    this.mparentwindow = TopParentWindow();
                }
                return this.mparentwindow;
            }
        }


    }
}
