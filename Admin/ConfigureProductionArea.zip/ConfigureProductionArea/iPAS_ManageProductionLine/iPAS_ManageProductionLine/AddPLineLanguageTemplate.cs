﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Text;
using System.Threading.Tasks;

namespace iPAS_ManageProductionLine
{
    class AddPLineLanguageTemplate
    {
        static CultureInfo ci = null;
        static ResourceManager rm = null;
        static string successfullyUpdatedProductionLineInfo = string.Empty;
        public string MsgsuccessfullyUpdatedProductionLineInfo
        {
            get { return successfullyUpdatedProductionLineInfo; }
            set { successfullyUpdatedProductionLineInfo = value; }
        }
        static string resMsgRecordInsert = string.Empty;
        public string MsgRecordInsert
        {
            get { return resMsgRecordInsert; }
            set { resMsgRecordInsert = value; }
        }
        static string resMsgRecordUpdate = string.Empty;
        public string MsgRecordUpdate
        {
            get { return resMsgRecordUpdate; }
            set { resMsgRecordUpdate = value; }
        }
        static string resMsgAction = string.Empty;
        public string MsgAction
        {
            get { return resMsgAction; }
            set { resMsgAction = value; }
        }
        public static void messageResource(string languageCode)
        {
            if (languageCode == "zh-CN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ManageProductionLine.resources.AddPLineResourceCN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "th-TH")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ManageProductionLine.resources.AddPLineResourceTH", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ManageProductionLine.resources.AddPLineResourceEN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
        }
        public static void messageInitialize()
        {
            successfullyUpdatedProductionLineInfo = rm.GetString("successfullyUpdatedProductionLineInfo", ci).Trim();
            resMsgRecordInsert = rm.GetString("resMsgRecordInsert", ci).Trim();
            resMsgRecordUpdate = rm.GetString("resMsgRecordUpdate", ci).Trim();
            resMsgAction = rm.GetString("resMsgAction", ci).Trim();
        }

    }
}
