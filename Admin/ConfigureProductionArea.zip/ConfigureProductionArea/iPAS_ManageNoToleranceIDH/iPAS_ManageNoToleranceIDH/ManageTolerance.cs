﻿using AutoItX3Lib;
using DataDrivenTesting;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace iPAS_ManageNoToleranceIDH
{
    class ManageTolerance
    {
        string minsleep = ConfigurationSettings.AppSettings["min"];
        string midsleep = ConfigurationSettings.AppSettings["mid"];
        string maxsleep = ConfigurationSettings.AppSettings["max"];
        public void uploadingToleranceExcelFile()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(min);
            Click<HtmlHyperlink>(PropertyType.Id, "lnkAdmin");
            Thread.Sleep(max);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkConfigPLine");
            Thread.Sleep(max);
            auto.Send("{F5}");
            Thread.Sleep(max);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkStagingRule");
            Thread.Sleep(max);
            auto.Send("{F5}");
            Thread.Sleep(max);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkToleranceIDH");
            auto.MouseClick();
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlRadioButton>(PropertyType.Id, "rdoNoToleranceApplyToSpecific");
            Thread.Sleep(mid);
            mparentwindow = null;
            Click<HtmlButton>(PropertyType.InnerText, "Confirm");
            Thread.Sleep(mid);
            /******Here Checking how Many record is there befor add ********/

            //var totalbefore = window.ExecuteScript("var data=document.getElementById('spnTotalRecords').innerHTML;  return  data");
            //string tot = totalbefore.ToString().Trim();
            //int totalbeforerecord = Convert.ToInt32(totalbefore);

            try
            {

                Click<HtmlSpan>(PropertyType.InnerText, "Manage Material Tolerance");
            }
            catch (Exception e)
            {
                Click<HtmlSpan>(PropertyType.InnerText, "Manage Material Tolerance");
            }
            Thread.Sleep(min);
            int xCoodinate = auto.MouseGetPosX();
            int yCoodinate = auto.MouseGetPosY();
            xCoodinate = xCoodinate - 370;
            auto.MouseMove(xCoodinate, yCoodinate);
            yCoodinate = yCoodinate + 90;
            auto.MouseMove(xCoodinate, yCoodinate);
            auto.MouseClick();



            Click<HtmlCustom>(PropertyType.Id, "btnUploadNoToleranceIDHList");
            Click<HtmlFileInput>(PropertyType.Id, "ContentPlaceHolder1_btnUploadIDH");
            PathEnterText<WinEdit>(PropertyType.Name, "File name:", ExcelDataTable.ReadData(1, "filePath"));
            Thread.Sleep(max*4);
            //****************Here check Validate File is Uploaded or not******************/
            var data = window.ExecuteScript("var data=document.getElementById('lblUploadError').innerHTML; return data;");
            string msg = data.ToString().Trim();
            if (msg!="")
            {
                string screenShotName = "FileIs_NotUploading";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", msg, msg);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            //var afterTotal = window.ExecuteScript("var data=document.getElementById('spnTotalRecords').innerHTML;  return  data");
            //string afterTot = afterTotal.ToString().Trim();
            //int afterTotalRecords = Convert.ToInt32(afterTot);
            //totalbeforerecord = totalbeforerecord + 1;
            //Thread.Sleep(mid);
            //if (afterTotalRecords != totalbeforerecord)
            //{
            //    string screenShotName = "afterTotalRecords_NotProper";
            //    screenShot(screenShotName);
            //}
            //Assert.AreEqual(afterTotalRecords, totalbeforerecord, "Total Record value is Not Proper");
            //Thread.Sleep(mid);
            //auto.Send("{F5}");
            //Thread.Sleep(mid);
        }
        public void deleteToleranceExcelFileInfo()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
           Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);
            int i = 1;
            try
            {
                var pageCount = window.ExecuteScript("var data=document.getElementById('ctl01_divPager').getElementsByTagName('a');  return  data.length");
                string len = pageCount.ToString();
                int length = Convert.ToInt32(len);
                for (i = 1; i <= length; i++)
                {
                    string tagId = "";

                    try
                    {
                        Click<HtmlDiv>(PropertyType.Id, "footer");
                        Thread.Sleep(min);
                        tagId = "ctl01_hrefNum" + i;
                        Thread.Sleep(min);
                        auto.Send("{Down}");
                        Thread.Sleep(min);
                        auto.Send("{Down}");
                        Thread.Sleep(min);
                        auto.Send("{Down}");
                        Thread.Sleep(min);
                        auto.Send("{Down}");
                        Click<HtmlHyperlink>(PropertyType.Id, tagId);
                        Thread.Sleep(min);
                        Click<HtmlDiv>(PropertyType.Id, "footer");
                        Thread.Sleep(min);
                        Click<HtmlCell>(PropertyType.InnerText, ExcelDataTable.ReadData(1, "IDHID"));
                        int Mx = auto.MouseGetPosX();
                        int My = auto.MouseGetPosY();
                        //Mx = Mx - 190;//befor add more pager index
                        Mx = Mx - 90;
                        Thread.Sleep(mid);
                        auto.MouseMove(Mx, My);
                        auto.MouseClick();
                        Thread.Sleep(min);
                        auto.Send("{ENTER}");
                        Thread.Sleep(min);
                    } catch (Exception e) { }
                }
            }catch(Exception e) { }
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void addToleranceInfo()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            try {
                EnterText<HtmlEdit>(PropertyType.Id, "txtAddNoToleranceIDH", ExcelDataTable.ReadData(1, "addIDH_NO"));
            }catch(Exception e) { }
            Thread.Sleep(min);
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnAddNoToleranceIDH");
            Thread.Sleep(mid);
            var data1 = window.ExecuteScript("var data=document.getElementById('spnNoToleranceError').innerHTML; return data;");
            string msg1 = data1.ToString().Trim();
            if (msg1 != "Tolerance information for this material has been added successfully")
            {
                string screenShotName = "Toleranceadded_NotSuccessfully";
                screenShot(screenShotName);
            }
            Assert.AreEqual("Tolerance information for this material has been added successfully", msg1, msg1);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void deleteAddToleranceInfo()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            int i = 1;
            try
            {
                var pageCount = window.ExecuteScript("var data=document.getElementById('ctl01_divPager').getElementsByTagName('a');  return  data.length");
                string len = pageCount.ToString();
                int length = Convert.ToInt32(len);
                for (i = 1; i <= length; i++)
                {
                    string tagId = "";

                    try
                    {
                        Click<HtmlDiv>(PropertyType.Id, "footer");
                        Thread.Sleep(min);
                        tagId = "ctl01_hrefNum" + i;
                        Thread.Sleep(min);
                        auto.Send("{Down}");
                        Thread.Sleep(min);
                        auto.Send("{Down}");
                        Thread.Sleep(min);
                        auto.Send("{Down}");
                        Thread.Sleep(min);
                        auto.Send("{Down}");
                        Click<HtmlHyperlink>(PropertyType.Id, tagId);
                        Thread.Sleep(min);
                        Click<HtmlDiv>(PropertyType.Id, "footer");
                        Thread.Sleep(min);
                        Click<HtmlCell>(PropertyType.InnerText, ExcelDataTable.ReadData(1, "addIDH_NO"));
                        int Mx = auto.MouseGetPosX();
                        int My = auto.MouseGetPosY();
                        //Mx = Mx - 190;//befor add more pager index
                        Mx = Mx - 90;
                        Thread.Sleep(mid);
                        auto.MouseMove(Mx, My);
                        auto.MouseClick();
                        Thread.Sleep(min);
                        auto.Send("{ENTER}");
                        Thread.Sleep(min);
                    }
                    catch (Exception e) { }
                }
            }
            catch (Exception e) { }
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(min);
        }
        public void downloadTemplate()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            try
            {

                Click<HtmlSpan>(PropertyType.InnerText, "Manage Material Tolerance");
            }
            catch (Exception e)
            {
                Click<HtmlSpan>(PropertyType.InnerText, "Manage Material Tolerance");
            }
            Thread.Sleep(min);
            int xCoodinate = auto.MouseGetPosX();
            int yCoodinate = auto.MouseGetPosY();
            xCoodinate = xCoodinate - 370;
            auto.MouseMove(xCoodinate, yCoodinate);
            yCoodinate = yCoodinate + 90;
            auto.MouseMove(xCoodinate, yCoodinate);
            auto.MouseClick();

            Click<HtmlHyperlink>(PropertyType.Id, "btnDownloadTemplate");
            Thread.Sleep(max * 12);
            Click<HtmlDiv>(PropertyType.Id, "footer");
            try {
                WindowButtonClick<WinToolBar>(PropertyType.Name, "Notification");
                WindowButtonClick<WinButton>(PropertyType.Name, "Open");
            }catch(Exception e) { }
            mparentwindow = null;
            Thread.Sleep(max * 17);
            auto.WinClose("Microsoft Excel");
            auto.WinClose("Excel");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void DownloadtoleranceIDHList()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            auto.Send("{F5}");
            Thread.Sleep(mid);

            try
            {

                Click<HtmlSpan>(PropertyType.InnerText, "Manage Material Tolerance");
            }
            catch (Exception e)
            {
                Click<HtmlSpan>(PropertyType.InnerText, "Manage Material Tolerance");
            }
            Thread.Sleep(min);
            int xCoodinate = auto.MouseGetPosX();
            int yCoodinate = auto.MouseGetPosY();
            xCoodinate = xCoodinate - 370;
            auto.MouseMove(xCoodinate, yCoodinate);
            yCoodinate = yCoodinate + 90;
            auto.MouseMove(xCoodinate, yCoodinate);
            auto.MouseClick();

            Click<HtmlCustom>(PropertyType.Id, "ContentPlaceHolder1_btnDownloadNoToleranceIDHList");
            Thread.Sleep(max * 10);
            Click<HtmlDiv>(PropertyType.Id, "footer");
            try {
                WindowButtonClick<WinToolBar>(PropertyType.Name, "Notification");
                WindowButtonClick<WinButton>(PropertyType.Name, "Open");
            }catch(Exception e) { }
            mparentwindow = null;
            Thread.Sleep(max * 20);
            auto.WinClose("Microsoft Excel");
            auto.WinClose("Excel");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void pageNavigator()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlDiv>(PropertyType.Id, "footer");

            int i = 1;
            try
            {
                var pageCount = window.ExecuteScript("var data=document.getElementById('ctl01_divPager').getElementsByTagName('a');  return  data.length");
                string len = pageCount.ToString();
                int length = Convert.ToInt32(len);
                for (i = 1; i <length-1; i++)
                {
                    string tagId = "ctl01_hrefNum" + i;
                    Click<HtmlDiv>(PropertyType.Id, "footer");
                    Thread.Sleep(min);
                    auto.Send("{Down}");
                    Thread.Sleep(min);
                    auto.Send("{Down}");
                    Thread.Sleep(min);
                    auto.Send("{Down}");
                    Thread.Sleep(min);
                    auto.Send("{Down}");

                    Click<HtmlHyperlink>(PropertyType.Id, tagId);
                    Thread.Sleep(mid);
                    validation(i);
                    Thread.Sleep(max);
                    tagId = "";
                }
            }
            catch (Exception e)
            {
                string error = "Data is Not there On Navigate page No:" + i;
                Assert.IsTrue(false, error);
            }
            Thread.Sleep(min);
        }
        public void validation(int i)
        {
            BrowserWindow window = new BrowserWindow();
            Thread.Sleep(1000);
            var len = window.ExecuteScript("var data=document.getElementById('ContentPlaceHolder1_tbNoToleranceIDHBody').getElementsByTagName('td');  return  data.length");
            string length = len.ToString().Trim();
            int Data = Convert.ToInt32(length);
            bool flag = true;
            if (Data == 0)
                flag = false;

            string error = "Data is Not there On Navigate page No:" + i;
            if (!flag)
            {
                string screenShotName = "DataIs_NotThereON_NavigatePageNo"+i;
                screenShot(screenShotName);
            }
            Assert.IsTrue(flag, error);
        }
        public void screenShot(string imgName)
        {
            BrowserWindow window = new BrowserWindow();
            string path = ConfigurationSettings.AppSettings["ScreenShot"];
            path = path + @"\\iPAS_ManageNoToleranceIDH";
            Directory.CreateDirectory(path);
            try
            {
                window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
                Image image = window.CaptureImage();
                image.Save(path + "\\" + imgName + ".jpeg", ImageFormat.Jpeg);
                image.Dispose();
            }
            catch (Exception e) { }
            Console.WriteLine("Screen Shot is Avaliable in " + path + "\t" + "Folder");
        }
        public void PathEnterText<T>(PropertyType type, string propertyvalue, string text) where T : WinEdit
        {
            WinEdit genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            genericControl.FilterProperties[WinEdit.PropertyNames.Name] = propertyvalue;
            AutoItX3 auto = new AutoItX3();
            auto.WinActivate("Choose File to Upload");
            auto.Send(text);
            auto.Send("{ENTER}");
            Thread.Sleep(1000);
        }
        public void WindowButtonClick<T>(PropertyType type, string propertyvalue) where T : WinControl
        {
            WinControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Name)
                genericControl.SearchProperties[WinControl.PropertyNames.Name] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void Click<T>(PropertyType type, string propertyvalue) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });

            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;
            else if (type == PropertyType.InnerText)
            {
                genericControl.SearchProperties[HtmlControl.PropertyNames.InnerText] = propertyvalue;
            }
            else if (type == PropertyType.TagInstance)
                genericControl.FilterProperties[HtmlControl.PropertyNames.TagInstance] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void EnterText<T>(PropertyType type, string propertyvalue, string text) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;

            Keyboard.SendKeys(genericControl, text);
        }
        private BrowserWindow mparentwindow { get; set; }
        public enum PropertyType
        {
            Id,
            Name,
            InnerText,
            TagInstance
        }
        public BrowserWindow TopParentWindow()
        {
            BrowserWindow window = new BrowserWindow();
            window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
            return window;
        }
        public BrowserWindow ParentWindow
        {
            get
            {
                if (this.mparentwindow == null)
                {
                    this.mparentwindow = TopParentWindow();
                }
                return this.mparentwindow;
            }
        }
    }
}