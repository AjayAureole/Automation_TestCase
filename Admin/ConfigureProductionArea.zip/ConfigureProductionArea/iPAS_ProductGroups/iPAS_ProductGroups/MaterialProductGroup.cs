﻿using AutoItX3Lib;
using DataDrivenTesting;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace iPAS_ProductGroups
{
    class MaterialProductGroup
    {
        string minsleep = ConfigurationSettings.AppSettings["min"];
        string midsleep = ConfigurationSettings.AppSettings["mid"];
        string maxsleep = ConfigurationSettings.AppSettings["max"];
        public void uploadMaterialProductGroupExcelFile()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("F5");
            Thread.Sleep(max);
            Click<HtmlHyperlink>(PropertyType.Id, "materialProductGroupLink");
            Thread.Sleep(mid);
            auto.Send("F5");
            Thread.Sleep(mid);

            try
            {

                Click<HtmlSpan>(PropertyType.InnerText, "Manage ChangeOver Information");
            }
            catch (Exception e)
            {
                Click<HtmlSpan>(PropertyType.InnerText, "Manage ChangeOver Information");
            }
            Thread.Sleep(min);
            int xCoodinate = auto.MouseGetPosX();
            int yCoodinate = auto.MouseGetPosY();
            xCoodinate = xCoodinate - 320;
            auto.MouseMove(xCoodinate, yCoodinate);
            yCoodinate = yCoodinate + 90;
            auto.MouseMove(xCoodinate, yCoodinate);
            auto.MouseClick();

            Click<HtmlCustom>(PropertyType.Id, "btnUploadMaterialProductGroupExcel");
            Click<HtmlFileInput>(PropertyType.Id, "ContentPlaceHolder1_uploadFile");
            PathEnterText<WinEdit>(PropertyType.Name, "File name:", ExcelDataTable.ReadData(1, "materialfilePath"));//HCRW
            Thread.Sleep(max * 3);
            //****************Here check Validate File is Uploaded or not******************/
            var data = window.ExecuteScript("var data=document.getElementById('lblUploadError').innerHTML; return data;");
            string msg = data.ToString().Trim();
            if (msg!="")
            {
                string screenShotName = "FileIs_NotUploading";
                screenShot(screenShotName);
            }

            Assert.AreEqual("", msg, msg);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void searchAndValidate()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("F5");
            Thread.Sleep(mid);
           // Click<HtmlRadioButton>(PropertyType.Id, "rdoMaterialNumber");
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtMaterialNum", ExcelDataTable.ReadData(1, "MATERIAL NUMBER"));

            }
            catch (Exception e) { }
            //try
            //{
            //    EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpgroup",ExcelDataTable.ReadData(1, "AddGroup Name"));
            //}catch(Exception e) { }
            Thread.Sleep(min);
            Click<HtmlButton>(PropertyType.Id,"ContentPlaceHolder1_btnSearch");
            Thread.Sleep(mid);
            var data1 = window.ExecuteScript("var data=document.getElementById('spnSearchError').innerHTML; return data;");
            string msg1 = data1.ToString().Trim();
            if (msg1 != "")
            {
                string screenShotName = "PleaseEnterSearch_Criteria";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", msg1, msg1);
            Thread.Sleep(mid);
            // var EditId = window.ExecuteScript("var data=document.querySelectorAll('i'); return data[11].id;");
            string material_No=ExcelDataTable.ReadData(1, "MATERIAL NUMBER");
            string id = "ucMaterialProductGroupSummary_" + material_No + "_drpProductGroup";
            Thread.Sleep(mid);
            try
            {
                EnterText<HtmlComboBox>(PropertyType.Id, id, ExcelDataTable.ReadData(1, "UpdateGroup Name"));
            }catch(Exception e) { }
            Thread.Sleep(mid);
            id = "'" + id + "'";
            var data2 = window.ExecuteScript("var data=document.getElementById("+id+ ").innerHTML; return data;");
            
            string list = data2.ToString();
            bool b1=list.Contains(ExcelDataTable.ReadData(1, "UpdateGroup Name"));
            Assert.IsTrue(b1, "Group Name is Not Added ");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            DownloadExcelFileMsterialInfo excel = new DownloadExcelFileMsterialInfo();
            excel.downloadExcelTemplate();
            excel.DownloadAllMaterialGroups();
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);
            Click<HtmlHyperlink>(PropertyType.Id, "productGroupLink");
            auto.MouseClick();
            Thread.Sleep(mid);
            auto.Send("{F5}");          
            Thread.Sleep(mid);
        }
        public void screenShot(string imgName)
        {
            BrowserWindow window = new BrowserWindow();
            string path = ConfigurationSettings.AppSettings["ScreenShot"];
            path = path + @"\\iPAS_ProductGroups";
            Directory.CreateDirectory(path);
            try
            {
                window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
                Image image = window.CaptureImage();
                image.Save(path + "\\" + imgName + ".jpeg", ImageFormat.Jpeg);
                image.Dispose();
            }
            catch (Exception e) { }
            Console.WriteLine("Screen Shot is Avaliable in " + path + "\t" + "Folder");
        }
        public void PathEnterText<T>(PropertyType type, string propertyvalue, string text) where T : WinEdit
        {
            WinEdit genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            genericControl.FilterProperties[WinEdit.PropertyNames.Name] = propertyvalue;
            AutoItX3 auto = new AutoItX3();
            auto.WinActivate("Choose File to Upload");
            auto.Send(text);
            auto.Send("{ENTER}");
            Thread.Sleep(1000);
        }
        public void WindowButtonClick<T>(PropertyType type, string propertyvalue) where T : WinControl
        {
            WinControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Name)
                genericControl.SearchProperties[WinControl.PropertyNames.Name] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void Click<T>(PropertyType type, string propertyvalue) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });

            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;
            else if (type == PropertyType.InnerText)
            {
                genericControl.SearchProperties[HtmlControl.PropertyNames.InnerText] = propertyvalue;
            }
            else if (type == PropertyType.TagInstance)
                genericControl.FilterProperties[HtmlControl.PropertyNames.TagInstance] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void EnterText<T>(PropertyType type, string propertyvalue, string text) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;

            Keyboard.SendKeys(genericControl, text);

        }
        private BrowserWindow mparentwindow { get; set; }
        public enum PropertyType
        {
            Id,
            Name,
            InnerText,
            TagInstance
        }
        public BrowserWindow TopParentWindow()
        {

            BrowserWindow window = new BrowserWindow();
            window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
            return window;
        }
        public BrowserWindow ParentWindow
        {
            get
            {
                if (this.mparentwindow == null)
                {
                    this.mparentwindow = TopParentWindow();
                }
                return this.mparentwindow;
            }
        }
    }
}
