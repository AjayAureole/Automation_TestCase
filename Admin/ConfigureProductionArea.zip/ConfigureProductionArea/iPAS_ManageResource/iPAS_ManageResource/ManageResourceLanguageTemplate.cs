﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Text;
using System.Threading.Tasks;

namespace iPAS__Manage_Resource
{
    class ManageResourceLanguageTemplate
    {
        static CultureInfo ci = null;
        static ResourceManager rm = null;
        static string resMsg_Action = string.Empty; 
        public string Msg_Action
        {
            get { return resMsg_Action; }
            set { resMsg_Action = value; }
        }
        static string resMsg_MixerAddedSuccessfully = string.Empty;
        public string Msg_MixerAddedSuccessfully
        {
            get { return resMsg_MixerAddedSuccessfully; }
            set { resMsg_MixerAddedSuccessfully = value; }
        }
        static string resMsg_RecordInsertedSuccessfully = string.Empty;
        public string Msg_RecordInsertedSuccessfully
        {
            get { return resMsg_RecordInsertedSuccessfully; }
            set { resMsg_RecordInsertedSuccessfully = value; }
        }
        static string resMsg_RecordUpdatedSuccessfully = string.Empty;
        public string Msg_RecordUpdatedSuccessfully
        {
            get { return resMsg_RecordUpdatedSuccessfully; }
            set { resMsg_RecordUpdatedSuccessfully = value; }
        }
        static string resMsg_UpdatedMixerSuccessfully = string.Empty;
        public string Msg_UpdatedMixerSuccessfully
        {
            get { return resMsg_UpdatedMixerSuccessfully; }
            set { resMsg_UpdatedMixerSuccessfully = value; }
        }
        static string resMsg_NoRecordsFound = string.Empty;
        public string Msg_NoRecordsFound
        {
            get { return resMsg_NoRecordsFound; }
            set { resMsg_NoRecordsFound = value; }
        }


        public static void messageResource(string languageCode)
        {
            if (languageCode == "zh-CN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ManageResource.resources.ManageResourcesCN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "th-TH")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ManageResource.resources.ManageResourcesTH", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ManageResource.resources.ManageResourcesEN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
        }

         public static void messageInitialize()
        {
            resMsg_Action = rm.GetString("resMsg_Action", ci).Trim();
            resMsg_MixerAddedSuccessfully = rm.GetString("resMsg_MixerAddedSuccessfully", ci).Trim();
            resMsg_RecordInsertedSuccessfully = rm.GetString("resMsg_RecordInsertedSuccessfully", ci).Trim();
            resMsg_RecordUpdatedSuccessfully = rm.GetString("resMsg_RecordUpdatedSuccessfully", ci).Trim();
            resMsg_UpdatedMixerSuccessfully = rm.GetString("resMsg_UpdatedMixerSuccessfully", ci).Trim();
            resMsg_NoRecordsFound = rm.GetString("resMsg_NoRecordsFound", ci).Trim();

        }
    }
}
