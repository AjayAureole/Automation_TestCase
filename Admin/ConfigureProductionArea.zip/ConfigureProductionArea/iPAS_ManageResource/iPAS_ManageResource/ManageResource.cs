﻿using AutoItX3Lib;
using DataDrivenTesting;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace iPAS__Manage_Resource
{
    class ManageResource
    {
        string minsleep = ConfigurationSettings.AppSettings["min"];
        string midsleep = ConfigurationSettings.AppSettings["mid"];
        string maxsleep = ConfigurationSettings.AppSettings["max"];
        ManageResourceLanguageTemplate languageResouce = new ManageResourceLanguageTemplate();
        public void UploadingExcelFile()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(min);
            Click<HtmlHyperlink>(PropertyType.Id, "lnkAdmin");
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkConfigPLine");
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkResource");
            auto.MouseClick();
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            try
            {

                Click<HtmlSpan>(PropertyType.InnerText, " Manage Resource");
            }
            catch (Exception e)
            {
                Click<HtmlSpan>(PropertyType.InnerText, " Manage Resource");
            }
            Thread.Sleep(min);
            int xCoodinate = auto.MouseGetPosX();
            int yCoodinate = auto.MouseGetPosY();
            xCoodinate = xCoodinate - 250;
            auto.MouseMove(xCoodinate, yCoodinate);
            yCoodinate = yCoodinate + 40;
            auto.MouseMove(xCoodinate, yCoodinate);
            auto.MouseClick();

            try
            {
                EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpSelectType", ExcelDataTable.ReadData(1, "Upload Type1"));
            }
            catch (Exception e) { }
            Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnUploadLabels");
            Click<HtmlFileInput>(PropertyType.Id, "ContentPlaceHolder1_uploadFile");
            PathEnterText<WinEdit>(PropertyType.Name, "File name:", ExcelDataTable.ReadData(1, "filePath1"));
            Thread.Sleep(mid);
            //****************Here check Validate File is Uploaded or not******************/
            var data = window.ExecuteScript("var data=document.getElementById('lblUploadError').innerHTML; return data;");
            string msg = data.ToString().Trim();
            if (msg!="")
            {
                string screenShotName = "FileIs_NotUploading";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", msg, msg);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);

            /*Another Excel file is uploading*/

            try
            {

                Click<HtmlSpan>(PropertyType.InnerText, " Manage Resource");
            }
            catch (Exception e)
            {
                Click<HtmlSpan>(PropertyType.InnerText, " Manage Resource");
            }
            Thread.Sleep(min);
            int xCoodinate1 = auto.MouseGetPosX();
            int yCoodinate1 = auto.MouseGetPosY();
            xCoodinate1 = xCoodinate1 - 250;
            auto.MouseMove(xCoodinate1, yCoodinate1);
            yCoodinate1 = yCoodinate1 + 40;
            auto.MouseMove(xCoodinate1, yCoodinate1);
            auto.MouseClick();

            try
            {
                EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpSelectType", ExcelDataTable.ReadData(1, "Upload Type2"));
            }
            catch (Exception e) { }
            Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnUploadLabels");
            Click<HtmlFileInput>(PropertyType.Id, "ContentPlaceHolder1_uploadFile");
            PathEnterText<WinEdit>(PropertyType.Name, "File name:", ExcelDataTable.ReadData(1, "filePath2"));
            Thread.Sleep(mid);
            /****************Here check Validate File is Uploaded or not******************/
            var data1 = window.ExecuteScript("var data=document.getElementById('lblUploadError').innerHTML; return data;");
            string msg1 = data1.ToString().Trim();
            if (msg1 != "")
            {
                string screenShotName = "FileIs_NotUploading";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", msg1, msg1);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);

            /*Here clicking on the Edit Button to Upadte the Excel file Uploaded info*/

            Click<HtmlEdit>(PropertyType.Id, "ProductionLineSearch_3702_txtSearchItems");
            Thread.Sleep(min);
            string str = ExcelDataTable.ReadData(1, "Production Line");
            Click<HtmlLabel>(PropertyType.InnerText, ExcelDataTable.ReadData(1, "Production Line"));
            mparentwindow = null;
            Click<HtmlLabel>(PropertyType.Id, "lblPLine");
            Thread.Sleep(min);
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtMixer", ExcelDataTable.ReadData(1, "Resource Code"));
            }
            catch (Exception e) { }
            Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearch");
            Thread.Sleep(min);

            /*First click Action Header than click Edit Bouuton*/

            Click<HtmlHeaderCell>(PropertyType.InnerText, languageResouce.Msg_Action);
            Thread.Sleep(min);
            int xCoodinate11 = auto.MouseGetPosX();
            int yCoodinate11 = auto.MouseGetPosY();
            yCoodinate11 = yCoodinate11 + 30;
            xCoodinate11 = xCoodinate11 - 15;
            auto.MouseMove(xCoodinate11, yCoodinate11);
            Thread.Sleep(min);
            auto.MouseClick();
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void updateExcelUploadedData()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            try
            {
                string str = ExcelDataTable.ReadData(1, "UpProduction Line");
                EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpProdLine", ExcelDataTable.ReadData(1, "UpProduction Line"));

            }
            catch(Exception e) { }
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtResourceDesc");
                auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                auto.Send("{DEL 20}");
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtResourceDesc",ExcelDataTable.ReadData(1, "UpMixer Description"));
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlCheckBox>(PropertyType.Id, "ContentPlaceHolder1_chkRepack");
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlCheckBox>(PropertyType.Id, "ContentPlaceHolder1_chkShareable");

            }
            catch (Exception e) { }
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtMixerSize");
                auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                auto.Send("{DEL 20}");
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtMixerSize",ExcelDataTable.ReadData(1, "UpBatch Size (KG)"));
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlCheckBox>(PropertyType.Id, "ContentPlaceHolder1_ChkFillingResource");
            }
            catch (Exception e) { }
            try
            {
                string str = ExcelDataTable.ReadData(1, "UpMixingResourceFillingType");
                EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpResourceType", ExcelDataTable.ReadData(1, "UpMixingResourceFillingType"));
            }catch (Exception e) { }
            try
            {
                Thread.Sleep(mid);
                string str = ExcelDataTable.ReadData(1, "UpReferenceResource");
                EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpPLineResources", ExcelDataTable.ReadData(1, "UpReferenceResource"));
            }catch(Exception e) { }
            Thread.Sleep(min);
            Click<HtmlDiv>(PropertyType.Id, "footer");
            Thread.Sleep(max);
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnUpdate");
            Thread.Sleep(mid);
            var data = window.ExecuteScript("var data=document.getElementById('spnError').innerHTML; return data;");
            string msg = data.ToString().Trim();
            if (languageResouce.Msg_UpdatedMixerSuccessfully != msg)
            {
                string screenShotName = "UpdatedMixer_NotSuccessfully";
                screenShot(screenShotName);
            }
            Assert.AreEqual(languageResouce.Msg_UpdatedMixerSuccessfully, msg, msg);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void updatePLineCheckListInfo()
        { 
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);

            Click<HtmlCustom>(PropertyType.Id, "lnkShowPLineCheckListInfo");
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            try
            {
                EnterText<HtmlTextArea>(PropertyType.Id, "txtResourceCheck", ExcelDataTable.ReadData(1, "UpResource Check Info"));
            }
            catch (Exception e) { }
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnAddResourceCheck");
            Thread.Sleep(mid);
            var data = window.ExecuteScript("var data=document.getElementById('lblResourceCheckError').innerHTML; return data;");
            string msg = data.ToString().Trim();
            if (languageResouce.Msg_RecordInsertedSuccessfully != msg)
            {
                string screenShotName = "PLineCheckLIs_NotAdd";
                screenShot(screenShotName);
            }
            Assert.AreEqual(languageResouce.Msg_RecordInsertedSuccessfully, msg, msg);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);

            /*Editing the Add Resource Check Info */
            Click<HtmlHeaderCell>(PropertyType.InnerText, languageResouce.Msg_Action);
            Thread.Sleep(min);
            int xCoodinate1 = auto.MouseGetPosX();
            int yCoodinate1 = auto.MouseGetPosY();
            yCoodinate1 = yCoodinate1 + 30;
            xCoodinate1 = xCoodinate1 - 15;
            auto.MouseMove(xCoodinate1, yCoodinate1);
            Thread.Sleep(min);
            auto.MouseClick();
            Thread.Sleep(min);
           
            /********************************************/
            try
            {
                Click<HtmlTextArea>(PropertyType.Id, "txtResourceCheck");
                auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                auto.Send("{DEL 20}");
                EnterText<HtmlTextArea>(PropertyType.Id, "txtResourceCheck", ExcelDataTable.ReadData(1, "UpResource Check Info1"));
            }
            catch (Exception e) { }
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnAddResourceCheck");
            Thread.Sleep(mid);
            var data1 = window.ExecuteScript("var data=document.getElementById('lblResourceCheckError').innerHTML; return data;");
            string msg1 = data1.ToString().Trim();
            if (languageResouce.Msg_RecordUpdatedSuccessfully != msg1)
            {
                string screenShotName = "PLineCheckLIs_NotUpdatedSuccessfully";
                screenShot(screenShotName);
            }
            Assert.AreEqual(languageResouce.Msg_RecordUpdatedSuccessfully, msg1, msg1);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            /*Delete the Add Resource Check Info */

            Click<HtmlHeaderCell>(PropertyType.InnerText, languageResouce.Msg_Action);
            Thread.Sleep(min);
            int xCoodinate = auto.MouseGetPosX();
            int yCoodinate = auto.MouseGetPosY();
            yCoodinate = yCoodinate + 30;
            xCoodinate = xCoodinate + 10;
            auto.MouseMove(xCoodinate, yCoodinate);
            Thread.Sleep(mid);
            auto.MouseClick();
            Thread.Sleep(min);
            auto.Send("{ENTER}");
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(max);

            Click<HtmlHyperlink>(PropertyType.InnerText, "Manage Resource");

            // Click<HtmlHyperlink>(PropertyType.Id, "lnkManageResource");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void deleteUploadedExcelData()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);

            /*Here clicking on the Edit Button to Upadte the Excel file Uploaded info*/
            Click<HtmlEdit>(PropertyType.Id, "ProductionLineSearch_3702_txtSearchItems");
            Thread.Sleep(min);
            mparentwindow = null;
            Click<HtmlLabel>(PropertyType.InnerText, ExcelDataTable.ReadData(1, "UpProduction Line"));
            //int xco = auto.MouseGetPosX();
            //int yco = auto.MouseGetPosY();
            //auto.MouseMove(xco, yco);
            //auto.MouseClick();
            Thread.Sleep(min);
            Click<HtmlLabel>(PropertyType.Id, "lblPLine");
            Thread.Sleep(min);
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtMixer", ExcelDataTable.ReadData(1, "Resource Code"));
            }
            catch (Exception e) { }
            Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearch");
            Thread.Sleep(min);
            mparentwindow = null;
            Click<HtmlHeaderCell>(PropertyType.InnerText, languageResouce.Msg_Action);
            Thread.Sleep(min);
            int xCoodinate = auto.MouseGetPosX();
            int yCoodinate = auto.MouseGetPosY();
            yCoodinate = yCoodinate + 30;
            xCoodinate = xCoodinate + 10;
            auto.MouseMove(xCoodinate, yCoodinate);
            Thread.Sleep(mid);
            auto.MouseClick();
            Thread.Sleep(min);
            auto.Send("{ENTER}");
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void addManually()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_addNewResourceButton");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);

            try
            {
                EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpProdLine", ExcelDataTable.ReadData(1, "Production Line1"));

            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtResourceCode", ExcelDataTable.ReadData(1, "Mixer code"));
            }
            catch (Exception e) { }
            try
            {
               EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtResourceDesc", ExcelDataTable.ReadData(1, "Mixer Description"));
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlCheckBox>(PropertyType.Id, "ContentPlaceHolder1_chkRepack");
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlCheckBox>(PropertyType.Id, "ContentPlaceHolder1_chkShareable");

            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtMixerSize", ExcelDataTable.ReadData(1, "Batch Size (KG)"));
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlCheckBox>(PropertyType.Id, "ContentPlaceHolder1_ChkFillingResource");
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpResourceType", ExcelDataTable.ReadData(1, "MixingResourceFillingType"));
            }
            catch (Exception e) { }
            try
            {
                Thread.Sleep(mid);
                EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpPLineResources", ExcelDataTable.ReadData(1, "ReferenceResource"));
            }
            catch (Exception e) { }
            Thread.Sleep(min);
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnAddResource");
            Thread.Sleep(mid);
            var data = window.ExecuteScript("var data=document.getElementById('spnError').innerHTML; return data;");
            string msg = data.ToString().Trim();
            if (languageResouce.Msg_MixerAddedSuccessfully != msg)
            {
                string screenShotName = "Mixer_NotAddedSuccessfully";
                screenShot(screenShotName);
            }
            Assert.AreEqual(languageResouce.Msg_MixerAddedSuccessfully, msg, msg);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(max);

            Click<HtmlHyperlink>(PropertyType.InnerText, "Manage Resource");

            //Click<HtmlHyperlink>(PropertyType.Id, "lnkManageResource");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlEdit>(PropertyType.Id, "ProductionLineSearch_3702_txtSearchItems");
            Thread.Sleep(min);

            Click<HtmlLabel>(PropertyType.InnerText, ExcelDataTable.ReadData(1, "Production Line1"));
            Thread.Sleep(min);
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtMixer", ExcelDataTable.ReadData(1, "Mixer code"));
            }
            catch (Exception e) { }

            Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearch");
            Thread.Sleep(min);

            /*First click Action Header than click Edit Bouuton*/

            Click<HtmlHeaderCell>(PropertyType.InnerText, languageResouce.Msg_Action);
            Thread.Sleep(min);
            int xCoodinate1 = auto.MouseGetPosX();
            int yCoodinate1 = auto.MouseGetPosY();
            yCoodinate1 = yCoodinate1 + 30;
            xCoodinate1 = xCoodinate1 - 15;
            auto.MouseMove(xCoodinate1, yCoodinate1);
            Thread.Sleep(min);
            auto.MouseClick();
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void updateManually()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            try
            {
                EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpProdLine", ExcelDataTable.ReadData(1, "UpProduction Line"));

            }
            catch (Exception e) { }
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtResourceDesc");
                auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                auto.Send("{DEL 20}");
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtResourceDesc", ExcelDataTable.ReadData(1, "UpMixer Description"));
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlCheckBox>(PropertyType.Id, "ContentPlaceHolder1_chkRepack");
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlCheckBox>(PropertyType.Id, "ContentPlaceHolder1_chkShareable");

            }
            catch (Exception e) { }
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtMixerSize");
                auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                auto.Send("{DEL 20}");
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtMixerSize", ExcelDataTable.ReadData(1, "UpBatch Size (KG)"));
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlCheckBox>(PropertyType.Id, "ContentPlaceHolder1_ChkFillingResource");
            }
            catch (Exception e) { }
            try
            {
                string str = ExcelDataTable.ReadData(1, "UpMixingResourceFillingType");
                EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpResourceType", ExcelDataTable.ReadData(1, "UpMixingResourceFillingType"));
            }
            catch (Exception e) { }
            try
            {
                Thread.Sleep(mid);
                string str = ExcelDataTable.ReadData(1, "UpReferenceResource");
                EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpPLineResources", ExcelDataTable.ReadData(1, "UpReferenceResource"));
            }
            catch (Exception e) { }
            Thread.Sleep(min);
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnUpdate");
            Thread.Sleep(mid);
            var data = window.ExecuteScript("var data=document.getElementById('spnError').innerHTML; return data;");
            string msg = data.ToString().Trim();
            if (languageResouce.Msg_UpdatedMixerSuccessfully != msg)
            {
                string screenShotName = "Mixer_NotUpdatedSuccessfully";
                screenShot(screenShotName);
            }
            Assert.AreEqual(languageResouce.Msg_UpdatedMixerSuccessfully, msg, msg);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void addPLineCheckListInfo()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);

            Click<HtmlCustom>(PropertyType.Id, "lnkShowPLineCheckListInfo");
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            try
            {
                EnterText<HtmlTextArea>(PropertyType.Id, "txtResourceCheck", ExcelDataTable.ReadData(1, "UpResource Check Info"));
            }
            catch (Exception e) { }
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnAddResourceCheck");
            Thread.Sleep(mid);
            var data = window.ExecuteScript("var data=document.getElementById('lblResourceCheckError').innerHTML; return data;");
            string msg = data.ToString().Trim();
            if (languageResouce.Msg_RecordInsertedSuccessfully != msg)
            {
                string screenShotName = "NotaddPLineCheckListInfo";
                screenShot(screenShotName);
            }
            Assert.AreEqual(languageResouce.Msg_RecordInsertedSuccessfully, msg, msg);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);

            /*Editing the Add Resource Check Info */
            Click<HtmlHeaderCell>(PropertyType.InnerText, languageResouce.Msg_Action);
            Thread.Sleep(min);
            int xCoodinate1 = auto.MouseGetPosX();
            int yCoodinate1 = auto.MouseGetPosY();
            yCoodinate1 = yCoodinate1 + 30;
            xCoodinate1 = xCoodinate1 - 15;
            auto.MouseMove(xCoodinate1, yCoodinate1);
            Thread.Sleep(min);
            auto.MouseClick();
            Thread.Sleep(min);

            /********************************************/
            try
            {
                Click<HtmlTextArea>(PropertyType.Id, "txtResourceCheck");
                auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                auto.Send("{DEL 20}");
                EnterText<HtmlTextArea>(PropertyType.Id, "txtResourceCheck", ExcelDataTable.ReadData(1, "UpResource Check Info1"));
            }
            catch (Exception e) { }
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnAddResourceCheck");
            Thread.Sleep(mid);
            var data1 = window.ExecuteScript("var data=document.getElementById('lblResourceCheckError').innerHTML; return data;");
            string msg1 = data1.ToString().Trim();
            if (languageResouce.Msg_RecordUpdatedSuccessfully != msg1)
            {
                string screenShotName = "NotUpdatedLineCheckListInfo";
                screenShot(screenShotName);
            }
            Assert.AreEqual(languageResouce.Msg_RecordUpdatedSuccessfully, msg1, msg1);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            /*Delete the Add Resource Check Info */

            Click<HtmlHeaderCell>(PropertyType.InnerText, languageResouce.Msg_Action);
            Thread.Sleep(min);
            int xCoodinate = auto.MouseGetPosX();
            int yCoodinate = auto.MouseGetPosY();
            yCoodinate = yCoodinate + 30;
            xCoodinate = xCoodinate + 10;
            auto.MouseMove(xCoodinate, yCoodinate);
            Thread.Sleep(mid);
            auto.MouseClick();
            Thread.Sleep(min);
            auto.Send("{ENTER}");
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(max);

            Click<HtmlHyperlink>(PropertyType.InnerText, "Manage Resource");

            //Click<HtmlHyperlink>(PropertyType.Id, "lnkManageResource");
        }
        public void deletemanageResource()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);

            Click<HtmlEdit>(PropertyType.Id, "ProductionLineSearch_3702_txtSearchItems");
            Thread.Sleep(min);
            mparentwindow = null;
            Click<HtmlLabel>(PropertyType.InnerText, ExcelDataTable.ReadData(1, "UpProduction Line"));
            //int xco = auto.MouseGetPosX();
            //int yco = auto.MouseGetPosY();
            //auto.MouseMove(xco, yco);
            //auto.MouseClick();
            //Thread.Sleep(min);
            //mparentwindow = null;
            Click<HtmlLabel>(PropertyType.Id, "lblPLine");
            Thread.Sleep(min);
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtMixer", ExcelDataTable.ReadData(1, "Mixer code"));
            }
            catch (Exception e) { }
            Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearch");
            Thread.Sleep(min);
            mparentwindow = null;
            Click<HtmlHeaderCell>(PropertyType.InnerText, languageResouce.Msg_Action);
            Thread.Sleep(min);
            int xCoodinate = auto.MouseGetPosX();
            int yCoodinate = auto.MouseGetPosY();
            yCoodinate = yCoodinate + 30;
            xCoodinate = xCoodinate + 10;
            auto.MouseMove(xCoodinate, yCoodinate);
            Thread.Sleep(mid);
            auto.MouseClick();
            Thread.Sleep(min);
            auto.Send("{ENTER}");
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void screenShot(string imgName)
        {
            BrowserWindow window = new BrowserWindow();
            string path = ConfigurationSettings.AppSettings["ScreenShot"];
            path = path + @"\\iPAS_ManageResource";
            Directory.CreateDirectory(path);
            try
            {
                window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
                Image image = window.CaptureImage();
                image.Save(path + "\\" + imgName + ".jpeg", ImageFormat.Jpeg);
                image.Dispose();
            }
            catch (Exception e) { }
            Console.WriteLine("Screen Shot is Avaliable in " + path + "\t" + "Folder");
        }


        public void PathEnterText<T>(PropertyType type, string propertyvalue, string text) where T : WinEdit
        {
            WinEdit genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            genericControl.FilterProperties[WinEdit.PropertyNames.Name] = propertyvalue;
            AutoItX3 auto = new AutoItX3();
            auto.WinActivate("Choose File to Upload");
            auto.Send(text);
            auto.Send("{ENTER}");
            Thread.Sleep(1000);
        }
        public void WindowButtonClick<T>(PropertyType type, string propertyvalue) where T : WinControl
        {
            WinControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Name)
                genericControl.SearchProperties[WinControl.PropertyNames.Name] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void Click<T>(PropertyType type, string propertyvalue) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });

            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;
            else if (type == PropertyType.InnerText)
            {
                genericControl.SearchProperties[HtmlControl.PropertyNames.InnerText] = propertyvalue;
            }
            else if (type == PropertyType.TagInstance)
                genericControl.FilterProperties[HtmlControl.PropertyNames.TagInstance] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void EnterText<T>(PropertyType type, string propertyvalue, string text) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;

            Keyboard.SendKeys(genericControl, text);

        }
        private BrowserWindow mparentwindow { get; set; }
        public enum PropertyType
        {
            Id,
            Name,
            InnerText,
            TagInstance
        }
        public BrowserWindow TopParentWindow()
        {

            BrowserWindow window = new BrowserWindow();
            window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
            return window;
        }
        public BrowserWindow ParentWindow
        {
            get
            {
                if (this.mparentwindow == null)
                {
                    this.mparentwindow = TopParentWindow();
                }
                return this.mparentwindow;
            }
        }


    }
}
