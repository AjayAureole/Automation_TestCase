﻿using AutoItX3Lib;
using DataDrivenTesting;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;

namespace iPAS__Manage_Resource
{
    class DownloadingExcelFile
    {
        string minsleep = ConfigurationSettings.AppSettings["min"];
        string midsleep = ConfigurationSettings.AppSettings["mid"];
        string maxsleep = ConfigurationSettings.AppSettings["max"];
        ManageResourceLanguageTemplate language =new ManageResourceLanguageTemplate();
    public void downloadExcel()
        {           

            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            try
            {

                Click<HtmlSpan>(PropertyType.InnerText, " Manage Resource");
            }
            catch (Exception e)
            {
                Click<HtmlSpan>(PropertyType.InnerText, " Manage Resource");
            }
            Thread.Sleep(min);
            int xCoodinate = auto.MouseGetPosX();
            int yCoodinate = auto.MouseGetPosY();
            xCoodinate = xCoodinate - 250;
            auto.MouseMove(xCoodinate, yCoodinate);
            yCoodinate = yCoodinate + 40;
            auto.MouseMove(xCoodinate, yCoodinate);
            auto.MouseClick();

            EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpSelectType", ExcelDataTable.ReadData(1, "Upload Type1"));
            Thread.Sleep(min);
            Click<HtmlCustom>(PropertyType.Id, "ContentPlaceHolder1_downLoadTemplateLink");
            Thread.Sleep(max * 7);
            Click<HtmlDiv>(PropertyType.Id, "footer");
           // try {
                WindowButtonClick<WinToolBar>(PropertyType.Name, "Notification");
                WindowButtonClick<WinButton>(PropertyType.Name, "Open");
           // }catch(Exception e) { }
            mparentwindow = null;
            Thread.Sleep(max * 10);
            auto.WinClose("Microsoft Excel");
            auto.WinClose("Excel");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void pageNavigator()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlDiv>(PropertyType.Id, "footer");
            //try
            //{
            //    var pageCount = window.ExecuteScript("var data=document.getElementById('ctl01_divPager').getElementsByTagName('a');  return  data.length");
            //    string len = pageCount.ToString();
            //    int length = Convert.ToInt32(len);
            //    for (int i = 1; i <= length; i++)
            //    {
            //        string tagId = "ctl01_hrefNum" + i;
            //        Thread.Sleep(mid);
            //        if (i == 7)
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            Click<HtmlHyperlink>(PropertyType.Id, "pagerControl_hrefLast");
            Thread.Sleep(mid);
            validation();
            Thread.Sleep(max);
            //    tagId = "";
            //}
            //}
            //catch (Exception e) { }
        }

        public void SearchNoData()
        {
            string languageCode = ExcelDataTable.ReadData(1, "languageCode");
            ManageResourceLanguageTemplate.messageResource(languageCode);
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlEdit>(PropertyType.Id, "ProductionLineSearch_3702_txtSearchItems");
            Thread.Sleep(min);
            mparentwindow = null;
            Click<HtmlLabel>(PropertyType.InnerText, ExcelDataTable.ReadData(1, "UpProduction Line"));            
            Click<HtmlLabel>(PropertyType.Id, "lblPLine");
            Thread.Sleep(min);
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtMixer", ExcelDataTable.ReadData(1, "Mixer code"));
            }
            catch (Exception e) { }
            Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearch");
            Thread.Sleep(max);

            var data = window.ExecuteScript("var data=document.getElementById('ContentPlaceHolder1_resourceListBody').getElementsByTagName('span')[0];  return  data.innerHTML");
            string successMsg = data.ToString().Trim();
            bool b1 = successMsg.Equals(language.Msg_NoRecordsFound);
            if (!b1)
            {
                string screenShotName = "DataIs_NotThere_LastNavigatePage";
                screenShot(screenShotName);
            }
            Assert.IsTrue(b1, "Data is Not Deleted");
        }
        public void validation()
        {
            BrowserWindow window = new BrowserWindow();
            Thread.Sleep(1000);
            var len = window.ExecuteScript("var data=document.getElementById('ContentPlaceHolder1_resourceListBody').getElementsByTagName('td');  return  data.length");
            string length = len.ToString().Trim();
            int Data = Convert.ToInt32(length);
            bool flag = true;
            if (Data == 0)
                flag = false;

            string error = "Data is Not there On Last Navigate page";
            if (!flag)
            {
                string screenShotName = "DataIs_NotThere_LastNavigatePage";
                screenShot(screenShotName);
            }

            Assert.IsTrue(flag, error);
        }
        public void screenShot(string imgName)
        {
            BrowserWindow window = new BrowserWindow();
            string path = ConfigurationSettings.AppSettings["ScreenShot"];
            path = path + @"\\iPAS_ManageResource";
            Directory.CreateDirectory(path);
            try
            {
                window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
                Image image = window.CaptureImage();
                image.Save(path + "\\" + imgName + ".jpeg", ImageFormat.Jpeg);
                image.Dispose();
            }
            catch (Exception e) { }
            Console.WriteLine("Screen Shot is Avaliable in " + path + "\t" + "Folder");
        }
        public void PathEnterText<T>(PropertyType type, string propertyvalue, string text) where T : WinEdit
        {
            WinEdit genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            genericControl.FilterProperties[WinEdit.PropertyNames.Name] = propertyvalue;
            AutoItX3 auto = new AutoItX3();
            auto.WinActivate("Choose File to Upload");
            auto.Send(text);
            auto.Send("{ENTER}");
            Thread.Sleep(1000);
        }
        public void WindowButtonClick<T>(PropertyType type, string propertyvalue) where T : WinControl
        {
            WinControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Name)
                genericControl.SearchProperties[WinControl.PropertyNames.Name] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void Click<T>(PropertyType type, string propertyvalue) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });

            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;
            else if (type == PropertyType.InnerText)
            {
                genericControl.SearchProperties[HtmlControl.PropertyNames.InnerText] = propertyvalue;
            }
            else if (type == PropertyType.TagInstance)
                genericControl.FilterProperties[HtmlControl.PropertyNames.TagInstance] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void EnterText<T>(PropertyType type, string propertyvalue, string text) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;

            Keyboard.SendKeys(genericControl, text);

        }
        private BrowserWindow mparentwindow { get; set; }
        public enum PropertyType
        {
            Id,
            Name,
            InnerText,
            TagInstance
        }
        public BrowserWindow TopParentWindow()
        {

            BrowserWindow window = new BrowserWindow();
            window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
            return window;
        }
        public BrowserWindow ParentWindow
        {
            get
            {
                if (this.mparentwindow == null)
                {
                    this.mparentwindow = TopParentWindow();
                }
                return this.mparentwindow;
            }
        }
    }
}
