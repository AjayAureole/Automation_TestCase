﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Text;
using System.Threading.Tasks;

namespace iPAS_SamplingInstructionWrongUpload
{
    class ManageSamplingInstructionsLanguageTemplate
    {
        static CultureInfo ci = null;
        static ResourceManager rm = null;
        static string res_MsgNoRecordsFound = string.Empty;
        public string MsgNoRecordsFound
        {
            get { return res_MsgNoRecordsFound; }
            set { res_MsgNoRecordsFound = value; }
        }
        public static void messageResource(string languageCode)
        {

            ci = new CultureInfo(languageCode);
            rm = new ResourceManager("iPAS_SamplingInstructionWrongUpload.resource.ManageSamplingInstructionsEN", Assembly.GetExecutingAssembly());
            messageInitialize();

        }
        public static void messageInitialize()
        {
            res_MsgNoRecordsFound = rm.GetString("res_MsgNoRecordsFound", ci).Trim();
        }
    }
}
