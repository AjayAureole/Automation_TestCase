﻿using AutoItX3Lib;
using DataDrivenTesting;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace iPAS_IDHCharacterWrongMaterialUploading
{
    class DGCharactersticInfo
    {
        string minsleep = ConfigurationSettings.AppSettings["min"];
        string midsleep = ConfigurationSettings.AppSettings["mid"];
        string maxsleep = ConfigurationSettings.AppSettings["max"];
        IDH_CharaterLanguageTemplate IDHLanguage = new IDH_CharaterLanguageTemplate();

        public void uploadingExcel(int i)
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(min);
            Click<HtmlHyperlink>(PropertyType.Id, "lnkAdmin");
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(max);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkGRIndex");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkIDH");
            Thread.Sleep(min);
            auto.MouseClick();
            Thread.Sleep(max);
            auto.Send("{F5}");
            Thread.Sleep(max);
            try
            {

                Click<HtmlSpan>(PropertyType.InnerText, "Material DG Characters");
            }
            catch (Exception e)
            {
                Click<HtmlSpan>(PropertyType.InnerText, "Material DG Characters");
            }
            Thread.Sleep(min);
            int xCoodinate = auto.MouseGetPosX();
            int yCoodinate = auto.MouseGetPosY();
            xCoodinate = xCoodinate - 320;
            auto.MouseMove(xCoodinate, yCoodinate);
            yCoodinate = yCoodinate + 40;
            auto.MouseMove(xCoodinate, yCoodinate);
            auto.MouseClick();

            Click<HtmlCustom>(PropertyType.Id, "btnUploadData");
            Thread.Sleep(mid);
            Click<HtmlFileInput>(PropertyType.Id, "ContentPlaceHolder1_uploadFile");
            Thread.Sleep(min);
            try
            {
                PathEnterText<WinEdit>(PropertyType.Name, "File name:", ExcelDataTable.ReadData(i, "filePath"));
                Thread.Sleep(mid);
            }
            catch (Exception e) { }
            Thread.Sleep(max *15);
            /**********Here Validate image uploading Valid or Not*****************/
            var data2 = window.ExecuteScript("var data=document.getElementById('lblUploadError').innerHTML;  return  data");
            string successMsg2 = data2.ToString().Trim();
            if (""!= successMsg2)
            {
                string screenShotName = "NotUploaded";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", successMsg2, successMsg2);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void findData(int i)
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);          
            auto.Send("{F5}");
            Thread.Sleep(max);
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtIDHNumber",ExcelDataTable.ReadData(i, "Material"));
            }catch(Exception e) { }
            Thread.Sleep(mid);
            Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearch");
            Thread.Sleep(max*3);
            bool b1 = Search();
            if (!b1)
            {
                string screenShotName = "WrongMaterialInformationIsuploaded" + "_" + ExcelDataTable.ReadData(i, "Plant");
                screenShot(screenShotName);
            }
            Assert.IsTrue(b1, "WrongMaterialInformationIsuploaded");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void addIDCharacter(int i)
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);          
            auto.Send("{F5}");
            Thread.Sleep(max);
            Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnNewAddCharacterType");
            Thread.Sleep(min);
            auto.MouseClick();
            Thread.Sleep(max);
            auto.Send("{F5}");
            Thread.Sleep(max);

            try
            {
                try
                {
                    EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtIDHNumber", ExcelDataTable.ReadData(i, "Material"));
                }
                catch (Exception) { }
                try
                {
                    EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtPreferedBrand", ExcelDataTable.ReadData(1, "PreferedBrand"));
                }
                catch (Exception) { }
                try
                {
                    EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtDescription", ExcelDataTable.ReadData(1, "IDHDescription"));

                }
                catch (Exception) { }
                try
                {
                    EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtTechnicalName", ExcelDataTable.ReadData(1, "TechnicalName"));
                }
                catch (Exception) { }

                try
                {
                    EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtUNCode", ExcelDataTable.ReadData(1, "UNCode"));

                }
                catch (Exception) { }
                try
                {
                    EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder_txtDGClass", ExcelDataTable.ReadData(1, "DGClass"));

                }
                catch (Exception) { }
                try
                {
                    EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtSubrisk", ExcelDataTable.ReadData(1, "Subrisk"));
                }
                catch (Exception) { }
                try
                {
                    EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtHAZ", ExcelDataTable.ReadData(1, "HAZ"));

                }
                catch (Exception) { }
                try
                {
                    EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtEPG", ExcelDataTable.ReadData(1, "EPG"));

                }
                catch (Exception) { }
                try
                {
                    EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtPG", ExcelDataTable.ReadData(1, "PG"));

                }
                catch (Exception) { }
                try
                {
                    EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtASS", ExcelDataTable.ReadData(1, "ASS"));

                }
                catch (Exception) { }
                try
                {
                    EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtASSG", ExcelDataTable.ReadData(1, "ASSG"));

                }
                catch (Exception) { }
                try
                {
                    EnterText<HtmlTextArea>(PropertyType.Id, "ContentPlaceHolder1_txtCritcalCharacteristic", ExcelDataTable.ReadData(1, "CritcalCharacteristic"));
                }
                catch (Exception) { }
            }
            catch (Exception e) { }
            Thread.Sleep(mid);
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnAdd");
            Thread.Sleep(mid);
            /******************Here Validate Mandatory  Text Box is not Empty *************************/
            string msg = "";
            try
            {
                var data = window.ExecuteScript("var data=document.getElementById('spnMessage').innerHTML; return data;");
                msg = data.ToString().Trim();
            }
            catch (Exception e) { }
            Thread.Sleep(min);
            if (msg != IDHLanguage.MsgMaterialNotExist)
            {
                string screenShotName = "Materail_IsNotExist";
                screenShot(screenShotName);
            }
            Assert.AreEqual(IDHLanguage.MsgMaterialNotExist, msg, msg);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            /**********************************Log Out******************************/
            Click<HtmlCustom>(PropertyType.Id, "userPropfile");
            Thread.Sleep(max);
            try
            {
                Click<HtmlHyperlink>(PropertyType.Id, "signOut");
            }
            catch (Exception e)
            {
                Thread.Sleep(mid);
                Click<HtmlHyperlink>(PropertyType.InnerText, "Sign Out");
            }
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public bool Search()
        {
            BrowserWindow window = new BrowserWindow();
            Thread.Sleep(600);
            var data1 = window.ExecuteScript("var data=document.getElementById('ContentPlaceHolder1_tbCharacterstic').getElementsByTagName('span')[0];  return  data.innerHTML");
            string msg1 = data1.ToString().Trim();
            bool b1 = msg1.Equals(IDHLanguage.MsgNoRecordsFound);
            return b1;
        }
        //public void SentEmail()
        //{
        //    string smtpAddress = "smtp-relay.gmail.com";
        //    int portNumber = 587;
        //    bool enableSSL = true;
        //    string emailFrom = "ab366665@gmail.com";
        //    string password = "Ajay14326";

        //    string emailTo = "ajaykumar@aureoleinc.com";
        //    string subject = "Hello";
        //    string tbody = "Hello, I'm just writing this to say Hi!";

        //    MailMessage msg = new MailMessage(emailFrom, emailTo, subject, tbody);
        //    msg.IsBodyHtml = true;
        //    SmtpClient sc = new SmtpClient("smtp.gmail.com", 587);
        //    sc.UseDefaultCredentials = false;
        //    NetworkCredential cre = new NetworkCredential(emailFrom, password);
        //    sc.Credentials = cre;
        //    sc.EnableSsl = true;
        //    sc.Send(msg);
        //}
        public void screenShot(string imgName)
        {
            BrowserWindow window = new BrowserWindow();
            string path = ConfigurationSettings.AppSettings["ScreenShot"];
            path = path + @"\\iPAS_IDHCharacterWrongMaterialUploading";
            Directory.CreateDirectory(path);
            try
            {
                window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
                Image image = window.CaptureImage();
                image.Save(path + "\\" + imgName + ".jpeg", ImageFormat.Jpeg);
                image.Dispose();
            }
            catch (Exception e) { }
            Console.WriteLine("Screen Shot is Avaliable in " + path + "\t" + "Folder");
        }
        public void WindowButtonClick<T>(PropertyType type, string propertyvalue) where T : WinControl
        {
            WinControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Name)
                genericControl.SearchProperties[WinControl.PropertyNames.Name] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void PathEnterText<T>(PropertyType type, string propertyvalue, string text) where T : WinEdit
        {
            WinEdit genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            genericControl.FilterProperties[WinEdit.PropertyNames.Name] = propertyvalue;
            AutoItX3 auto = new AutoItX3();
            auto.WinActivate("Choose File to Upload");
            auto.Send(text);
            auto.Send("{ENTER}");
            Thread.Sleep(1000);
        }
        public void Click<T>(PropertyType type, string propertyvalue) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });

            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;
            else if (type == PropertyType.InnerText)
            {
                genericControl.SearchProperties[HtmlControl.PropertyNames.InnerText] = propertyvalue;
            }
            else if (type == PropertyType.TagInstance)
                genericControl.FilterProperties[HtmlControl.PropertyNames.TagInstance] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void EnterText<T>(PropertyType type, string propertyvalue, string text) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;

            Keyboard.SendKeys(genericControl, text);

        }
        private BrowserWindow mparentwindow { get; set; }
        public enum PropertyType
        {
            Id,
            Name,
            InnerText,
            TagInstance
        }
        public BrowserWindow TopParentWindow()
        {

            BrowserWindow window = new BrowserWindow();
            window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
            return window;
        }
        public BrowserWindow ParentWindow
        {
            get
            {
                if (this.mparentwindow == null)
                {
                    this.mparentwindow = TopParentWindow();
                }
                return this.mparentwindow;
            }
        }

    }
}
