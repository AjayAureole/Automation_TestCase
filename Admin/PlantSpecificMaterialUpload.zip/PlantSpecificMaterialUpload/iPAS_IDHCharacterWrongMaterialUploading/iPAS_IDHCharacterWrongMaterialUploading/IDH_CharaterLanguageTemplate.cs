﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Text;
using System.Threading.Tasks;

namespace iPAS_IDHCharacterWrongMaterialUploading
{
    class IDH_CharaterLanguageTemplate
    {
        static CultureInfo ci = null;
        static ResourceManager rm = null;
        static string res_MsgNoRecordsFound = string.Empty;
        public string MsgNoRecordsFound
        {
            get { return res_MsgNoRecordsFound; }
            set { res_MsgNoRecordsFound = value; }
        }
        static string res_MsgMaterialNotExist = string.Empty;
        public string MsgMaterialNotExist
        {
            get { return res_MsgMaterialNotExist; }
            set { res_MsgMaterialNotExist = value; }
        }
        static string res_MsgUploading = string.Empty;
        public string MsgUploading
        {
            get { return res_MsgUploading; }
            set { res_MsgUploading = value; }
        }

        public static void messageResource(string languageCode)
        {
           
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_IDHCharacterWrongMaterialUploading.resource.IDH_CharaterEN", Assembly.GetExecutingAssembly());
                messageInitialize();
           
        }
        public static void messageInitialize()
        {
            res_MsgNoRecordsFound = rm.GetString("res_MsgNoRecordsFound", ci).Trim(); 
            res_MsgMaterialNotExist = rm.GetString("res_MsgMaterialNotExist", ci).Trim();
            res_MsgUploading = rm.GetString("res_MsgUploading", ci).Trim();


        }
    }
}
