﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Text;
using System.Threading.Tasks;

namespace iPAS_CustomerSpecificWrongMaterialUpload
{
    class CustomerSpecificProductLanguageTemplate
    {
        static CultureInfo ci = null;
        static ResourceManager rm = null;
        static string resMsg_InvalidBulkIDH = string.Empty;
        public string Msg_InvalidBulkIDH
        {
            get { return resMsg_InvalidBulkIDH; }
            set { resMsg_InvalidBulkIDH = value; }
        }
        static string resMsg_InvalidRMIDH = string.Empty;
        public string Msg_InvalidRMIDH
        {
            get { return resMsg_InvalidRMIDH; }
            set { resMsg_InvalidRMIDH = value; }
        }

        public static void messageResource(string languageCode)
        {

            ci = new CultureInfo(languageCode);
            rm = new ResourceManager("iPAS_CustomerSpecificWrongMaterialUpload.resource.CustomerSpecificProductEN", Assembly.GetExecutingAssembly());
            messageInitialize();
        }
        public static void messageInitialize()
        {
            resMsg_InvalidBulkIDH = rm.GetString("resMsg_InvalidBulkIDH", ci).Trim();
            resMsg_InvalidRMIDH = rm.GetString("resMsg_InvalidRMIDH", ci).Trim();

        }
    }
}
