﻿using AutoItX3Lib;
using DataDrivenTesting;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Configuration;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Threading;

namespace iPASManageInwardGoodsNoteWrongUpload
{
    class ManageInwardGoodsNote
    {
        string minsleep = ConfigurationSettings.AppSettings["min"];
        string midsleep = ConfigurationSettings.AppSettings["mid"];
        string maxsleep = ConfigurationSettings.AppSettings["max"];
        ManageInwardGoodsNoteLanguageTemplate goodsNote = new ManageInwardGoodsNoteLanguageTemplate();
        public void uploadingExcel(int i)
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(min);
            Click<HtmlHyperlink>(PropertyType.Id, "lnkAdmin");
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(max);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkGRIndex");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkGRNotes");
            Thread.Sleep(min);
            auto.MouseClick();
            Thread.Sleep(max);
            auto.Send("{F5}");
            Thread.Sleep(max);

            try
            {

                Click<HtmlSpan>(PropertyType.InnerText, "Receiving Notes");
            }
            catch (Exception e)
            {
                Click<HtmlSpan>(PropertyType.InnerText, "Receiving Notes");
            }
            Thread.Sleep(min);
            int xCoodinate = auto.MouseGetPosX();
            int yCoodinate = auto.MouseGetPosY();
            xCoodinate = xCoodinate - 280;
            auto.MouseMove(xCoodinate, yCoodinate);
            yCoodinate = yCoodinate + 40;
            auto.MouseMove(xCoodinate, yCoodinate);
            auto.MouseClick();


            Click<HtmlCustom>(PropertyType.Id, "ContentPlaceHolder1_btnUploadData");
            Thread.Sleep(mid);
            Click<HtmlFileInput>(PropertyType.Id, "ContentPlaceHolder1_uploadFile");
            Thread.Sleep(min);
            try
            {
                PathEnterText<WinEdit>(PropertyType.Name, "File name:", ExcelDataTable.ReadData(i, "filePath"));
                Thread.Sleep(mid);
            }
            catch (Exception e) { }
            Thread.Sleep(max * 10);

            /**********Here Validate uploading file Valid or Not*****************/
            var data2 = window.ExecuteScript("var data=document.getElementById('lblUploadError').innerHTML;  return  data");
            string successMsg2 = data2.ToString().Trim();
            if ("" != successMsg2)
            {
                string screenShotName = "NotUploaded";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", successMsg2, successMsg2);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void findData(int i)
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);
            //Click<HtmlRadioButton>(PropertyType.Id, "rdoIDHID");
            //Thread.Sleep(mid);
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtMaterialSearch", ExcelDataTable.ReadData(i, "Material"));
            }catch(Exception e) { }            
            Thread.Sleep(mid);
            Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearch");
            Thread.Sleep(max * 3);
            bool b1 = Search();
            if (!b1)
            {
                string screenShotName = "WrongMaterialInformationIsuploaded" + "_" + ExcelDataTable.ReadData(i, "Plant");
                screenShot(screenShotName);
            }
            Assert.IsTrue(b1, "Wrong Material Information is uploaded");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);
            /**********************************Log Out******************************/
            Click<HtmlCustom>(PropertyType.Id, "userPropfile");
            Thread.Sleep(max);
            try
            {
                Click<HtmlHyperlink>(PropertyType.Id, "signOut");
            }
            catch (Exception e)
            {
                Thread.Sleep(mid);
                Click<HtmlHyperlink>(PropertyType.InnerText, "Sign Out");
            }
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public bool Search()
        {
            BrowserWindow window = new BrowserWindow();
            Thread.Sleep(600);
            var data1 = window.ExecuteScript("var data=document.getElementById('ContentPlaceHolder1_tblGRNotesBody').getElementsByTagName('span')[0];  return  data.innerHTML");
            string msg1 = data1.ToString().Trim();
            bool b1 = msg1.Equals(goodsNote.MsgNoRecordsFound);
            return b1;
        }
        //public void SentEmail()
        //{
        //    string smtpAddress = "smtp-relay.gmail.com";
        //    int portNumber = 587;
        //    bool enableSSL = true;
        //    string emailFrom = "ab366665@gmail.com";
        //    string password = "Ajay14326";

        //    string emailTo = "ajaykumar@aureoleinc.com";
        //    string subject = "Hello";
        //    string tbody = "Hello, I'm just writing this to say Hi!";

        //    MailMessage msg = new MailMessage(emailFrom, emailTo, subject, tbody);
        //    msg.IsBodyHtml = true;
        //    SmtpClient sc = new SmtpClient("smtp.gmail.com", 587);
        //    sc.UseDefaultCredentials = false;
        //    NetworkCredential cre = new NetworkCredential(emailFrom, password);
        //    sc.Credentials = cre;
        //    sc.EnableSsl = true;
        //    sc.Send(msg);
        //}
        public void screenShot(string imgName)
        {
            BrowserWindow window = new BrowserWindow();
            string path = ConfigurationSettings.AppSettings["ScreenShot"];
            path = path + @"\\iPASManageInwardGoodsNoteWrongUpload";
            Directory.CreateDirectory(path);
            try
            {
                window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
                Image image = window.CaptureImage();
                image.Save(path + "\\" + imgName + ".jpeg", ImageFormat.Jpeg);
                image.Dispose();
            }
            catch (Exception e) { }
            Console.WriteLine("Screen Shot is Avaliable in " + path + "\t" + "Folder");
        }
        public void WindowButtonClick<T>(PropertyType type, string propertyvalue) where T : WinControl
        {
            WinControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Name)
                genericControl.SearchProperties[WinControl.PropertyNames.Name] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void PathEnterText<T>(PropertyType type, string propertyvalue, string text) where T : WinEdit
        {
            WinEdit genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            genericControl.FilterProperties[WinEdit.PropertyNames.Name] = propertyvalue;
            AutoItX3 auto = new AutoItX3();
            auto.WinActivate("Choose File to Upload");
            auto.Send(text);
            auto.Send("{ENTER}");
            Thread.Sleep(1000);
        }
        public void Click<T>(PropertyType type, string propertyvalue) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });

            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;
            else if (type == PropertyType.InnerText)
            {
                genericControl.SearchProperties[HtmlControl.PropertyNames.InnerText] = propertyvalue;
            }
            else if (type == PropertyType.TagInstance)
                genericControl.FilterProperties[HtmlControl.PropertyNames.TagInstance] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void EnterText<T>(PropertyType type, string propertyvalue, string text) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;

            Keyboard.SendKeys(genericControl, text);

        }
        private BrowserWindow mparentwindow { get; set; }
        public enum PropertyType
        {
            Id,
            Name,
            InnerText,
            TagInstance
        }
        public BrowserWindow TopParentWindow()
        {

            BrowserWindow window = new BrowserWindow();
            window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
            return window;
        }
        public BrowserWindow ParentWindow
        {
            get
            {
                if (this.mparentwindow == null)
                {
                    this.mparentwindow = TopParentWindow();
                }
                return this.mparentwindow;
            }
        }
    }
}
