﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Text;
using System.Threading.Tasks;

namespace iPAS_LabelDBWrongMaterialUpload
{
    class ManageDynamicLabelDBLanguageTemplate
    {
        static CultureInfo ci = null;
        static ResourceManager rm = null;
        static string resMsg_NoRecordFound = string.Empty;
        public string Msg_NoRecordFound
        {
            get { return resMsg_NoRecordFound; }
            set { resMsg_NoRecordFound = value; }
        }
        static string resMsg_MaterialNotExist = string.Empty;
        public string Msg_MaterialNotExist
        {
            get { return resMsg_MaterialNotExist; }
            set { resMsg_MaterialNotExist = value; }
        }

        public static void messageResource(string languageCode)
        {

            ci = new CultureInfo(languageCode);
            rm = new ResourceManager("iPAS_LabelDBWrongMaterialUpload.resource.ManageDynamicLabelDBEN", Assembly.GetExecutingAssembly());
            messageInitialize();
        }
        public static void messageInitialize()
        {
            resMsg_NoRecordFound = rm.GetString("resMsg_NoRecordFound", ci).Trim();
            resMsg_MaterialNotExist = rm.GetString("resMsg_MaterialNotExist", ci).Trim();

        }

    }
}
