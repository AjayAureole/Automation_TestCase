﻿using AutoItX3Lib;
using DataDrivenTesting;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace iPAS_LabelDBWrongMaterialUpload
{
    class ManageDynamicLabelDatabase
    {
        string minsleep = ConfigurationSettings.AppSettings["min"];
        string midsleep = ConfigurationSettings.AppSettings["mid"];
        string maxsleep = ConfigurationSettings.AppSettings["max"];
        ManageDynamicLabelDBLanguageTemplate DBLan = new ManageDynamicLabelDBLanguageTemplate();
        public void uploadingExcel(int i)
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "lnkAdmin");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnklabelDb");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlDiv>(PropertyType.Id, "footer");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkMangeLabelDB");
            Thread.Sleep(min);
            auto.MouseClick();
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            try
            {

                Click<HtmlSpan>(PropertyType.InnerText, "Manage Dynamic Label Database");
            }
            catch (Exception e)
            {
                Click<HtmlSpan>(PropertyType.InnerText, "Manage Dynamic Label Database");
            }
            Thread.Sleep(min);
            int xCoodinate = auto.MouseGetPosX();
            int yCoodinate = auto.MouseGetPosY();
            xCoodinate = xCoodinate - 320;
            auto.MouseMove(xCoodinate, yCoodinate);
            yCoodinate = yCoodinate + 40;
            auto.MouseMove(xCoodinate, yCoodinate);
            auto.MouseClick();


            Click<HtmlCustom>(PropertyType.Id, "btnUploadData");
            Click<HtmlFileInput>(PropertyType.Id, "ContentPlaceHolder1_uploadFile");
            PathEnterText<WinEdit>(PropertyType.Name, "File name:", ExcelDataTable.ReadData(i, "filePath"));
            Thread.Sleep(max * 10);
            var data1 = window.ExecuteScript("var data=document.getElementById('lblUploadError').innerHTML;  return  data");
            string successMsg1 = data1.ToString().Trim();
            if (successMsg1 != "")
            {
                string screenShotName = "FileIs_NotUploading";
                screenShot(screenShotName);
            }

            Assert.AreEqual("", successMsg1, successMsg1);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void findData(int i)
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            auto.Send("{F5}");
            Thread.Sleep(max);
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtMaterialNumber", ExcelDataTable.ReadData(i, "Material"));
            }
            catch (Exception e) { }
            Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearch");
            Thread.Sleep(mid);
            ////************Here validate on the Search TextBoX Data is Enter or Not**************///
            var data1 = window.ExecuteScript("var data=document.getElementById('spnSearchError').innerHTML;  return  data");
            string successMsg1 = data1.ToString().Trim();
            if (successMsg1 != "")
            {
                string screenShotName = "PleaseEnterSearch_Criteria";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", successMsg1, successMsg1);
            Thread.Sleep(mid);
            bool b1 = SearchNoData();
            if (!b1)
            {
                string screenShotName = "WrongMaterialInformationIsuploaded" + "_" + ExcelDataTable.ReadData(i, "Plant");
                screenShot(screenShotName);

            }
            Assert.IsTrue(b1, "Wrong Material Information Is uploaded");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void addingMaterial(int i)
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_btnAddNewLabelDb");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtMaterialNumber", ExcelDataTable.ReadData(i, "Material"));
            }catch(Exception e) { }
            auto.Send("{TAB}");
            Thread.Sleep(mid);
            var data1 = window.ExecuteScript("var data=document.getElementById('spnMaterialMessage').innerHTML;  return  data");
            string successMsg1 = data1.ToString().Trim();
            if (successMsg1 != DBLan.Msg_MaterialNotExist)
            {
                string screenShotName = "FileIs_NotUploading";
                screenShot(screenShotName);
            }

            Assert.AreEqual(DBLan.Msg_MaterialNotExist, successMsg1, successMsg1);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);

            /**********************************Log Out******************************/
            Click<HtmlCustom>(PropertyType.Id, "userPropfile");
            Thread.Sleep(max);
            try
            {
                Click<HtmlHyperlink>(PropertyType.Id, "signOut");
            }
            catch (Exception e)
            {
                Thread.Sleep(mid);
                Click<HtmlHyperlink>(PropertyType.InnerText, "Sign Out");
            }
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void screenShot(string imgName)
        {
            BrowserWindow window = new BrowserWindow();
            string path = ConfigurationSettings.AppSettings["ScreenShot"];
            path = path + @"\\iPAS_LabelDBWrongMaterialUpload";
            Directory.CreateDirectory(path);

            try
            {
                window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
                Image image = window.CaptureImage();
                image.Save(path + "\\" + imgName + ".jpeg", ImageFormat.Jpeg);
                image.Dispose();
            }
            catch (Exception e) { }
            Console.WriteLine("Screen Shot is Avaliable in " + path + "\t" + "Folder");
        }
        public bool SearchNoData()
        {
            BrowserWindow window = new BrowserWindow();
            Thread.Sleep(500);
            var data = window.ExecuteScript("var data=document.getElementById('ContentPlaceHolder1_tbLabelDataBase').getElementsByTagName('span')[0];  return  data.innerHTML");
            string successMsg = data.ToString().Trim();
            bool b1 = successMsg.Equals(DBLan.Msg_NoRecordFound);
            return b1;
        }

        public void PathEnterText<T>(PropertyType type, string propertyvalue, string text) where T : WinEdit
        {
            WinEdit genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            genericControl.FilterProperties[WinEdit.PropertyNames.Name] = propertyvalue;
            AutoItX3 auto = new AutoItX3();
            auto.WinActivate("Choose File to Upload");
            auto.Send(text);
            auto.Send("{ENTER}");
            Thread.Sleep(1000);
        }
        public void WindowButtonClick<T>(PropertyType type, string propertyvalue) where T : WinControl
        {
            WinControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Name)
                genericControl.SearchProperties[WinControl.PropertyNames.Name] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void Click<T>(PropertyType type, string propertyvalue) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });

            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;
            else if (type == PropertyType.InnerText)
            {
                genericControl.SearchProperties[HtmlControl.PropertyNames.InnerText] = propertyvalue;
            }
            else if (type == PropertyType.TagInstance)
                genericControl.FilterProperties[HtmlControl.PropertyNames.TagInstance] = propertyvalue;
            else if (type == PropertyType.Class)
            {
                genericControl.FilterProperties[HtmlControl.PropertyNames.Class] = propertyvalue;
            }

            Mouse.Click(genericControl);
        }
        public void EnterText<T>(PropertyType type, string propertyvalue, string text) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;
            else if (type == PropertyType.Class)
                genericControl.FilterProperties[HtmlControl.PropertyNames.Class] = propertyvalue;



            Keyboard.SendKeys(genericControl, text);

        }
        private BrowserWindow mparentwindow { get; set; }
        public enum PropertyType
        {
            Id,
            Name,
            InnerText,
            TagInstance,
            Class
        }
        public BrowserWindow TopParentWindow()
        {

            BrowserWindow window = new BrowserWindow();
            window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
            return window;
        }
        public BrowserWindow ParentWindow
        {
            get
            {
                if (this.mparentwindow == null)
                {
                    this.mparentwindow = TopParentWindow();
                }
                return this.mparentwindow;
            }
        }

    }
}
