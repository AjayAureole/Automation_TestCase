﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Text;
using System.Threading.Tasks;

namespace iPAS_MaterialInfoWrongUpload
{
    class PlantMaterialInfoLanguageTemplate
    {
        static CultureInfo ci = null;
        static ResourceManager rm = null; 
        static string res_MsgNoRecordFound = string.Empty;
        public string MsgNoRecordFound
        {
            get { return res_MsgNoRecordFound; }
            set { res_MsgNoRecordFound = value; }
        }
        static string res_MsgUploadZip = string.Empty;
        public string MsgUploadZip
        {
            get { return res_MsgUploadZip; }
            set { res_MsgUploadZip = value; }
        }
        public static void messageResource(string languageCode)
        {

            ci = new CultureInfo(languageCode);
            rm = new ResourceManager("iPAS_MSDSWrongMaterialInfoUpload.resource.PlantMaterialInfoEN", Assembly.GetExecutingAssembly());
            messageInitialize();

        }
        public static void messageInitialize()
        {
            res_MsgNoRecordFound = rm.GetString("res_MsgNoRecordFound", ci).Trim();
            res_MsgUploadZip = rm.GetString("res_MsgUploadZip", ci).Trim();

    }
}
}
