﻿using AutoItX3Lib;
using DataDrivenTesting;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace iPAS_ManageToleranceIDHWrongUpload
{
    class ManageIDHTolerance
    {
        string minsleep = ConfigurationSettings.AppSettings["min"];
        string midsleep = ConfigurationSettings.AppSettings["mid"];
        string maxsleep = ConfigurationSettings.AppSettings["max"];
        ManageToleranceIDHLanguageTemplate lanToleranceIDH = new ManageToleranceIDHLanguageTemplate();
        public void addManageIDHTolearance(int i)
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "lnkAdmin");
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(max);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkConfigPLine");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkStagingRule");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkToleranceIDH");
            Thread.Sleep(min);
            auto.MouseClick();
            Thread.Sleep(max);
            auto.Send("{F5}");
            Thread.Sleep(max);
            //var totalbefore = window.ExecuteScript("var data=document.getElementById('spnTotalRecords').innerHTML;  return  data");
            //string tot = totalbefore.ToString().Trim();
            //int totalbeforerecord = Convert.ToInt32(totalbefore);
            //Thread.Sleep(max);

            //try
            //{

            //    Click<HtmlSpan>(PropertyType.InnerText, "Manage Material Tolerance");
            //}
            //catch (Exception e)
            //{
            //    Click<HtmlSpan>(PropertyType.InnerText, "Manage Material Tolerance");
            //}
            //Thread.Sleep(min);
            //int xCoodinate = auto.MouseGetPosX();
            //int yCoodinate = auto.MouseGetPosY();
            //xCoodinate = xCoodinate - 360;
            //auto.MouseMove(xCoodinate, yCoodinate);
            //yCoodinate = yCoodinate + 150;
            //auto.MouseMove(xCoodinate, yCoodinate);
            //auto.MouseClick();

            //Click<HtmlCustom>(PropertyType.Id, "btnUploadNoToleranceIDHList");
            //Thread.Sleep(mid);
            //Click<HtmlFileInput>(PropertyType.Id, "ContentPlaceHolder1_btnUploadIDH");
            //Thread.Sleep(mid);

            //try
            //{
            //    PathEnterText<WinEdit>(PropertyType.Name, "File name:", ExcelDataTable.ReadData(i, "filePath"));
            //    Thread.Sleep(mid);
            //}
            //catch (Exception e) { }
            //Thread.Sleep(max * 10);

            /**********Here Validate  uploading Valid or Not*****************/

            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtAddNoToleranceIDH", ExcelDataTable.ReadData(i, "Material"));
            }catch(Exception e) { }
            Thread.Sleep(min);
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnAddNoToleranceIDH");
            Thread.Sleep(max*2);

            var data2 = window.ExecuteScript("var data=document.getElementById('spnNoToleranceError').innerHTML;  return  data");
            string successMsg2 = data2.ToString().Trim();
            if (lanToleranceIDH.Msg_enterMaterial != successMsg2)
            {
                string screenShotName = "WrongMaterialInformationIsadd" + "_" + ExcelDataTable.ReadData(i, "Plant"); ;
                screenShot(screenShotName);
            }
            Assert.AreEqual(lanToleranceIDH.Msg_enterMaterial, successMsg2, successMsg2);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);           
        }      
        public void logOut(int i)
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);
            //try
            //{
            //    EnterText<HtmlEdit>(PropertyType.Id, "txtMaterialNumber", ExcelDataTable.ReadData(i, "Material"));
            //}
            //catch (Exception e) { }
            //Thread.Sleep(mid);
            //Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearch");
            //Thread.Sleep(max * 3);
            //bool b1 = Search();
            //if (!b1)
            //{
            //    string screenShotName = "UploadedData_IsFound";
            //    screenShot(screenShotName);
            //}
            //Assert.IsTrue(b1, "Material Information is there");
            //Thread.Sleep(mid);
            //auto.Send("{F5}");
            //Thread.Sleep(mid);

            /**********************************Log Out******************************/
            Click<HtmlCustom>(PropertyType.Id, "userPropfile");
            Thread.Sleep(max);
            try
            {
                Click<HtmlHyperlink>(PropertyType.Id, "signOut");
            }
            catch (Exception e)
            {
                Thread.Sleep(mid);
                Click<HtmlHyperlink>(PropertyType.InnerText, "Sign Out");
            }
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }









        public void addManageMaterialGHSInfo(int i)
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_btnAddNewLabelDb");
            Thread.Sleep(max);
            auto.Send("{F5}");
            Thread.Sleep(max);
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtMaterialNumber", ExcelDataTable.ReadData(i, "Material"));
            }
            catch (Exception e) { }
            Thread.Sleep(max);
            auto.Send("{TAB}");
            auto.Send("{TAB}");
            Thread.Sleep(max);
            var data2 = window.ExecuteScript("var data=document.getElementById('lblUploadError').innerHTML;  return  data");
            string successMsg2 = data2.ToString().Trim();
            if ("" != successMsg2)
            {
                string screenShotName = "NotUploaded";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", successMsg2, successMsg2);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(max);
            /**********************************Log Out******************************/
            Click<HtmlHyperlink>(PropertyType.InnerText, ExcelDataTable.ReadData(i, "userName"));
            Thread.Sleep(mid);
            try
            {
                Click<HtmlHyperlink>(PropertyType.Id, "menuitem");
            }
            catch (Exception e)
            {
                Thread.Sleep(mid);
                Click<HtmlHyperlink>(PropertyType.InnerText, " Sign Out");
            }
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public bool Search()
        {
            BrowserWindow window = new BrowserWindow();
            Thread.Sleep(600);
            var data1 = window.ExecuteScript("var data=document.getElementById('ContentPlaceHolder1_tbLabelDataBase').getElementsByTagName('span')[0];  return  data.innerHTML");
            string msg1 = data1.ToString().Trim();
            bool b1 = msg1.Equals("");
            return b1;
        }
        //public void SentEmail()
        //{
        //    string smtpAddress = "smtp-relay.gmail.com";
        //    int portNumber = 587;
        //    bool enableSSL = true;
        //    string emailFrom = "ab366665@gmail.com";
        //    string password = "Ajay14326";

        //    string emailTo = "ajaykumar@aureoleinc.com";
        //    string subject = "Hello";
        //    string tbody = "Hello, I'm just writing this to say Hi!";

        //    MailMessage msg = new MailMessage(emailFrom, emailTo, subject, tbody);
        //    msg.IsBodyHtml = true;
        //    SmtpClient sc = new SmtpClient("smtp.gmail.com", 587);
        //    sc.UseDefaultCredentials = false;
        //    NetworkCredential cre = new NetworkCredential(emailFrom, password);
        //    sc.Credentials = cre;
        //    sc.EnableSsl = true;
        //    sc.Send(msg);
        //}
        public void screenShot(string imgName)
        {
            BrowserWindow window = new BrowserWindow();
            string path = ConfigurationSettings.AppSettings["ScreenShot"];
            path = path + @"\\iPAS_ManageToleranceIDHWrongUpload";
            Directory.CreateDirectory(path);
            try
            {
                window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
                Image image = window.CaptureImage();
                image.Save(path + "\\" + imgName + ".jpeg", ImageFormat.Jpeg);
                image.Dispose();
            }
            catch (Exception e) { }
            Console.WriteLine("Screen Shot is Avaliable in " + path + "\t" + "Folder");
        }
        public void WindowButtonClick<T>(PropertyType type, string propertyvalue) where T : WinControl
        {
            WinControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Name)
                genericControl.SearchProperties[WinControl.PropertyNames.Name] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void PathEnterText<T>(PropertyType type, string propertyvalue, string text) where T : WinEdit
        {
            WinEdit genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            genericControl.FilterProperties[WinEdit.PropertyNames.Name] = propertyvalue;
            AutoItX3 auto = new AutoItX3();
            auto.WinActivate("Choose File to Upload");
            auto.Send(text);
            auto.Send("{ENTER}");
            Thread.Sleep(1000);
        }
        public void Click<T>(PropertyType type, string propertyvalue) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });

            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;
            else if (type == PropertyType.InnerText)
            {
                genericControl.SearchProperties[HtmlControl.PropertyNames.InnerText] = propertyvalue;
            }
            else if (type == PropertyType.TagInstance)
                genericControl.FilterProperties[HtmlControl.PropertyNames.TagInstance] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void EnterText<T>(PropertyType type, string propertyvalue, string text) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;

            Keyboard.SendKeys(genericControl, text);

        }
        private BrowserWindow mparentwindow { get; set; }
        public enum PropertyType
        {
            Id,
            Name,
            InnerText,
            TagInstance
        }
        public BrowserWindow TopParentWindow()
        {

            BrowserWindow window = new BrowserWindow();
            window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
            return window;
        }
        public BrowserWindow ParentWindow
        {
            get
            {
                if (this.mparentwindow == null)
                {
                    this.mparentwindow = TopParentWindow();
                }
                return this.mparentwindow;
            }
        }
    }
}
