﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Text;
using System.Threading.Tasks;

namespace iPAS_ManageToleranceIDHWrongUpload
{
    class ManageToleranceIDHLanguageTemplate
    {
        static CultureInfo ci = null;
        static ResourceManager rm = null;
        static string resMsg_enterMaterial = string.Empty;
        public string Msg_enterMaterial
        {
            get { return resMsg_enterMaterial; }
            set { resMsg_enterMaterial = value; }
        }

        public static void messageResource(string languageCode)
        {

            ci = new CultureInfo(languageCode);
            rm = new ResourceManager("iPAS_ManageToleranceIDHWrongUpload.resource.ManageToleranceIDHEN", Assembly.GetExecutingAssembly());
            messageInitialize();
        }
        public static void messageInitialize()
        {
            resMsg_enterMaterial = rm.GetString("resMsg_enterMaterial", ci).Trim();
        }
    }
}
