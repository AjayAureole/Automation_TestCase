﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Text;
using System.Threading.Tasks;

namespace iPAS_PlantPrinters
{
    class PlantPrinterLanguageResource
    {
        static CultureInfo ci = null;
        static ResourceManager rm = null;
        static string resMsg_AddPrinterSuccess = string.Empty;
        public string Msg_AddPrinterSuccess
        {
            get { return resMsg_AddPrinterSuccess; }
            set { resMsg_AddPrinterSuccess = value; }
        }

        static string resMsg_PrinterUpdateSuccess = string.Empty;
        public string Msg_PrinterUpdateSuccess
        {
            get { return resMsg_PrinterUpdateSuccess; }
            set { resMsg_PrinterUpdateSuccess = value; }
        }
        public static void messageResource(string languageCode)
        {
            if (languageCode == "zh-CN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_PlantPrinters.resources.PlantPrinterResourceCN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "th-TH")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_PlantPrinters.resources.PlantPrinterResourceTH", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_PlantPrinters.resources.PlantPrinterResourceEN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
        }
        public static void messageInitialize()
        {
            resMsg_AddPrinterSuccess = rm.GetString("resMsg_AddPrinterSuccess", ci).Trim();
            resMsg_PrinterUpdateSuccess = rm.GetString("resMsg_PrinterUpdateSuccess", ci).Trim();
        }
    }
}
