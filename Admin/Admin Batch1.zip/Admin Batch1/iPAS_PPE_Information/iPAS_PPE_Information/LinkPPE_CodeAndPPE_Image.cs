﻿using AutoItX3Lib;
using DataDrivenTesting;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace iPAS_PPE_Information
{
    class LinkPPE_CodeAndPPE_Image
    {
        string minsleep = ConfigurationSettings.AppSettings["min"];
        string midsleep = ConfigurationSettings.AppSettings["mid"];
        string maxsleep = ConfigurationSettings.AppSettings["max"];
        PPELanguageResource languageResource = new PPELanguageResource();
        public void LinkCodeAndPPE_Image()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);
            Click<HtmlHyperlink>(PropertyType.Id, "lnkLinkPPECode");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            string PPECode = ExcelDataTable.ReadData(1, "ppeCode").Trim();
            string materialType = ExcelDataTable.ReadData(1, "Material Type");
            PPECode = PPECode + "-" + materialType;
            Thread.Sleep(min);
            EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpPPECode", PPECode);
            Thread.Sleep(min);
            Click<HtmlDiv>(PropertyType.Id,"footer");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(mid);
            Click<HtmlSpan>(PropertyType.InnerText,ExcelDataTable.ReadData(1, "Description"));
            /*************here click on the check Box for both(code and Image)********************/

            int Mx1 = auto.MouseGetPosX();
            int My1 = auto.MouseGetPosY();
            Mx1 = Mx1 + 330;
            My1 = My1 - 3;
            Thread.Sleep(mid);
            auto.MouseMove(Mx1, My1);
            Thread.Sleep(min);
            auto.MouseClick();
            Thread.Sleep(min);
            Mx1 = Mx1 + 165;
            Thread.Sleep(min);
            auto.MouseMove(Mx1, My1);
            Thread.Sleep(min);
            auto.MouseClick();
            Thread.Sleep(min);
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnAdd");
            Thread.Sleep(mid);
            /****************Here Validate PPE COde or PPE Image linking is Updated successfully or not******************/
            var data = window.ExecuteScript("var data=document.getElementById('spnAddError').innerHTML; return data;");
            string msg = data.ToString().Trim();
            if (languageResource.Msg_SuccessfullyUpdatedPPE!=msg)
            {
                string screenShotName = "Updated_Notuccessfully";
                screenShot(screenShotName);
            }
            Assert.AreEqual(languageResource.Msg_SuccessfullyUpdatedPPE, msg, msg);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void deleteAllLink()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
           
            Click<HtmlHyperlink>(PropertyType.Id, "lnkLinkPPECode");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlSpan>(PropertyType.InnerText, ExcelDataTable.ReadData(1, "ppeCode"));
            Thread.Sleep(min);
            int Mx1 = auto.MouseGetPosX();
            int My1 = auto.MouseGetPosY();
            Mx1 = Mx1 - 55;
            My1 = My1 - 3;
            Thread.Sleep(mid);
            auto.MouseMove(Mx1, My1);
            Thread.Sleep(min);
            auto.MouseClick();
            Thread.Sleep(min);
            auto.Send("{ENTER}");
            Thread.Sleep(mid);
            /******************Delete PPE Information ************/
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "lnkPPEimage");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlDiv>(PropertyType.Id, "footer");
            try
            {
                var pageCount = window.ExecuteScript("var data=document.getElementById('pagerControl_divPager').getElementsByTagName('a');  return  data.length");
                string len = pageCount.ToString();
                int length = Convert.ToInt32(len);
                for (int i = 1; i <= length; i++)
                {
                    Thread.Sleep(mid);
                    auto.Send("{F5}");
                    Thread.Sleep(mid);
                    string tagId = "pagerControl_hrefNum" + i;
                    Thread.Sleep(min);
                    Click<HtmlHyperlink>(PropertyType.Id, tagId);
                    try
                    {
                        Click<HtmlSpan>(PropertyType.InnerText, ExcelDataTable.ReadData(1, "Description"));
                        int Mx2 = auto.MouseGetPosX();
                        int My2 = auto.MouseGetPosY();
                        Mx2 = Mx2 - 430;
                        My2 = My2 - 3;
                        Thread.Sleep(min);
                        auto.MouseMove(Mx2, My2);
                        auto.MouseClick();
                        Thread.Sleep(min);
                        auto.Send("{ENTER}");
                        Thread.Sleep(min);
                    }
                    catch (Exception e) { }
                    tagId = "";
                }
            }
            catch (Exception e) { }
            Thread.Sleep(min);
            auto.Send("{F5}");
            /********************Here Manage PPE Code Deletion***********/
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "lnkManagePPECode");
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlDiv>(PropertyType.Id, "footer");
            try
            {
                var pageCount = window.ExecuteScript("var data=document.getElementById('pagerControl_divPager').getElementsByTagName('a');  return  data.length");
                string len = pageCount.ToString();
                int length = Convert.ToInt32(len);
                string ss= ExcelDataTable.ReadData(1, "addPPE Code");
                for (int i = 1; i <= length; i++)
                {
                    auto.Send("{F5}");
                    Thread.Sleep(min);
                    string tagId = "pagerControl_hrefNum" + i;
                    Thread.Sleep(min);
                    Click<HtmlHyperlink>(PropertyType.Id, tagId);
                    try
                    {
                        Click<HtmlSpan>(PropertyType.InnerText, "Z123");
                        Thread.Sleep(min);
                        int Mx3 = auto.MouseGetPosX();
                        int My3 = auto.MouseGetPosY();
                        Mx3 = Mx3 - 55;
                        My3 = My3 - 3;
                        Thread.Sleep(mid);
                        auto.MouseMove(Mx3, My3);
                        auto.MouseClick();
                        Thread.Sleep(min);
                        mparentwindow = null;
                        Click<HtmlButton>(PropertyType.InnerText,languageResource.Msg_Confirm);
                        auto.Send("{ENTER}");
                        Thread.Sleep(min);
                        auto.Send("{F5}");
                        Thread.Sleep(mid);
                    }
                    catch (Exception e) { }
                    tagId = "";                   
                }
            }
            catch (Exception e) { }
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(min);
        }
        public void screenShot(string imgName)
        {
            BrowserWindow window = new BrowserWindow();
            string path = ConfigurationSettings.AppSettings["ScreenShot"];
            path = path + @"\\iPAS_PPE_Information";
            Directory.CreateDirectory(path);
            try
            {
                window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
                Image image = window.CaptureImage();
                image.Save(path + "\\" + imgName + ".jpeg", ImageFormat.Jpeg);
                image.Dispose();
            }
            catch (Exception e) { }
            Console.WriteLine("Screen Shot is Avaliable in " + path + "\t" + "Folder");
        }
        public void WindowButtonClick<T>(PropertyType type, string propertyvalue) where T : WinControl
        {
            WinControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Name)
                genericControl.SearchProperties[WinControl.PropertyNames.Name] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void PathEnterText<T>(PropertyType type, string propertyvalue, string text) where T : WinEdit
        {
            WinEdit genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            genericControl.FilterProperties[WinEdit.PropertyNames.Name] = propertyvalue;
            AutoItX3 auto = new AutoItX3();
            auto.WinActivate("Choose File to Upload");
            auto.Send(text);
            auto.Send("{ENTER}");
            Thread.Sleep(1000);
        }
        public void Click<T>(PropertyType type, string propertyvalue) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });

            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;
            else if (type == PropertyType.InnerText)
            {
                genericControl.SearchProperties[HtmlControl.PropertyNames.InnerText] = propertyvalue;
            }
            else if (type == PropertyType.TagInstance)
                genericControl.FilterProperties[HtmlControl.PropertyNames.TagInstance] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void EnterText<T>(PropertyType type, string propertyvalue, string text) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;

            Keyboard.SendKeys(genericControl, text);

        }
        private BrowserWindow mparentwindow { get; set; }
        public enum PropertyType
        {
            Id,
            Name,
            InnerText,
            TagInstance
        }
        public BrowserWindow TopParentWindow()
        {

            BrowserWindow window = new BrowserWindow();
            window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
            return window;
        }
        public BrowserWindow ParentWindow
        {
            get
            {
                if (this.mparentwindow == null)
                {
                    this.mparentwindow = TopParentWindow();
                }
                return this.mparentwindow;
            }
        }

    }
}
