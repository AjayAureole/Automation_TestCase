﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Text;
using System.Threading.Tasks;

namespace iPAS_PPE_Information
{
    class AddPPECodeLanguageResource
    {
        static CultureInfo ci = null;
        static ResourceManager rm = null;
        static string resMsg_Confirm = string.Empty;
        public string Msg_Confirm
        {
            get { return resMsg_Confirm; }
            set { resMsg_Confirm = value; }
        }

        static string resMsg_PPECodeAddedSuccessfully = string.Empty;
        public string Msg_PPECodeAddedSuccessfully
        {
            get { return resMsg_PPECodeAddedSuccessfully; }
            set { resMsg_PPECodeAddedSuccessfully = value; }
        }
        public static void messageResource(string languageCode)
        {
            if (languageCode == "zh-CN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_PPE_Information.resources.AddPPECodeResourceCN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "th-TH")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_PPE_Information.resources.AddPPECodeResourceTH", Assembly.GetExecutingAssembly());
                messageInitialize();
            }           
            else
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_PPE_Information.resources.AddPPECodeResourceEN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
        }
        public static void messageInitialize()
        {
            resMsg_Confirm = rm.GetString("resMsg_Confirm", ci).Trim();
            resMsg_PPECodeAddedSuccessfully = rm.GetString("resMsg_PPECodeAddedSuccessfully", ci).Trim();
            }
    }
}
