﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Text;
using System.Threading.Tasks;

namespace iPAS_PPE_Information
{
    class PPELanguageResource
    {

        static CultureInfo ci = null;
        static ResourceManager rm = null;
        static string resMsg_Confirm = string.Empty;
        public string Msg_Confirm
        {
            get { return resMsg_Confirm; }
            set { resMsg_Confirm = value; }
        }

        static string resMsg_SuccessfullyUpdatedPPE = string.Empty;
        public string Msg_SuccessfullyUpdatedPPE
        {
            get { return resMsg_SuccessfullyUpdatedPPE; }
            set { resMsg_SuccessfullyUpdatedPPE = value; }
        }
        static string resMsg_PPEAddedSuccessfully = string.Empty;
        public string Msg_PPEAddedSuccessfully
        {
            get { return resMsg_PPEAddedSuccessfully; }
            set { resMsg_PPEAddedSuccessfully = value; }
        }
        public static void messageResource(string languageCode)
        {
            if (languageCode == "zh-CN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_PPE_Information.resources.PPEResourceCN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "th-TH")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_PPE_Information.resources.PPEResourceTH", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_PPE_Information.resources.PPEResourceEN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
        }
        public static void messageInitialize()
        {
            resMsg_Confirm = rm.GetString("resMsg_Confirm", ci).Trim();
            resMsg_PPEAddedSuccessfully = rm.GetString("resMsg_PPEAddedSuccessfully", ci).Trim();
            resMsg_SuccessfullyUpdatedPPE = rm.GetString("resMsg_SuccessfullyUpdatedPPE", ci).Trim();
        }
    }
}
