﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Text;
using System.Threading.Tasks;

namespace iPAS_CustomerSpecificProduct
{
    class CustomerSpecificProductLanguage
    {
        static CultureInfo ci = null;
        static ResourceManager rm = null;
        static string resMsg_NoRecordFound = string.Empty;
        public string Msg_NoRecordFound
        {
            get { return resMsg_NoRecordFound; }
            set { resMsg_NoRecordFound = value; }
        }

        static string resMsg_Action = string.Empty;
        public string Msg_Action
        {
            get { return resMsg_Action; }
            set { resMsg_Action = value; }
        }
        static string resMsg_AddProductSuccess = string.Empty;
        public string Msg_AddProductSuccess
        {
            get { return resMsg_AddProductSuccess; }
            set { resMsg_AddProductSuccess = value; }
        }
        static string resMsg_UpdateProductSuccess = string.Empty;
        public string Msg_UpdateProductSuccess
        {
            get { return resMsg_UpdateProductSuccess; }
            set { resMsg_UpdateProductSuccess = value; }
        }
        public static void messageResource(string languageCode)
        {
            if (languageCode == "zh-CN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_CustomerSpecificProduct.resources.CustomerSpecificProductCN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "th-TH")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_CustomerSpecificProduct.resources.CustomerSpecificProductTH", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_CustomerSpecificProduct.resources.CustomerSpecificProductEN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
        }
        public static void messageInitialize()
        {
            resMsg_NoRecordFound = rm.GetString("resMsg_NoRecordFound", ci).Trim();
            resMsg_Action = rm.GetString("resMsg_Action", ci).Trim();
            resMsg_AddProductSuccess = rm.GetString("resMsg_AddProductSuccess", ci).Trim();
            resMsg_UpdateProductSuccess = rm.GetString("resMsg_UpdateProductSuccess", ci).Trim();
        }
    }
}
