﻿using AutoItX3Lib;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Configuration;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using System.Drawing;
using System.Drawing.Imaging;
using DataDrivenTesting;
using iPAS_MaterialInformation;

namespace iPAS_PPE_Information
{
    class Downloader
    {
        string minsleep = ConfigurationSettings.AppSettings["min"];
        string midsleep = ConfigurationSettings.AppSettings["mid"];
        string maxsleep = ConfigurationSettings.AppSettings["max"];
        PlantMaterialLanguageTemplate languageResouce = new PlantMaterialLanguageTemplate();
        public void downloadTemplate()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            try
            {

                Click<HtmlSpan>(PropertyType.InnerText, "Plant Material Information");
            }
            catch (Exception e)
            {
                Click<HtmlSpan>(PropertyType.InnerText, "Plant Material Information");
            }
            Thread.Sleep(min);
            int xCoodinate = auto.MouseGetPosX();
            int yCoodinate = auto.MouseGetPosY();
            xCoodinate = xCoodinate - 150;
            auto.MouseMove(xCoodinate, yCoodinate);
            yCoodinate = yCoodinate + 40;
            auto.MouseMove(xCoodinate, yCoodinate);
            auto.MouseClick();
            Thread.Sleep(min);
            Click<HtmlCustom>(PropertyType.Id, "btnDownLoadMaterialTemplateExcel");
            Thread.Sleep(max * 5);
            Click<HtmlDiv>(PropertyType.Id, "footer");
            try {
                WindowButtonClick<WinToolBar>(PropertyType.Name, "Notification");
                WindowButtonClick<WinButton>(PropertyType.Name, "Open");
            }catch(Exception e) { }
            mparentwindow = null;
            Thread.Sleep(max * 15);           
            auto.WinClose("Excel");
            auto.WinClose("Microsoft Excel");
            auto.WinClose("Spreadsheets");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void DownloadAllMaterialDetails()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            try
            {

                Click<HtmlSpan>(PropertyType.InnerText, "Plant Material Information");
            }
            catch (Exception e)
            {
                Click<HtmlSpan>(PropertyType.InnerText, "Plant Material Information");
            }
            Thread.Sleep(min);
            int xCoodinate = auto.MouseGetPosX();
            int yCoodinate = auto.MouseGetPosY();
            xCoodinate = xCoodinate - 150;
            auto.MouseMove(xCoodinate, yCoodinate);
            yCoodinate = yCoodinate + 40;
            auto.MouseMove(xCoodinate, yCoodinate);
            auto.MouseClick();
            Thread.Sleep(min);

            Click<HtmlCustom>(PropertyType.Id, "ContentPlaceHolder1_btnDownloadMaterials");
            Thread.Sleep(max * 10);
            Click<HtmlDiv>(PropertyType.Id, "footer");
            try {
                WindowButtonClick<WinToolBar>(PropertyType.Name, "Notification");
                WindowButtonClick<WinButton>(PropertyType.Name, "Open");
            }catch(Exception e) { }
            mparentwindow = null;
            Thread.Sleep(max * 15);
            auto.WinClose("Excel");
            auto.WinClose("Microsoft Excel");
            auto.WinClose("Spreadsheets");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void pageNavigator()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlDiv>(PropertyType.Id, "footer");
           Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            Click<HtmlHyperlink>(PropertyType.Id, "ctl01_hrefLast");
           Thread.Sleep(mid);
           validation();
            Thread.Sleep(mid);
            try
            {
                Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearchAll");
            }catch(Exception e) { }
           Thread.Sleep(max);
            auto.Send("{F5}");
            Thread.Sleep(max);
        }
        public void downloadTemplate2()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            try
            {

                Click<HtmlSpan>(PropertyType.InnerText, "Plant Material Information");
            }
            catch (Exception e)
            {
                Click<HtmlSpan>(PropertyType.InnerText, "Plant Material Information");
            }
            Thread.Sleep(min);
            int xCoodinate = auto.MouseGetPosX();
            int yCoodinate = auto.MouseGetPosY();
            xCoodinate = xCoodinate - 150;
            auto.MouseMove(xCoodinate, yCoodinate);
            yCoodinate = yCoodinate + 65;
            auto.MouseMove(xCoodinate, yCoodinate);
            auto.MouseClick();
            Thread.Sleep(min);
            Click<HtmlCustom>(PropertyType.Id, "ContentPlaceHolder1_btnDownloadZipTemplate");
            Thread.Sleep(max * 2);
            Click<HtmlDiv>(PropertyType.Id, "footer");
            try
            {
                WindowButtonClick<WinToolBar>(PropertyType.Name, "Notification");
                WindowButtonClick<WinButton>(PropertyType.Name, "Open");
            }
            catch (Exception e) { }
            mparentwindow = null;
            Thread.Sleep(max * 10);
            auto.WinClose("WinZipper");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void UploadMSDSFiles()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            //try
            //{

            //    Click<HtmlSpan>(PropertyType.InnerText, "Plant Material Information");
            //}
            //catch (Exception e)
            //{
            //    Click<HtmlSpan>(PropertyType.InnerText, "Plant Material Information");
            //}
            //Thread.Sleep(min);
            //int xCoodinate = auto.MouseGetPosX();
            //int yCoodinate = auto.MouseGetPosY();
            //xCoodinate = xCoodinate - 150;
            //auto.MouseMove(xCoodinate, yCoodinate);
            //yCoodinate = yCoodinate + 65;
            //auto.MouseMove(xCoodinate, yCoodinate);
            //auto.MouseClick();
            //Thread.Sleep(min);

            Click<HtmlCustom>(PropertyType.Id, "ContentPlaceHolder1_btnUploadZipFiles");
            Click<HtmlFileInput>(PropertyType.Id, "ContentPlaceHolder1_uploadZipFileItems");
            PathEnterText<WinEdit>(PropertyType.Name, "File name:", ExcelDataTable.ReadData(1, "zipPath"));
            Thread.Sleep(max*30);
            /****************Here check Validate File is Uploaded or not******************/
            var data = window.ExecuteScript("var data=document.getElementById('lblZipUploadError').innerHTML; return data;");
            string msg = data.ToString().Trim();
            if (msg != languageResouce.Msg_FileUploadedSuccessfully)
            {
                string screenShotName = "ZipFileIs_NotUploaded";
                screenShot(screenShotName);
            }
            Assert.AreEqual(languageResouce.Msg_FileUploadedSuccessfully, msg, msg);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void validateZipFileData()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            try
            {
                Click<HtmlRadioButton>(PropertyType.Id, "rdoIdhID");
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtPlantMaterial", ExcelDataTable.ReadData(1, "Material Number"));
                Thread.Sleep(min);
            }
            catch (Exception e) { }
            Thread.Sleep(mid);
           Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearch");
            Thread.Sleep(mid);
            ////************Here validate on the Search TextBoX Data is Enter or Not**************///
            var data1 = window.ExecuteScript("var data=document.getElementById('spnSearchError').innerHTML;  return  data");
            string successMsg1 = data1.ToString().Trim();
            if (successMsg1 != "")
            {
                string screenShotName = "PleaseEnterSearch_Criteria";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", successMsg1, successMsg1);
            Thread.Sleep(mid);
            bool b1 = Search();
            if (b1)
            {
                string screenShotName = "DataIs_NotThere";
                screenShot(screenShotName);
            }
            Assert.IsFalse(b1, "Data is Not There");
            Thread.Sleep(mid);

            /**************Here Checking the MSDS columns data ***********/
            //UcMaterialSummary2085946_divLangVersion
            string msdsId= "UcMaterialSummary"+ ExcelDataTable.ReadData(1, "Material Number").Trim()+ "_divLangVersion";
            msdsId = "'"+ msdsId + "'";
            var msdsData = window.ExecuteScript("var data=document.getElementById("+msdsId+ ").getElementsByTagName('a').length;  return  data");
            int len = Int32.Parse(msdsData.ToString().Trim());
            bool b2 = false;
            if (len > 0)
                b2 = true;
            else
                b2 = false;

            if (!b2)
            {
                string screenShotName = "Empty_MSDSColumn";
                screenShot(screenShotName);
            }
            Assert.IsTrue(b2, "Data Is Not there in MSDS Column");
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public bool Search()
        {
            BrowserWindow window = new BrowserWindow();
            string msg1 = string.Empty;
            bool b1 = false;
            Thread.Sleep(800);
            try
            {
                var data1 = window.ExecuteScript("var data=document.getElementById('ContentPlaceHolder1_tbPlantMaterialInfo').getElementsByTagName('td')[0];  return  data.innerHTML");
                msg1 = data1.ToString().Trim();
            }
            catch (Exception e) { }
            b1 = msg1.Equals(languageResouce.Msg_NoRecordFound);
            return b1;
        }
        public void validation()
        {
            BrowserWindow window = new BrowserWindow();
            Thread.Sleep(1000);
            var len = window.ExecuteScript("var data=document.getElementById('ContentPlaceHolder1_tbPlantMaterialInfo').getElementsByTagName('td');  return  data.length");
            string length = len.ToString().Trim();
            int Data = Convert.ToInt32(length);
            bool flag = true;
            if (Data == 0)
                flag = false;

            string error = "Data is Not there On Last Navigate page";
            if (!flag)
            {
                string screenShotName = "DataIs_NotThereOnLastNavigatePage";
                screenShot(screenShotName);
            }

            Assert.IsTrue(flag, error);
        }
        public void screenShot(string imgName)
        {
            BrowserWindow window = new BrowserWindow();
            string path = ConfigurationSettings.AppSettings["ScreenShot"];
            path = path + @"\\iPAS_MaterialInformation";
            Directory.CreateDirectory(path);

            try
            {
                window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
                Image image = window.CaptureImage();
                image.Save(path + "\\" + imgName + ".jpeg", ImageFormat.Jpeg);
                image.Dispose();
            }
            catch (Exception e) { }
            Console.WriteLine("Screen Shot is Avaliable in " + path + "\t" + "Folder");
        }



        public void WindowButtonClick<T>(PropertyType type, string propertyvalue) where T : WinControl
        {
            WinControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Name)
                genericControl.SearchProperties[WinControl.PropertyNames.Name] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void PathEnterText<T>(PropertyType type, string propertyvalue, string text) where T : WinEdit
        {
            WinEdit genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            genericControl.FilterProperties[WinEdit.PropertyNames.Name] = propertyvalue;
            AutoItX3 auto = new AutoItX3();
            auto.WinActivate("Choose File to Upload");
            auto.Send(text);
            auto.Send("{ENTER}");
            Thread.Sleep(1000);
        }

        public void Click<T>(PropertyType type, string propertyvalue) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });

            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;
            else if (type == PropertyType.InnerText)
            {
                genericControl.SearchProperties[HtmlControl.PropertyNames.InnerText] = propertyvalue;
            }
            else if (type == PropertyType.TagInstance)
                genericControl.FilterProperties[HtmlControl.PropertyNames.TagInstance] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void EnterText<T>(PropertyType type, string propertyvalue, string text) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;

            Keyboard.SendKeys(genericControl, text);
        }
        private BrowserWindow mparentwindow { get; set; }
        public enum PropertyType
        {
            Id,
            Name,
            InnerText,
            TagInstance
        }
        public BrowserWindow TopParentWindow()
        {

            BrowserWindow window = new BrowserWindow();
            window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
            return window;
        }
        public BrowserWindow ParentWindow
        {
            get
            {
                if (this.mparentwindow == null)
                {
                    this.mparentwindow = TopParentWindow();
                }
                return this.mparentwindow;
            }
        }
    }
}
