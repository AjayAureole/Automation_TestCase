﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Text;
using System.Threading.Tasks;

namespace iPAS_MaterialInformation
{
    class PlantMaterialLanguageTemplate
    {
        static CultureInfo ci = null;
        static ResourceManager rm = null;   
        static string resMsg_NoRecordFound = string.Empty;
        public string Msg_NoRecordFound
        {
            get { return resMsg_NoRecordFound; }
            set { resMsg_NoRecordFound = value; }
        }
        static string resMsg_FileUploadedSuccessfully = string.Empty;
        public string Msg_FileUploadedSuccessfully
        {
            get { return resMsg_FileUploadedSuccessfully; }
            set { resMsg_FileUploadedSuccessfully = value; }
        }
        public static void messageResource(string languageCode)
        {
            if (languageCode == "zh-CN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_MaterialInformation.resources.PlantMaterialCN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "th-TH")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_MaterialInformation.resources.PlantMaterialTH", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_MaterialInformation.resources.PlantMaterialEN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
        }
        public static void messageInitialize()
        {
            resMsg_NoRecordFound = rm.GetString("resMsg_NoRecordFound", ci).Trim();
            resMsg_FileUploadedSuccessfully = rm.GetString("resMsg_FileUploadedSuccessfully", ci).Trim();
        }
    }
}