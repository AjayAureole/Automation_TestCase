﻿using AutoItX3Lib;
using DataDrivenTesting;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace iPAS_UserInformation
{
    class UserInformation
    {
        string minsleep = ConfigurationSettings.AppSettings["min"];
        string midsleep = ConfigurationSettings.AppSettings["mid"];
        string maxsleep = ConfigurationSettings.AppSettings["max"];
        public void uploadUserInfoExcelFile()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "lnkAdmin");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkUserInfo");
            Thread.Sleep(min);
            auto.MouseClick();
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            try
            {

                Click<HtmlSpan>(PropertyType.InnerText, "User Information");
            }
            catch (Exception e)
            {
                Click<HtmlSpan>(PropertyType.InnerText, "User Information");
            }
            Thread.Sleep(min);
            int xCoodinate = auto.MouseGetPosX();
            int yCoodinate = auto.MouseGetPosY();
            xCoodinate = xCoodinate - 120;
            auto.MouseMove(xCoodinate, yCoodinate);
            yCoodinate = yCoodinate + 40;
            auto.MouseMove(xCoodinate, yCoodinate);
            auto.MouseClick();
            Thread.Sleep(mid);
            Click<HtmlCustom>(PropertyType.Id, "btnUploadUserInfo");
            Click<HtmlFileInput>(PropertyType.Id, "ContentPlaceHolder1_uploadFile");
            try {
                PathEnterText<WinEdit>(PropertyType.Name, "File name:", ExcelDataTable.ReadData(1, "userInfoFilePath"));
            }catch(Exception e) { }
            Thread.Sleep(max*20);
            auto.Send("{F5}");
            Thread.Sleep(max);
            var data1 = window.ExecuteScript("var data=document.getElementById('lblUploadError').innerHTML;  return  data");
            string successMsg1 = data1.ToString().Trim();
            if (successMsg1!="")
            {
                string screenShotName = "FileIs_NotUploading";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", successMsg1, successMsg1);
            Thread.Sleep(mid);
            auto.Send("{F5}");           
            Thread.Sleep(mid);
        }
        public void deleteUploadedUserInfo()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtUserName",ExcelDataTable.ReadData(1, "First Name"));
            }catch(Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtEmailID", ExcelDataTable.ReadData(1, "Email ID"));
            }
            catch (Exception e) { }
            Thread.Sleep(min);
            Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearch");
            Thread.Sleep(mid);           
            ////************Here validate on the Search TextBoX Data is Enter or Not**************///
            var data1 = window.ExecuteScript("var data=document.getElementById('spnSearchError').innerHTML;  return  data");
            string successMsg1 = data1.ToString().Trim();
            if (successMsg1 != "")
            {
                string screenShotName = "PleaseEnterSearch_Criteria";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", successMsg1, successMsg1);
            mparentwindow = null;
            Click<HtmlHeaderCell>(PropertyType.InnerText, "Action");
            int Mx1 = auto.MouseGetPosX();
            int My1 = auto.MouseGetPosY();
            My1 = My1 + 30;
            Mx1 = Mx1 + 10;
            Thread.Sleep(mid);
            auto.MouseMove(Mx1, My1);
            auto.MouseClick();
            Thread.Sleep(min);
            auto.Send("{ENTER}");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);

        }
        public void addNewUserInformation()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlCustom>(PropertyType.Id, "ContentPlaceHolder1_btnAddNewUser");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtFirstName", ExcelDataTable.ReadData(1, "addFirst Name"));
            }catch(Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtLastName", ExcelDataTable.ReadData(1, "addLast Name"));

            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtUserName", ExcelDataTable.ReadData(1, "addLogin Name"));

            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtPassword", ExcelDataTable.ReadData(1, "addPassword"));

            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtEmailID", ExcelDataTable.ReadData(1, "addEmail-ID"));

            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpLanguages", ExcelDataTable.ReadData(1, "addPrefered Languages"));

            }
            catch (Exception e) { }
            Thread.Sleep(min);
            //CLick Is Site Admin
           // Click<HtmlCheckBox>(PropertyType.Id, "ContentPlaceHolder1_chkUserAccessID");
            /*****************Uploading the image of the User************/
            Click<HtmlFileInput>(PropertyType.Id, "fileToUpload");
            try
            {
                PathEnterText<WinEdit>(PropertyType.Name, "File name:", ExcelDataTable.ReadData(1, "addUserImageFilePath"));
            }
            catch (Exception e) { }
            Thread.Sleep(mid*2);
            //Click Production Line
            try
            {
                Click<HtmlCheckBox>(PropertyType.Id, "ContentPlaceHolder1_chkProductionLineList_0");
            }catch(Exception e) { }
            Thread.Sleep(min);
            //Click Dispatch Areas
            try {
                Click<HtmlCheckBox>(PropertyType.Id, "ContentPlaceHolder1_chkDispatchList_0");
            }
            catch (Exception e) { }
            Thread.Sleep(min);
            //Click Roles
            try {
                Click<HtmlCheckBox>(PropertyType.Id, "ContentPlaceHolder1_dlstRoles_chkRoleName_0_0_0");
            }
            catch (Exception e) { }
            Thread.Sleep(min);
            try { 
            Click<HtmlCheckBox>(PropertyType.Id, "ContentPlaceHolder1_dlstRoles_chkRoleName_1_0_1");
            }
            catch (Exception e) { }
            Thread.Sleep(min);

            try {
                Click<HtmlCheckBox>(PropertyType.Id, "ContentPlaceHolder1_dlstRoles_chkRoleName_2_0_2");
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlSpan>(PropertyType.Id, "ContentPlaceHolder1_dlstRoles_lblDepartName_0");
                Click<HtmlSpan>(PropertyType.Id, "ContentPlaceHolder1_dlstRoles_lblDepartName_1");
            }
            catch (Exception e) { }
            Thread.Sleep(min);
            try { 
            Click<HtmlCheckBox>(PropertyType.Id, "ContentPlaceHolder1_dlstRoles_chkRoleName_3_0_3");
            }
            catch (Exception e) { }
            Thread.Sleep(min);
            try { 
            Click<HtmlCheckBox>(PropertyType.Id, "ContentPlaceHolder1_dlstRoles_chkRoleName_4_0_4");
            }
            catch (Exception e) { }
            Thread.Sleep(min);
            try { 
            Click<HtmlCheckBox>(PropertyType.Id, "ContentPlaceHolder1_dlstRoles_chkRoleName_5_0_5");
            }
            catch (Exception e) { }
            Thread.Sleep(min);
            //click Footer
            Click<HtmlDiv>(PropertyType.Id,"footer");
            Thread.Sleep(min);
            //click SITE INSPECTION
            try { 
            Click<HtmlCheckBox>(PropertyType.Id, "ContentPlaceHolder1_dlstRoles_chkRoleName_9_0_9");
            }
            catch (Exception e) { }
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnCreateUser");
            Thread.Sleep(mid);           

            string successMsg = string.Empty;
            try {
             var data = window.ExecuteScript("var data=document.getElementById('spnSearchError').innerHTML;  return  data");
             successMsg = data.ToString().Trim();
            }
            catch (Exception e) { }
            if (successMsg != "")
            {
                string screenShotName = "addNewUserInformation_NotProperInformation";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", successMsg, successMsg);
            Thread.Sleep(mid);
        }
        public void seachAndUpdate()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(max);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtUserName", ExcelDataTable.ReadData(1, "addLogin Name"));
                Thread.Sleep(min);
            }
            catch (Exception e) { }
            Thread.Sleep(min);
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtEmailID", ExcelDataTable.ReadData(1, "addEmail-ID"));

            }catch(Exception e) { }
            Thread.Sleep(min);
            Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearch");

            ////************Here validate on the Search TextBoX Data is Enter or Not**************///
            var data1 = window.ExecuteScript("var data=document.getElementById('spnSearchError').innerHTML;  return  data");
            string successMsg1 = data1.ToString().Trim();
            if (successMsg1 != "")
            {
                string screenShotName = "PleaseEnterSearch_Criteria";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", successMsg1, successMsg1);
            Thread.Sleep(min);
            mparentwindow = null;
            Click<HtmlHeaderCell>(PropertyType.InnerText, "Action");
            int Mx1 = auto.MouseGetPosX();
            int My1 = auto.MouseGetPosY();
            My1 = My1 + 30;
            Mx1 = Mx1 - 15;
            Thread.Sleep(max);
            auto.MouseMove(Mx1, My1);
            auto.MouseClick();
            Thread.Sleep(max);
            auto.Send("{F5}");
            Thread.Sleep(max);
            /*********Update the User information********************/

            try
            {
                Click<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtFirstName");
                auto.Send("{BACKSPACE 20}");
                auto.Send("{DEL 20}");
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtFirstName", ExcelDataTable.ReadData(1, "UpFirst Name"));
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtLastName");
                auto.Send("{BACKSPACE 20}");
                auto.Send("{DEL 20}");
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtLastName", ExcelDataTable.ReadData(1, "UpLast Name"));

            }
            catch (Exception e) { }
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtUserName");
                auto.Send("{BACKSPACE 20}");
                auto.Send("{DEL 20}");
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtUserName", ExcelDataTable.ReadData(1, "UpLogin Name"));

            }
            catch (Exception e) { }
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtPassword");
                auto.Send("{BACKSPACE 20}");
                auto.Send("{DEL 20}");
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtPassword", ExcelDataTable.ReadData(1, "UpPassword"));

            }
            catch (Exception e) { }
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtEmailID");
                auto.Send("{BACKSPACE 20}");
                auto.Send("{DEL 20}");
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtEmailID", ExcelDataTable.ReadData(1, "UpEmail-ID"));


            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpLanguages", ExcelDataTable.ReadData(1, "UpPrefered Languages"));

            }
            catch (Exception e) { }
            Thread.Sleep(min);
            //CLick Is Site Admin
           Click<HtmlCheckBox>(PropertyType.Id, "ContentPlaceHolder1_chkUserAccessID");
            /*****************Uploading the image of the User************/
            Click<HtmlFileInput>(PropertyType.Id, "fileToUpload");
            try
            {
                PathEnterText<WinEdit>(PropertyType.Name, "File name:", ExcelDataTable.ReadData(1, "UpUserImageFilePath"));
            }
            catch (Exception e) { }
            Thread.Sleep(mid * 2);
            try
            {
                Click<HtmlCheckBox>(PropertyType.Id, "ContentPlaceHolder1_chkDispatchList_2");
            }catch(Exception e) { }
            Thread.Sleep(min);
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnCreateUser");
            Thread.Sleep(mid);
            string successMsg = string.Empty;
            try
            {
                var data = window.ExecuteScript("var data=document.getElementById('spnSearchError').innerHTML;  return  data");
                successMsg = data.ToString().Trim();
            }
            catch (Exception e) { }
            if (successMsg != "")
            {
                string screenShotName = "Updating_FailUserInformation";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", successMsg, successMsg);
            Thread.Sleep(mid);
        }
        public void deleteNewAddUserInfo()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtUserName", ExcelDataTable.ReadData(1, "UpFirst Name"));
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtEmailID", ExcelDataTable.ReadData(1, "UpEmail-ID"));
            }
            catch (Exception e) { }
            Thread.Sleep(min);
            Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearch");
            Thread.Sleep(mid);
            ////************Here validate on the Search TextBoX Data is Enter or Not**************///
            var data1 = window.ExecuteScript("var data=document.getElementById('spnSearchError').innerHTML;  return  data");
            string successMsg1 = data1.ToString().Trim();
            if (successMsg1 != "")
            {
                string screenShotName = "PleaseEnterSearch_Criteria";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", successMsg1, successMsg1);
            mparentwindow = null;
            Click<HtmlHeaderCell>(PropertyType.InnerText, "Action");
            int Mx1 = auto.MouseGetPosX();
            int My1 = auto.MouseGetPosY();
            My1 = My1 + 30;
            Mx1 = Mx1 + 10;
            Thread.Sleep(mid);
            auto.MouseMove(Mx1, My1);
            auto.MouseClick();
            Thread.Sleep(min);
            auto.Send("{ENTER}");
            Thread.Sleep(mid);
            try {
                Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearchAll");
            }catch(Exception e) { }
            Thread.Sleep(max);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void pageNavigator()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlDiv>(PropertyType.Id, "footer");
            //try
            //{
            //    var pageCount = window.ExecuteScript("var data=document.getElementById('ctl01_divPager').getElementsByTagName('a');  return  data.length");
            //    string len = pageCount.ToString();
            //    int length = Convert.ToInt32(len);
            //    for (int i = 1; i <= length; i++)
            //    {
            //        string tagId = "ctl01_hrefNum" + i;
            //        Thread.Sleep(mid);
            //        if (i == 7)
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);          
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);

            Click<HtmlHyperlink>(PropertyType.Id, "ucPager_hrefLast");
            Thread.Sleep(max);
            validation();
            Thread.Sleep(mid);

            //    tagId = "";
            //}
            //}
            //catch (Exception e) { }
            auto.Send("{F5}");
            Thread.Sleep(min);
        }
        public void validation()
        {
            BrowserWindow window = new BrowserWindow();
            Thread.Sleep(1000);
            var len = window.ExecuteScript("var data=document.getElementById('ContentPlaceHolder1_tblUserInfo').getElementsByTagName('td');  return  data.length");
            string length = len.ToString().Trim();
            int Data = Convert.ToInt32(length);
            bool flag = true;
            if (Data == 0)
                flag = false;

            string error = "Data is Not there On Last Navigate page";
            if (!flag)
            {
                string screenShotName = "DataIs_NotThereOnLastNavigatePage";
                screenShot(screenShotName);
            }
            Assert.IsTrue(flag, error);
        }
        public void screenShot(string imgName)
        {
            BrowserWindow window = new BrowserWindow();
            string path = ConfigurationSettings.AppSettings["ScreenShot"];
            path = path + @"\\iPAS_UserInformation";
            Directory.CreateDirectory(path);
            try
            {
                window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
                Image image = window.CaptureImage();
                image.Save(path + "\\" + imgName + ".jpeg", ImageFormat.Jpeg);
                image.Dispose();
            }
            catch (Exception e) { }
            Console.WriteLine("Screen Shot is Avaliable in " + path + "\t" + "Folder");
        }

        public void WindowButtonClick<T>(PropertyType type, string propertyvalue) where T : WinControl
        {
            WinControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Name)
                genericControl.SearchProperties[WinControl.PropertyNames.Name] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void PathEnterText<T>(PropertyType type, string propertyvalue, string text) where T : WinEdit
        {
            WinEdit genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            genericControl.FilterProperties[WinEdit.PropertyNames.Name] = propertyvalue;
            AutoItX3 auto = new AutoItX3();
            auto.WinActivate("Choose File to Upload");
            auto.Send(text);
            auto.Send("{ENTER}");
            Thread.Sleep(1000);
        }
        public void Click<T>(PropertyType type, string propertyvalue) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });

            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;
            else if (type == PropertyType.InnerText)
            {
                genericControl.SearchProperties[HtmlControl.PropertyNames.InnerText] = propertyvalue;
            }
            else if (type == PropertyType.TagInstance)
                genericControl.FilterProperties[HtmlControl.PropertyNames.TagInstance] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void EnterText<T>(PropertyType type, string propertyvalue, string text) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;

            Keyboard.SendKeys(genericControl, text);

        }
        private BrowserWindow mparentwindow { get; set; }
        public enum PropertyType
        {
            Id,
            Name,
            InnerText,
            TagInstance
        }
        public BrowserWindow TopParentWindow()
        {

            BrowserWindow window = new BrowserWindow();
            window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
            return window;
        }
        public BrowserWindow ParentWindow
        {
            get
            {
                if (this.mparentwindow == null)
                {
                    this.mparentwindow = TopParentWindow();
                }
                return this.mparentwindow;
            }
        }

    }
}
