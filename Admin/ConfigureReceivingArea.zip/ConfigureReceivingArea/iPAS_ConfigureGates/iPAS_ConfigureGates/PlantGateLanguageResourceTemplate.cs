﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Text;
using System.Threading.Tasks;

namespace iPAS_ConfigureGates
{
    class PlantGateLanguageResourceTemplate
    {
        static CultureInfo ci = null;
        static ResourceManager rm = null;
        static string resMsg_EnterGateName = string.Empty;
        public string Msg_EnterGateName
        {
            get { return resMsg_EnterGateName; }
            set { resMsg_EnterGateName = value; }
        }

        static string resMsg_FailedToAddGateInfo = string.Empty;
        public string Msg_FailedToAddGateInfo
        {
            get { return resMsg_FailedToAddGateInfo; }
            set { resMsg_FailedToAddGateInfo = value; }
        }
        static string resMsg_GateAddedSuccess = string.Empty;
        public string Msg_GateAddedSuccess
        {
            get { return resMsg_GateAddedSuccess; }
            set { resMsg_GateAddedSuccess = value; }
        }
        static string resMsg_GateInfoUpdated = string.Empty;
        public string Msg_GateInfoUpdated
        {
            get { return resMsg_GateInfoUpdated; }
            set { resMsg_GateInfoUpdated = value; }
        }
        static string resMsg_GateNameExist = string.Empty;
        public string Msg_GateNameExist
        {
            get { return resMsg_GateNameExist; }
            set { resMsg_GateNameExist = value; }
        }
        static string resMsg_NoRecordsFound = string.Empty;
        public string Msg_NoRecordsFound
        {
            get { return resMsg_NoRecordsFound; }
            set { resMsg_NoRecordsFound = value; }
        }
        static string resMsg_SelectBuildingName = string.Empty;
        public string Msg_SelectBuildingName
        {
            get { return resMsg_SelectBuildingName; }
            set { resMsg_SelectBuildingName = value; }
        }
      

        public static void messageResource(string languageCode)
        {
            if (languageCode == "zh-CN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ConfigureGates.resources.PlantGateCN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "th-TH")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ConfigureGates.resources.PlantGateTH", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "vi-VN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ConfigureGates.resources.PlantGateVN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "ko-KR")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ConfigureGates.resources.PlantGateKR", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "ja-JP")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ConfigureGates.resources.PlantGateJP", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "id-ID")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ConfigureGates.resources.PlantGateID", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ConfigureGates.resources.PlantGateEN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
        }
        public static void messageInitialize()
        {
            resMsg_EnterGateName = rm.GetString("resMsg_EnterGateName", ci).Trim();
            resMsg_FailedToAddGateInfo = rm.GetString("resMsg_FailedToAddGateInfo", ci).Trim();
            resMsg_GateAddedSuccess = rm.GetString("resMsg_GateAddedSuccess", ci).Trim();
            resMsg_GateInfoUpdated = rm.GetString("resMsg_GateInfoUpdated", ci).Trim();
            resMsg_GateNameExist = rm.GetString("resMsg_GateNameExist", ci).Trim();
            resMsg_NoRecordsFound = rm.GetString("resMsg_NoRecordsFound", ci).Trim();
            resMsg_SelectBuildingName = rm.GetString("resMsg_SelectBuildingName", ci).Trim();
        }
    }
}
