﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Text;
using System.Threading.Tasks;

namespace iPAS_ConfigureGates
{
    class LanguageResourceTemplate
    {
        static CultureInfo ci = null;
        static ResourceManager rm = null;
        static string resMsg_BuildingAddSuccess = string.Empty;
        public string Msg_BuildingAddSuccess
        {
            get { return resMsg_BuildingAddSuccess; }
            set { resMsg_BuildingAddSuccess = value; }
        }

        static string resMsg_FailedToAddBuilding = string.Empty;
        public string Msg_FailedToAddBuilding
        {
            get { return resMsg_FailedToAddBuilding; }
            set { resMsg_FailedToAddBuilding = value; }
        }
        static string resMsg_EnterBuildingName = string.Empty;
        public string Msg_EnterBuildingName
        {
            get { return resMsg_EnterBuildingName; }
            set { resMsg_EnterBuildingName = value; }
        }
        static string resMsg_EditBuildingSuccess = string.Empty;
        public string Msg_EditBuildingSuccess
        {
            get { return resMsg_EditBuildingSuccess; }
            set { resMsg_EditBuildingSuccess = value; }
        }
        static string resMsg_BuildingExists = string.Empty;
        public string Msg_BuildingExists
        {
            get { return resMsg_BuildingExists; }
            set { resMsg_BuildingExists = value; }
        }
        static string resMsg_NoRecordsFound = string.Empty;
        public string Msg_NoRecordsFound
        {
            get { return resMsg_NoRecordsFound; }
            set { resMsg_NoRecordsFound = value; }
        }
        static string resMsg_FailedToLoadBuildingList = string.Empty;
        public string Msg_FailedToLoadBuildingList
        {
            get { return resMsg_FailedToLoadBuildingList; }
            set { resMsg_FailedToLoadBuildingList = value; }
        }
        static string resMsg_Error = string.Empty;
        public string Msg_Error
        {
            get { return resMsg_Error; }
            set { resMsg_Error = value; }
        }
        static string resMsg_FailedToEditBuildingInfo = string.Empty;
        public string Msg_FailedToEditBuildingInfo
        {
            get { return resMsg_FailedToEditBuildingInfo; }
            set { resMsg_FailedToEditBuildingInfo = value; }
        }
        static string resMsg_DeleteConfirmBuilding = string.Empty;
        public string Msg_DeleteConfirmBuilding
        {
            get { return resMsg_DeleteConfirmBuilding; }
            set { resMsg_DeleteConfirmBuilding = value; }
        }
        static string resMsg_DeleteConfirmBuildingGateAssigned = string.Empty;
        public string Msg_DeleteConfirmBuildingGateAssigned
        {
            get { return resMsg_DeleteConfirmBuildingGateAssigned; }
            set { resMsg_DeleteConfirmBuildingGateAssigned = value; }
        }

        static string resMsg_FailedToRemoveBuildingInfo = string.Empty;
        public string Msg_FailedToRemoveBuildingInfo
        {
            get { return resMsg_FailedToRemoveBuildingInfo; }
            set { resMsg_FailedToRemoveBuildingInfo = value; }
        }
        static string resMsg_BtnAdd = string.Empty;
        public string Msg_BtnAdd
        {
            get { return resMsg_BtnAdd; }
            set { resMsg_BtnAdd = value; }
        }
        static string resMsg_BtnUpdate = string.Empty;
        public string Msg_BtnUpdate
        {
            get { return resMsg_BtnUpdate; }
            set { resMsg_BtnUpdate = value; }
        }
        static string resMsg_Confirm = string.Empty;
        public string Msg_Confirm
        {
            get { return resMsg_Confirm; }
            set { resMsg_Confirm = value; }
        }

        static string resMsg_Cancel = string.Empty;
        public string Msg_Cancel
        {
            get { return resMsg_Cancel; }
            set { resMsg_Cancel = value; }
        }
        static string resMsg_Ok = string.Empty;
        public string Msg_Ok
        {
            get { return resMsg_Ok; }
            set { resMsg_Ok = value; }
        }


        public static void messageResource(string languageCode)
        {
            if (languageCode == "zh-CN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ConfigureGates.resources.PlantBuildingResourceCN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }else if (languageCode == "th-TH")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ConfigureGates.resources.PlantBuildingResourceTH", Assembly.GetExecutingAssembly());
                messageInitialize();
            }else if(languageCode == "vi-VN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ConfigureGates.resources.PlantBuildingResourceVN", Assembly.GetExecutingAssembly());
                messageInitialize();
            } else if (languageCode == "ko-KR")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ConfigureGates.resources.PlantBuildingResourceKR", Assembly.GetExecutingAssembly());
                messageInitialize();
            } else if (languageCode == "ja-JP")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ConfigureGates.resources.PlantBuildingResourceJP", Assembly.GetExecutingAssembly());
                messageInitialize();
            }else if(languageCode == "id-ID")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ConfigureGates.resources.PlantBuildingResourceID", Assembly.GetExecutingAssembly());
                messageInitialize();
            }else
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ConfigureGates.resources.PlantBuildingResourceEN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
        }
        public static void messageInitialize()
        {
            resMsg_BuildingAddSuccess = rm.GetString("resMsg_BuildingAddSuccess", ci).Trim();
            resMsg_FailedToAddBuilding = rm.GetString("resMsg_FailedToAddBuilding", ci).Trim();
            resMsg_EnterBuildingName = rm.GetString("resMsg_EnterBuildingName", ci).Trim();
            resMsg_EditBuildingSuccess = rm.GetString("resMsg_EditBuildingSuccess", ci).Trim();
            resMsg_BuildingExists = rm.GetString("resMsg_BuildingExists", ci).Trim();
            resMsg_NoRecordsFound = rm.GetString("resMsg_NoRecordsFound", ci).Trim();
            resMsg_FailedToLoadBuildingList = rm.GetString("resMsg_FailedToLoadBuildingList", ci).Trim();
            resMsg_Error = rm.GetString("resMsg_Error", ci).Trim();
            resMsg_FailedToEditBuildingInfo = rm.GetString("resMsg_FailedToEditBuildingInfo", ci).Trim();
            resMsg_DeleteConfirmBuilding = rm.GetString("resMsg_DeleteConfirmBuilding", ci).Trim();
            resMsg_DeleteConfirmBuildingGateAssigned = rm.GetString("resMsg_DeleteConfirmBuildingGateAssigned", ci).Trim();
            resMsg_FailedToRemoveBuildingInfo = rm.GetString("resMsg_FailedToRemoveBuildingInfo", ci).Trim();
            resMsg_BtnAdd = rm.GetString("resMsg_BtnAdd", ci).Trim();
            resMsg_BtnUpdate = rm.GetString("resMsg_BtnUpdate", ci).Trim();
            resMsg_Confirm = rm.GetString("resMsg_Confirm", ci).Trim();
            resMsg_Cancel = rm.GetString("resMsg_Cancel", ci).Trim();
            resMsg_Ok = rm.GetString("resMsg_Ok", ci).Trim();
        }
    }
}
