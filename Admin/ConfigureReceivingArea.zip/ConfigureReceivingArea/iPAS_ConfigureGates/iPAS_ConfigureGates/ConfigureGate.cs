﻿using AutoItX3Lib;
using DataDrivenTesting;
using iPAS_ConfigureGates;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Configuration;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Threading;

namespace ConfigureReceivingArea
{
    class ConfigureGate
    {
        string minsleep = ConfigurationSettings.AppSettings["min"];
        string midsleep = ConfigurationSettings.AppSettings["mid"];
        string maxsleep = ConfigurationSettings.AppSettings["max"];

        LanguageResourceTemplate languageResource = new LanguageResourceTemplate();
        PlantGateLanguageResourceTemplate plantgateresource = new PlantGateLanguageResourceTemplate();

        public void addPlantBuildings()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "lnkAdmin");
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkGRIndex");
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkBuilding");
            auto.MouseClick();
            Thread.Sleep(min);

            /*****Here Checking how Many record is there befor add ******/

         /*
            var totalbefore = window.ExecuteScript("var data=document.getElementById('spnTotalRecords').innerHTML;  return  data");
            string tot = totalbefore.ToString().Trim();
            int totalbeforerecord = Convert.ToInt32(totalbefore);
        */
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtBuildingName", ExcelDataTable.ReadData(1, "BuildingName"));
            }
            catch(Exception e){ }
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnAddBuilding");
            Thread.Sleep(mid);
            var data = window.ExecuteScript("var data=document.getElementById('spnAddBuildingError').innerHTML;  return  data");
            string successMsg = data.ToString().Trim();
            if (languageResource.Msg_BuildingAddSuccess!= successMsg)
            {
                string screenShotName = "BuildingAddNot_Success";
                screenShot(screenShotName);
            }
            Assert.AreEqual(languageResource.Msg_BuildingAddSuccess,successMsg, successMsg);
            Thread.Sleep(min);
/*
            var afterTotal = window.ExecuteScript("var data=document.getElementById('spnTotalRecords').innerHTML;  return  data");
            string afterTot = afterTotal.ToString().Trim();
            int afterTotalRecords = Convert.ToInt32(afterTot);
            totalbeforerecord = totalbeforerecord + 1;
            Thread.Sleep(mid);
            if (afterTotalRecords != totalbeforerecord)
            {
                string screenShotName = "afterTotalRecordsIs_NotProper";
                screenShot(screenShotName);
            }
            Assert.AreEqual(afterTotalRecords, totalbeforerecord, "Total Record value is Not Proper");
*/
            Thread.Sleep(min);

            /******************Update Building Information************************/
            auto.Send("{F5}");
            auto.Send("{F5}");
            Thread.Sleep(max);

            Click<HtmlSpan>(PropertyType.InnerText, ExcelDataTable.ReadData(1, "BuildingName"));
            int Mx2 = auto.MouseGetPosX();
            int My2 = auto.MouseGetPosY();
            Mx2 = Mx2 - 120;
            Thread.Sleep(min);
            auto.MouseMove(Mx2, My2);
            auto.MouseClick();
            Thread.Sleep(mid);
            Click<HtmlEdit>(PropertyType.Id, "txtBuildingName");
            auto.Send("{BACKSPACE 20}");
            auto.Send("{DEL 20}");
            Thread.Sleep(min);
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtBuildingName", ExcelDataTable.ReadData(1, "UpdateBuildingName"));

            }catch(Exception e) { }
             Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnAddBuilding");
            Thread.Sleep(mid);
            var data2 = window.ExecuteScript("var data=document.getElementById('spnAddBuildingError').innerHTML;  return  data");
            string successMsg2 = data2.ToString().Trim();

            if (languageResource.Msg_EditBuildingSuccess != successMsg2)
            {
                string screenShotName = "UpdateBuilding_NotSuccess";
                screenShot(screenShotName);
            }
            Assert.AreEqual(languageResource.Msg_EditBuildingSuccess, successMsg2, successMsg2);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void addPlantGates()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "lnkPlantGate");
            Thread.Sleep(min);
            /*Here Checking how Many record is there befor add */

          /*  var totalbefore = window.ExecuteScript("var data=document.getElementById('spnTotalRecords').innerHTML;  return  data");
            string tot = totalbefore.ToString().Trim();
            int totalbeforerecord = Convert.ToInt32(totalbefore);
            Thread.Sleep(min);
          */
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtGateName", ExcelDataTable.ReadData(1, "GateName"));
            }
            catch(Exception e) { }
            try
            {
                EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpBuildings", ExcelDataTable.ReadData(1, "UpdateBuildingName"));
            }catch(Exception e){}
            try
            {
                Click<HtmlCheckBox>(PropertyType.Id, "ContentPlaceHolder1_chkPlantTechnologyList_0");

            }
            catch (Exception e) { }
            try
            {
                Click<HtmlCheckBox>(PropertyType.Id, "ContentPlaceHolder1_chkPlantTechnologyList_3");

            }
            catch (Exception e) { }
            Thread.Sleep(mid);
            /************************************** Going Down *********************/   


            auto.Send("{Down}");
            Thread.Sleep(mid);
            auto.Send("{Down}");
            auto.Send("{Down}");
            Thread.Sleep(mid);
            auto.Send("{Down}");
            auto.Send("{Down}");
            Thread.Sleep(mid);
            auto.Send("{Down}");

            try
            {
                Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnAddGate");
            }catch(Exception e)
            {
                Click<HtmlInputButton>(PropertyType.InnerText, "Add");
            }
            Thread.Sleep(mid);
            var data = window.ExecuteScript("var data=document.getElementById('spnGateError').innerHTML;  return  data");
            string successMsg = data.ToString().Trim();
            if (plantgateresource.Msg_GateAddedSuccess != successMsg)
            {
                string screenShotName = "GateAdded_NotSuccess";
                screenShot(screenShotName);
            }
            Assert.AreEqual(plantgateresource.Msg_GateAddedSuccess, successMsg, successMsg);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
          /*
          var afterTotal = window.ExecuteScript("var data=document.getElementById('spnTotalRecords').innerHTML;  return  data");
            string afterTot = afterTotal.ToString().Trim();
            int afterTotalRecords = Convert.ToInt32(afterTot);
            totalbeforerecord = totalbeforerecord + 1;
            Thread.Sleep(mid);
            if (afterTotalRecords != totalbeforerecord)
            {
                string screenShotName = "afterTotalRecords_NotProper";
                screenShot(screenShotName);
            }
            Assert.AreEqual(afterTotalRecords, totalbeforerecord, "Total Record value is Not Proper");

            Thread.Sleep(min);
            */

            Click<HtmlDiv>(PropertyType.Id,"footer");
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");

            Click<HtmlSpan>(PropertyType.InnerText, ExcelDataTable.ReadData(1, "GateName"));
            int Mx = auto.MouseGetPosX();
            int My = auto.MouseGetPosY();
            Mx = Mx - 85;
            My = My-3;
            Thread.Sleep(max);
            auto.MouseMove(Mx, My);
            auto.MouseClick();
            Thread.Sleep(min);
            /************************** Edit the Gate information**************************/

            Click<HtmlEdit>(PropertyType.Id, "txtGateName");
            auto.Send("{BACKSPACE 10}");
            auto.Send("{DEL 10}");
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtGateName", ExcelDataTable.ReadData(1, "updateGate"));
            }
            catch(Exception e){ }
            try
            {
                Click<HtmlCheckBox>(PropertyType.Id, "ContentPlaceHolder1_chkPlantTechnologyList_4");

            }catch(Exception e) { }
            auto.Send("{Down}");
            Thread.Sleep(mid);
            auto.Send("{Down}");
            auto.Send("{Down}");
            Thread.Sleep(mid);
            auto.Send("{Down}");
            auto.Send("{Down}");
            Thread.Sleep(mid);
            auto.Send("{Down}");
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnAddGate");
            Thread.Sleep(mid);
            var data1 = window.ExecuteScript("var data=document.getElementById('spnGateError').innerHTML;  return  data");
            string successMsg1 = data1.ToString().Trim();
            if (plantgateresource.Msg_GateInfoUpdated != successMsg1)
            {
                string screenShotName = "GateInfo_NotUpdated";
                screenShot(screenShotName);
            }
            Assert.AreEqual(plantgateresource.Msg_GateInfoUpdated, successMsg1, successMsg1);
            Thread.Sleep(min);
            var len = window.ExecuteScript("var data=document.querySelectorAll('i'); return data.length-3;");
            var EditId = window.ExecuteScript("var data=document.querySelectorAll('i'); return data[" + len + "].id;");
            string id = EditId.ToString();

            id = id.Replace("edit", "tdIsGateMaintenance");
            Thread.Sleep(min);
            Click<HtmlDiv>(PropertyType.Id, "footer");
            Click<HtmlCell>(PropertyType.Id, id);

            /******************Delete Plant Building information************************************/

            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "lnkPlantBuilding");
            Thread.Sleep(min);
            Click<HtmlDiv>(PropertyType.Id,"footer");
            auto.Send("{Down}");
            Thread.Sleep(mid);
            auto.Send("{Down}");
            auto.Send("{Down}");
            Thread.Sleep(mid);
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Click<HtmlSpan>(PropertyType.InnerText,ExcelDataTable.ReadData(1, "UpdateBuildingName"));
            int Mx1=auto.MouseGetPosX();
            int My1 = auto.MouseGetPosY();
            Mx1 = Mx1 - 53;
            Thread.Sleep(max);
            auto.MouseMove(Mx1, My1);
            auto.MouseClick();
            Thread.Sleep(min);
            auto.Send("{ENTER}");
            Thread.Sleep(min);
        }
        public void screenShot(string imgName)
        {
            BrowserWindow window = new BrowserWindow();
            string path = ConfigurationSettings.AppSettings["ScreenShot"];
            path = path + @"\\iPAS_ConfigureGates";
            Directory.CreateDirectory(path);
            try
            {
                window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
                Image image = window.CaptureImage();
                image.Save(path + "\\" + imgName + ".jpeg", ImageFormat.Jpeg);
                image.Dispose();
            }
            catch (Exception e) { }
            Console.WriteLine("Screen Shot is Avaliable in " + path + "\t" + "Folder");
        }
        public void PathEnterText<T>(PropertyType type, string propertyvalue, string text) where T : WinEdit
        {
            WinEdit genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            genericControl.FilterProperties[WinEdit.PropertyNames.Name] = propertyvalue;
            AutoItX3 auto = new AutoItX3();
            auto.WinActivate("Choose File to Upload");
            auto.Send(text);
            auto.Send("{ENTER}");
            Thread.Sleep(1000);
        }
        public void WindowButtonClick<T>(PropertyType type, string propertyvalue) where T : WinControl
        {
            WinControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Name)
                genericControl.SearchProperties[WinControl.PropertyNames.Name] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void Click<T>(PropertyType type, string propertyvalue) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });

            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;
            else if (type == PropertyType.InnerText)
            {
                genericControl.SearchProperties[HtmlControl.PropertyNames.InnerText] = propertyvalue;
            }
            else if (type == PropertyType.TagInstance)
                genericControl.FilterProperties[HtmlControl.PropertyNames.TagInstance] = propertyvalue;
            else if (type == PropertyType.Class)
                genericControl.FilterProperties[HtmlControl.PropertyNames.Class] = propertyvalue;


            Mouse.Click(genericControl);
        }
        public void EnterText<T>(PropertyType type, string propertyvalue, string text) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;
            

            Keyboard.SendKeys(genericControl, text);

        }
        private BrowserWindow mparentwindow { get; set; }
        public enum PropertyType
        {
            Id,
            Name,
            InnerText,
            TagInstance,
            Class
        }
        public BrowserWindow TopParentWindow()
        {

            BrowserWindow window = new BrowserWindow();
            window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
            return window;
        }
        public BrowserWindow ParentWindow
        {
            get
            {
                if (this.mparentwindow == null)
                {
                    this.mparentwindow = TopParentWindow();
                }
                return this.mparentwindow;
            }
        }
    }
}
