﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Text;
using System.Threading.Tasks;

namespace iPAS_DefinePackageTypes
{
    class LanguageResourceTemplate
    {
        static CultureInfo ci = null;
        static ResourceManager rm = null;
        static string resMsg_PackageNameAddedSuccessfully = string.Empty;
        public string Msg_PackageNameAddedSuccessfully
        {
            get { return resMsg_PackageNameAddedSuccessfully; }
            set { resMsg_PackageNameAddedSuccessfully = value; }
        }

        static string resMsg_packageNameAlreadyExist = string.Empty;
        public string Msg_packageNameAlreadyExist
        {
            get { return resMsg_packageNameAlreadyExist; }
            set { resMsg_packageNameAlreadyExist = value; }
        }
        static string resMsg_PleaseEnterPackageName = string.Empty;
        public string Msg_PleaseEnterPackageName
        {
            get { return resMsg_PleaseEnterPackageName; }
            set { resMsg_PleaseEnterPackageName = value; }
        }
        static string resMsg_SuccessfullyUpdatedPackageInformation = string.Empty;
        public string Msg_SuccessfullyUpdatedPackageInformation
        {
            get { return resMsg_SuccessfullyUpdatedPackageInformation; }
            set { resMsg_SuccessfullyUpdatedPackageInformation = value; }
        }
      

        public static void messageResource(string languageCode)
        {
            if (languageCode == "zh-CN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_DefinePackageTypes.resources.PackageTypeResourcesCN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "th-TH")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_DefinePackageTypes.resources.PackageTypeResourcesTH", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "vi-VN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_DefinePackageTypes.resources.PackageTypeResourcesVN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "ko-KR")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_DefinePackageTypes.resources.PackageTypeResourcesKR", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "ja-JP")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_DefinePackageTypes.resources.PackageTypeResourcesJP", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "id-ID")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_DefinePackageTypes.resources.PackageTypeResourcesID", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_DefinePackageTypes.resources.PackageTypeResourcesEN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
        }
        public static void messageInitialize()
        {
            resMsg_PackageNameAddedSuccessfully = rm.GetString("resMsg_PackageNameAddedSuccessfully", ci).Trim();
            resMsg_packageNameAlreadyExist = rm.GetString("resMsg_packageNameAlreadyExist", ci).Trim();
            resMsg_PleaseEnterPackageName = rm.GetString("resMsg_PleaseEnterPackageName", ci).Trim();
            resMsg_SuccessfullyUpdatedPackageInformation = rm.GetString("resMsg_SuccessfullyUpdatedPackageInformation", ci).Trim();
        }
    }
}
