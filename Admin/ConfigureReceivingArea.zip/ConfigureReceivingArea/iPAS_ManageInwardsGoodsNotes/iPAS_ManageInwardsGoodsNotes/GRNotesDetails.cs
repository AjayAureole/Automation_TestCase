﻿using AutoItX3Lib;
using DataDrivenTesting;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace iPAS_ManageInwardsGoodsNotes
{
    class GRNotesDetails
    {
        string minsleep = ConfigurationSettings.AppSettings["min"];
        string midsleep = ConfigurationSettings.AppSettings["mid"];
        string maxsleep = ConfigurationSettings.AppSettings["max"];
        public void GRInfoNote()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "lnkAdmin");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkGRIndex");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkGRNotes");
            auto.MouseClick();
            Thread.Sleep(mid);
            auto.Send("F5");
            Thread.Sleep(max);
            /************************Clicking on the Download and Upload Button*****************/
            try
            {

                Click<HtmlSpan>(PropertyType.InnerText, "Receiving Notes");
            }
            catch (Exception e)
            {
                Click<HtmlSpan>(PropertyType.InnerText, "Receiving Notes");
            }
            Thread.Sleep(min);
            int xCoodinate = auto.MouseGetPosX();
            int yCoodinate = auto.MouseGetPosY();
            xCoodinate = xCoodinate - 300;
            auto.MouseMove(xCoodinate, yCoodinate);
            yCoodinate = yCoodinate + 40;
            auto.MouseMove(xCoodinate, yCoodinate);
            auto.MouseClick();

            Click<HtmlCustom>(PropertyType.Id, "ContentPlaceHolder1_btnUploadData");
            Click<HtmlFileInput>(PropertyType.Id, "ContentPlaceHolder1_uploadFile");
            PathEnterText<WinEdit>(PropertyType.Name, "File name:", ExcelDataTable.ReadData(1, "filePath"));
            Thread.Sleep(max*5);

            /****************Here check Validate File is Uploaded or not******************/
            var data = window.ExecuteScript("var data=document.getElementById('lblUploadError').innerHTML; return data;");
            string msg = data.ToString();
            if (msg!="")
            {
                string screenShotName = "File_NotUploaded";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", msg, msg);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }

        public void searchAndUpdate()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);

        //    Click<HtmlRadioButton>(PropertyType.Id, "rdoIDHID");
            try {
                EnterText<HtmlEdit>(PropertyType.Id, "txtMaterialSearch", ExcelDataTable.ReadData(1, "Material_No"));

                }catch(Exception e) { }
            Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearch");
            Thread.Sleep(mid);
            /*****************Here check Material Number is Enter Or not***/
            var data1 = window.ExecuteScript("var data=document.getElementById('spnSearchError').innerHTML; return data;");
            string msg1 = data1.ToString().Trim();
            bool b = msg1.Equals("Enter search criteria");
            if (b)
            {
                string screenShotName = "Enter_SearchCriteria";
                screenShot(screenShotName);
            }
            Assert.IsFalse(b, msg1);
            Thread.Sleep(mid);

            /************Here Validate GR Note or Put Away Note is Uploaded  or Not******************************/
            
           //string GRNote= compareExcelDataToNote(ExcelDataTable.ReadData(1, "GR Notes"));
          // string putAwayNote = compareExcelDataToNote(ExcelDataTable.ReadData(1, "Put Away Notes"));
           var data = window.ExecuteScript("var data=document.getElementById('ctl01_spnGRNotes').innerHTML; return data;");
           string msg = data.ToString().Trim();
            if (msg.Equals(""))
            {
                msg = null;
                if (msg==null)
                {
                    string screenShotName = "PleaseFillGR_NoteInExcel";
                    screenShot(screenShotName);
                }
                Assert.IsNotNull(msg, "Please Fill GR Note in Excel");
            }
            var data3 = window.ExecuteScript("var data=document.getElementById('ctl01_spnPutAwayNotes').innerHTML; return data;");
            string msg3 = data3.ToString().Trim();
            if (msg3.Equals(""))
            {
                msg3 = null;
                if (msg3 == null)
                {
                    string screenShotName = "Please_FillPutAway_NoteInExcelData";
                    screenShot(screenShotName);
                }
                Assert.IsNotNull(msg3, "Please Fill Put Away Note in Excel Data");
            }
            Thread.Sleep(min);

            /********************************Update the Record*****************************************/
            //var EditId1 = window.ExecuteScript("var data=document.querySelectorAll('i'); return data;");
            //var EditId = window.ExecuteScript("var data=document.querySelectorAll('i'); return data[16].id;");
            //string id = EditId.ToString();
            //id = "'" + id + "'";
            //var xCoodinate = window.ExecuteScript("var data1=document.getElementById(" + id + "); var rect = data1.getBoundingClientRect(); return  rect.left");
            //var yCoodinate = window.ExecuteScript("var data1=document.getElementById(" + id + "); var rect = data1.getBoundingClientRect(); return  rect.top");

            //string x = xCoodinate.ToString();
            //string y = yCoodinate.ToString();
            //double x1 = Convert.ToDouble(x);
            //double y1 = Convert.ToDouble(y);
            //int Xco = Convert.ToInt32(x1);
            //int Yco = Convert.ToInt32(y1);
            ////Make sure Browser Window is Maximize
            //// Xco = Xco;
            //Yco = Yco + 45;
            //auto.MouseMove(Xco, Yco);
            //auto.MouseClick();
            //Thread.Sleep(min);
            //auto.Send("{F5}");
            //Thread.Sleep(mid);


            mparentwindow = null;
            Click<HtmlSpan>(PropertyType.InnerText, ExcelDataTable.ReadData(1, "Material_No"));
            Thread.Sleep(min);
            int xCoodinate = auto.MouseGetPosX();
            int yCoodinate = auto.MouseGetPosY();
            xCoodinate = xCoodinate - 75;
            auto.MouseMove(xCoodinate, yCoodinate);
            Thread.Sleep(min);
            auto.MouseClick();
            Thread.Sleep(mid);
            try
            {
                auto.Send("{F5}");
                Thread.Sleep(mid);
                Click<HtmlTextArea>(PropertyType.Id, "ContentPlaceHolder1_txtGRNotes");
                auto.Send("{BACKSPACE 30}");//Existing Data Deletion
                auto.Send("{DEL 30}");
            }
            catch (Exception) { }
            try
            {

                Click<HtmlTextArea>(PropertyType.Id, "ContentPlaceHolder1_txtPutAwayNote");
                auto.Send("{BACKSPACE 30}");//Existing Data Deletion
                auto.Send("{DEL 30}");
            }
            catch (Exception) { }
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnSave");
            Thread.Sleep(min);
            auto.Send("F5");
            Thread.Sleep(mid);
        }
        public void validateEmpty()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            auto.Send("{F5}");
            Thread.Sleep(mid);

          //  Click<HtmlRadioButton>(PropertyType.Id, "rdoIDHID");
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtMaterialSearch", ExcelDataTable.ReadData(1, "Material_No"));

            }
            catch (Exception e) { }
            Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearch");
            Thread.Sleep(mid);
            /*****************Here check Material Number is Enter Or not***/
            var data1 = window.ExecuteScript("var data=document.getElementById('spnSearchError').innerHTML; return data;");
            string msg1 = data1.ToString().Trim();
            bool b = msg1.Equals("Enter search criteria");
            if (b)
            {
                string screenShotName = "Enter_SearchCriteria";
                screenShot(screenShotName);
            }
            Assert.IsFalse(b, msg1);
            Thread.Sleep(mid);
            string id = "'ctl01_spnGRNotes'";
            bool b1 = validate(id);
            if (!b1)
            {
                string screenShotName = "GRNoteIs_NotUpdated";
                screenShot(screenShotName);
            }
            Assert.IsTrue(b1, "GRNote is Not Updated");
            string id1 = "'ctl01_spnGRNotes'";
            bool b2 = validate(id1);
            if (!b2)
            {
                string screenShotName = "PutAwayIs_NotUpdated";
                screenShot(screenShotName);
            }
            Assert.IsTrue(b1, "Put Away is Not Updated");
            Thread.Sleep(max);
            try
            {
                Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnShowAll");
            }catch(Exception e) { }
            Thread.Sleep(max);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }

        public void downloadTemplate()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");//673574
            Thread.Sleep(mid);
            /************************Clicking on the Download and Upload Button*****************/
            try
            {

                Click<HtmlSpan>(PropertyType.InnerText, "Receiving Notes");
            }
            catch (Exception e)
            {
                Click<HtmlSpan>(PropertyType.InnerText, "Receiving Notes");
            }
            Thread.Sleep(min);
            int xCoodinate = auto.MouseGetPosX();
            int yCoodinate = auto.MouseGetPosY();
            xCoodinate = xCoodinate - 300;
            auto.MouseMove(xCoodinate, yCoodinate);
            yCoodinate = yCoodinate + 40;
            auto.MouseMove(xCoodinate, yCoodinate);
            auto.MouseClick();

            Click<HtmlHyperlink>(PropertyType.Id, "btnDownloadTemplate");
            Thread.Sleep(max * 10);
            Click<HtmlDiv>(PropertyType.Id, "footer");
            try {
                WindowButtonClick<WinToolBar>(PropertyType.Name, "Notification");
                WindowButtonClick<WinButton>(PropertyType.Name, "Open");
            }catch(Exception e) { }
            mparentwindow = null;
            Thread.Sleep(max * 17);
            auto.WinClose("Microsoft Excel");
            auto.WinClose("Excel");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void downloadAllGRNote()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");//673574
            Thread.Sleep(mid);
            /************************Clicking on the Download and Upload Button*****************/
            try
            {

                Click<HtmlSpan>(PropertyType.InnerText, "Receiving Notes");
            }
            catch (Exception e)
            {
                Click<HtmlSpan>(PropertyType.InnerText, "Receiving Notes");
            }
            Thread.Sleep(min);
            int xCoodinate = auto.MouseGetPosX();
            int yCoodinate = auto.MouseGetPosY();
            xCoodinate = xCoodinate - 300;
            auto.MouseMove(xCoodinate, yCoodinate);
            yCoodinate = yCoodinate + 40;
            auto.MouseMove(xCoodinate, yCoodinate);
            auto.MouseClick();
            Click<HtmlCustom>(PropertyType.Id, "ContentPlaceHolder1_btnDownloadSampleData");
            Thread.Sleep(max * 10);
            Click<HtmlDiv>(PropertyType.Id, "footer");
            try {
                WindowButtonClick<WinToolBar>(PropertyType.Name, "Notification");
                WindowButtonClick<WinButton>(PropertyType.Name, "Open");
            }catch(Exception e) { }
            mparentwindow = null;
            Thread.Sleep(max * 17);
            auto.WinClose("Microsoft Excel");
            auto.WinClose("Excel");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void pageNavigator()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlDiv>(PropertyType.Id, "footer");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");
            Thread.Sleep(min);
            auto.Send("{Down}");

            //try
            //{
            //    var pageCount = window.ExecuteScript("var data=document.getElementById('ctl01_divPager').getElementsByTagName('a');  return  data.length");
            //    string len = pageCount.ToString();
            //    int length = Convert.ToInt32(len);
            //    for (int i = 1; i <= length; i++)
            //    {
            //        string tagId = "ctl01_hrefNum" + i;
            //        Thread.Sleep(mid);
            //        if (i == 7)
            Click<HtmlHyperlink>(PropertyType.Id, "ctl01_hrefLast");
            Thread.Sleep(max);
            validation();
            Thread.Sleep(min);
            //    tagId = "";
            //}
            //}
            //catch (Exception e) { }

        }
        public void validation()
        {
            BrowserWindow window = new BrowserWindow();
            Thread.Sleep(1000);
            var len = window.ExecuteScript("var data=document.getElementById('ContentPlaceHolder1_tblGRNotesBody').getElementsByTagName('td');  return  data.length");
            string length = len.ToString().Trim();
            int Data = Convert.ToInt32(length);
            bool flag = true;
            if (Data == 0)
                flag = false;

            string error = "Data is Not there On Last Navigate page";
            if (!flag)
            {
                string screenShotName = "DataIs_NotThere";
                screenShot(screenShotName);
            }
            Assert.IsTrue(flag, error);
        }
        public  bool validate(string id)
        {
            BrowserWindow window = new BrowserWindow();
            var data = window.ExecuteScript("var data=document.getElementById("+ id +").innerHTML; return data;");
            string msg = data.ToString().Trim();
            return (msg.Equals(""));

        }
        public void screenShot(string imgName)
        {
            BrowserWindow window = new BrowserWindow();
            string path = ConfigurationSettings.AppSettings["ScreenShot"];
            path = path + @"\\iPAS_ManageInwardsGoodsNotes";
            Directory.CreateDirectory(path);
            try
            {
                window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
                Image image = window.CaptureImage();
                image.Save(path + "\\" + imgName + ".jpeg", ImageFormat.Jpeg);
                image.Dispose();
            }
            catch (Exception e) { }
            Console.WriteLine("Screen Shot is Avaliable in " + path + "\t" + "Folder");
        }
        public void WindowButtonClick<T>(PropertyType type, string propertyvalue) where T : WinControl
        {
            WinControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Name)
                genericControl.SearchProperties[WinControl.PropertyNames.Name] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void PathEnterText<T>(PropertyType type, string propertyvalue, string text) where T : WinEdit
        {
            WinEdit genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            genericControl.FilterProperties[WinEdit.PropertyNames.Name] = propertyvalue;
            AutoItX3 auto = new AutoItX3();
            auto.WinActivate("Choose File to Upload");
            auto.Send(text);
            auto.Send("{ENTER}");
            Thread.Sleep(1000);
        }

        public void Click<T>(PropertyType type, string propertyvalue) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });

            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;
            else if (type == PropertyType.InnerText)
            {
                genericControl.SearchProperties[HtmlControl.PropertyNames.InnerText] = propertyvalue;
            }
            else if (type == PropertyType.TagInstance)
                genericControl.FilterProperties[HtmlControl.PropertyNames.TagInstance] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void EnterText<T>(PropertyType type, string propertyvalue, string text) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;

            Keyboard.SendKeys(genericControl, text);

        }
        private BrowserWindow mparentwindow { get; set; }
        public enum PropertyType
        {
            Id,
            Name,
            InnerText,
            TagInstance
        }
        public BrowserWindow TopParentWindow()
        {

            BrowserWindow window = new BrowserWindow();
            window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
            return window;
        }
        public BrowserWindow ParentWindow
        {
            get
            {
                if (this.mparentwindow == null)
                {
                    this.mparentwindow = TopParentWindow();
                }
                return this.mparentwindow;
            }
        }
    }
}
