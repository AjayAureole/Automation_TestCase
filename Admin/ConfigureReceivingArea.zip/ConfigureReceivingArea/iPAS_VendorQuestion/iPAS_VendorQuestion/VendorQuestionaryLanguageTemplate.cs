﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Text;
using System.Threading.Tasks;

namespace iPAS_VendorQuestion
{
    class VendorQuestionaryLanguageTemplate
    {
        static CultureInfo ci = null;
        static ResourceManager rm = null;
        static string resMsg_QuestionaryAddedSuccessfully = string.Empty;
        public string Msg_QuestionaryAddedSuccessfully
        {
            get { return resMsg_QuestionaryAddedSuccessfully; }
            set { resMsg_QuestionaryAddedSuccessfully = value; }
        }

        static string resMsg_SuccessfullyQuestionUpdated = string.Empty;
        public string Msg_SuccessfullyQuestionUpdated
        {
            get { return resMsg_SuccessfullyQuestionUpdated; }
            set { resMsg_SuccessfullyQuestionUpdated = value; }
        }      

        public static void messageResource(string languageCode)
        {
            if (languageCode == "zh-CN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_VendorQuestion.resources.VendorQuestionaryCN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "th-TH")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_VendorQuestion.resources.VendorQuestionaryTH", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "vi-VN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_VendorQuestion.resources.VendorQuestionaryVN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "ko-KR")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_VendorQuestion.resources.VendorQuestionaryKR", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "ja-JP")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_VendorQuestion.resources.VendorQuestionaryJP", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "id-ID")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_VendorQuestion.resources.VendorQuestionaryID", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_VendorQuestion.resources.VendorQuestionaryEN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
        }
        public static void messageInitialize()
        {
            resMsg_QuestionaryAddedSuccessfully = rm.GetString("resMsg_QuestionaryAddedSuccessfully", ci).Trim();
            resMsg_SuccessfullyQuestionUpdated = rm.GetString("resMsg_SuccessfullyQuestionUpdated", ci).Trim();
        }
    }
}
