﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Text;
using System.Threading.Tasks;

namespace iPAS_PurchasingGroups
{
    class LanguageResouceTemplate
    {
        static CultureInfo ci = null;
        static ResourceManager rm = null;
        static string resMsg_NoRecordsFound = string.Empty;
        public string Msg_NoRecordsFound
        {
            get { return resMsg_NoRecordsFound; }
            set { resMsg_NoRecordsFound = value; }
        }

        static string resMsg_PleaseEnterPOGroup = string.Empty;
        public string Msg_PleaseEnterPOGroup
        {
            get { return resMsg_PleaseEnterPOGroup; }
            set { resMsg_PleaseEnterPOGroup = value; }
        }
        static string resMsg_PleaseSelectOneTechnology = string.Empty;
        public string Msg_PleaseSelectOneTechnology
        {
            get { return resMsg_PleaseSelectOneTechnology; }
            set { resMsg_PleaseSelectOneTechnology = value; }
        }

        static string resMsg_POGroupAdded = string.Empty;
        public string Msg_POGroupAdded
        {
            get { return resMsg_POGroupAdded; }
            set { resMsg_POGroupAdded = value; }
        }
        static string resMsg_POGroupAlreadyExists = string.Empty;
        public string Msg_POGroupAlreadyExists
        {
            get { return resMsg_POGroupAlreadyExists; }
            set { resMsg_POGroupAlreadyExists = value; }
        }
        static string resMsg_POGroupUpdatedSuccessfully = string.Empty;
        public string Msg_POGroupUpdatedSuccessfully
        {
            get { return resMsg_POGroupUpdatedSuccessfully; }
            set { resMsg_POGroupUpdatedSuccessfully = value; }
        }



        public static void messageResource(string languageCode)
        {
            if (languageCode == "zh-CN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_PurchasingGroups.resources.POGroupResourceCN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "th-TH")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_PurchasingGroups.resources.POGroupResourceTH", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "vi-VN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_PurchasingGroups.resources.POGroupResourceVN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "ko-KR")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_PurchasingGroups.resources.POGroupResourceKR", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "ja-JP")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_PurchasingGroups.resources.POGroupResourceJP", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "id-ID")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_PurchasingGroups.resources.POGroupResourceID", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_PurchasingGroups.resources.POGroupResourceEN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
        }
        public static void messageInitialize()
        {
            resMsg_NoRecordsFound = rm.GetString("resMsg_NoRecordsFound", ci).Trim();
            resMsg_PleaseEnterPOGroup = rm.GetString("resMsg_PleaseEnterPOGroup", ci).Trim();
            resMsg_PleaseSelectOneTechnology = rm.GetString("resMsg_PleaseSelectOneTechnology", ci).Trim();
            resMsg_POGroupAdded = rm.GetString("resMsg_POGroupAdded", ci).Trim();
            resMsg_POGroupAlreadyExists = rm.GetString("resMsg_POGroupAlreadyExists", ci).Trim();
            resMsg_POGroupUpdatedSuccessfully = rm.GetString("resMsg_POGroupUpdatedSuccessfully", ci).Trim();
        }
    }
}
