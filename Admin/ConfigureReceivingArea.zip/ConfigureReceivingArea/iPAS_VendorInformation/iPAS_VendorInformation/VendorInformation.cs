﻿using AutoItX3Lib;
using DataDrivenTesting;
using iPAS_VendorInformation;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ConfigureReceivingArea
{
    class VendorInformation
    {
        LanguageResourceTemplate languageResource = new LanguageResourceTemplate();

        string minsleep = ConfigurationSettings.AppSettings["min"];
        string midsleep = ConfigurationSettings.AppSettings["mid"];
        string maxsleep = ConfigurationSettings.AppSettings["max"];
        public void VendorInfoUpload()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "lnkAdmin");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkGRIndex");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkVendorInfo");
            Thread.Sleep(mid);
            auto.MouseClick();
            auto.Send("F5");
            Thread.Sleep(max);
            /*Here Checking how Many record is there befor add */

            //var totalbefore = window.ExecuteScript("var data=document.getElementById('spnTotalRecords').innerHTML;  return  data");
            //string tot = totalbefore.ToString().Trim();
            //int totalbeforerecord = Convert.ToInt32(totalbefore);

            /***************************Clicking on the Download and Upload Button*********/
            try
            {

                Click<HtmlSpan>(PropertyType.InnerText, "Vendor Information");
            }
            catch (Exception e)
            {
                Click<HtmlSpan>(PropertyType.InnerText, "Vendor Information");
            }
            Thread.Sleep(min);
            int xCoodinate = auto.MouseGetPosX();
            int yCoodinate = auto.MouseGetPosY();
            xCoodinate = xCoodinate - 250;
            auto.MouseMove(xCoodinate, yCoodinate);
            yCoodinate = yCoodinate + 40;
            auto.MouseMove(xCoodinate, yCoodinate);
            auto.MouseClick();


            /*************************File Uploading Excel file*************************************/
            Click<HtmlButton>(PropertyType.Id, "btnUploadVendor");
            Thread.Sleep(min);
            HtmlFileInput<HtmlFileInput>(PropertyType.Id, "ContentPlaceHolder1_uploadFile", ExcelDataTable.ReadData(1, "FilePath"));
            Thread.Sleep(max*10);
            /****************Here check Validate File is Uploaded or not******************/
            var data = window.ExecuteScript("var data=document.getElementById('lblUploadError').innerHTML; return data;");
            string msg = data.ToString();
            if (msg!="")
            {
                string screenShotName = "FileUploadingProblem";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", msg, msg);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            //var afterTotal = window.ExecuteScript("var data=document.getElementById('spnTotalRecords').innerHTML;  return  data");
            //string afterTot = afterTotal.ToString().Trim();
            //int afterTotalRecords = Convert.ToInt32(afterTot);
            //totalbeforerecord = totalbeforerecord + 1;
            //Thread.Sleep(mid);
            //if (afterTotalRecords != totalbeforerecord)
            //{
            //    string screenShotName = "afterTotalRecords_NotProper";
            //    screenShot(screenShotName);
            //}
            //Assert.AreEqual(afterTotalRecords, totalbeforerecord, "Total Record value is Not Proper");

            //Thread.Sleep(min);
            //Click<HtmlDiv>(PropertyType.Id, "footer");
            //WindowButtonClick<WinToolBar>(PropertyType.Name, "Notification");
            //WindowButtonClick<WinButton>(PropertyType.Name, "Open");

            //auto.Send("{F5}");
            //Thread.Sleep(mid);

            /********************Delete Upload vendor information******************/
            /* try
             {
                 var pageCount = window.ExecuteScript("var data=document.getElementById('ucPager_divPager').getElementsByTagName('a');  return  data.length");
                 string len = pageCount.ToString();
                 int length = Convert.ToInt32(len);
                 for (int i = 1; i <= length; i++)
                 {
                     string tagId = "";
                     try {
                         tagId = "ucPager_hrefNum" + i;
                         Click<HtmlDiv>(PropertyType.Id, "footer");
                         Thread.Sleep(mid);
                         Click<HtmlHyperlink>(PropertyType.Id, tagId);
                         Thread.Sleep(mid);
                         Click<HtmlDiv>(PropertyType.Id, "footer");
                         Thread.Sleep(mid);
                         Click<HtmlCell>(PropertyType.InnerText, ExcelDataTable.ReadData(1, "VendorCodeuseFile"));
                         Thread.Sleep(mid);
                         int Mx2 = auto.MouseGetPosX();
                         int My2 = auto.MouseGetPosY();
                         Mx2 = Mx2 - 80;
                         Thread.Sleep(max);
                         auto.MouseMove(Mx2, My2);
                         auto.MouseClick();
                         Thread.Sleep(min);
                         auto.Send("{ENTER}");
                         tagId = "";
                     }catch(Exception e) {
                     }
                 }
             }
             catch (Exception e) {}
             */

            EnterText<HtmlEdit>(PropertyType.Id, "txtVendorCodeOrName", ExcelDataTable.ReadData(1, "VendorCodeuseFile"));
            Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearch");
            Thread.Sleep(min);

            Click<HtmlCell>(PropertyType.InnerText, ExcelDataTable.ReadData(1, "VendorCodeuseFile"));
            Thread.Sleep(mid);
            int Mx2 = auto.MouseGetPosX();
            int My2 = auto.MouseGetPosY();
            Mx2 = Mx2 - 85;
            Thread.Sleep(max);
            auto.MouseMove(Mx2, My2);
            auto.MouseClick();
            Thread.Sleep(min);
            auto.Send("{ENTER}");

            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void manuallyAdd()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            bool b1 = false;

            /***************************Add vendor information using Enter Data******************************/
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtVendorCode", ExcelDataTable.ReadData(1, "VendorCode"));
            }catch(Exception e) { }
            try {
                EnterText<HtmlEdit>(PropertyType.Id, "txtVendorName", ExcelDataTable.ReadData(1, "VendorName"));
            } catch (Exception e) { }
            try {
                EnterText<HtmlEdit>(PropertyType.Id, "txtVendorDays", ExcelDataTable.ReadData(1, "VendorDays"));
            }catch(Exception e) { }
            try { 
                EnterText<HtmlEdit>(PropertyType.Id, "txtVendorEmailId", ExcelDataTable.ReadData(1, "VendorEmailId"));
            }
            catch (Exception e){}
            Thread.Sleep(min);
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnAddVendor");
            Thread.Sleep(mid);
            var data = window.ExecuteScript("var data=document.getElementById('spnAddVendorError').innerHTML;  return  data");
            string successMsg = data.ToString().Trim();
            if (languageResource.Msg_AddVendorSuccess != successMsg)
            {
                string screenShotName = "AddVendor_NotSuccess";
                screenShot(screenShotName);
            }
            Assert.AreEqual(languageResource.Msg_AddVendorSuccess, successMsg, successMsg);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            int i = 1;
            /***********************updating the Vendor information************************/
            //try
            //{
            //var pageCount = window.ExecuteScript("var data=document.getElementById('ucPager_divPager').getElementsByTagName('a');  return  data.length");
            //string len = pageCount.ToString();
            //int length = Convert.ToInt32(len);
            //for (i = 1; i <= length; i++)
            //{
            //    string tagId = "";
            //    try
            //    {
            //        Click<HtmlDiv>(PropertyType.Id, "footer");
            //        Thread.Sleep(min);
            //        tagId = "ucPager_hrefNum" + i;
            //        Thread.Sleep(min);
            //        Click<HtmlHyperlink>(PropertyType.Id, tagId);
            //        Thread.Sleep(mid);
            //        Click<HtmlDiv>(PropertyType.Id, "footer");
            //        Thread.Sleep(mid);
            //        string str = ExcelDataTable.ReadData(1, "VendorCode");

                      EnterText<HtmlEdit>(PropertyType.Id, "txtVendorCodeOrName", ExcelDataTable.ReadData(1, "VendorCode"));
                      Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearch");
                      Thread.Sleep(min);

                        Click<HtmlCell>(PropertyType.InnerText, ExcelDataTable.ReadData(1, "VendorCode"));
                        int Mx = auto.MouseGetPosX();
                        int My = auto.MouseGetPosY();
                        Mx = Mx - 110;
                        Thread.Sleep(max);
                        auto.MouseMove(Mx, My);
                        auto.MouseClick();
                        Thread.Sleep(mid);
                        try
                        {
                            Click<HtmlEdit>(PropertyType.Id, "txtVendorName");
                            auto.Send("{BACKSPACE 20}");
                            auto.Send("{DEL 20}");
                            EnterText<HtmlEdit>(PropertyType.Id, "txtVendorName", ExcelDataTable.ReadData(1, "UpdateVendorName"));

                        }
                        catch (Exception e) { }
                        try {
                            Click<HtmlEdit>(PropertyType.Id, "txtVendorDays");//Clear the text Box
                            auto.Send("{BACKSPACE 20}");
                            auto.Send("{DEL 20}");
                            EnterText<HtmlEdit>(PropertyType.Id, "txtVendorDays", ExcelDataTable.ReadData(1, "UpdateVendorDays"));

                        }
                        catch (Exception e) { }
                      
                        try {
                            Click<HtmlEdit>(PropertyType.Id, "txtVendorEmailId");//Clear the text Box
                            auto.Send("{BACKSPACE 20}");
                            auto.Send("{DEL 20}");
                            EnterText<HtmlEdit>(PropertyType.Id, "txtVendorEmailId", ExcelDataTable.ReadData(1, "UpdateVendorEmailId"));
                        }
                        catch (Exception e) {  }
                        Thread.Sleep(min);
                        Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnAddVendor");
                        Thread.Sleep(mid);
                        var data1 = window.ExecuteScript("var data=document.getElementById('spnAddVendorError').innerHTML;  return  data");
                        string successMsg1 = data1.ToString().Trim();
                        if (languageResource.Msg_VendorUpdateSuccess != successMsg1)
                        {
                            string screenShotName = "VendorUpdate_NotSuccess";
                            screenShot(screenShotName);
                        }
                        Assert.AreEqual(languageResource.Msg_VendorUpdateSuccess, successMsg1, successMsg1);
                       
                        //Thread.Sleep(min);
                        //auto.Send("{F5}");
                        //Thread.Sleep(mid);
                        //tagId = "";
                        //b1 = true;
                  //  }
                //    catch (Exception e) {
                //        Assert.IsTrue(b1,e.Message);

                //    }
                //}
           // }
            //catch (Exception e) {
            //    Assert.IsTrue(b1, e.Message);
            //}
            

            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);

            /***************************Clicking on the Download and Upload Button*********/
            try
            {

                Click<HtmlSpan>(PropertyType.InnerText, "Vendor Information");
            }
            catch (Exception e)
            {
                Click<HtmlSpan>(PropertyType.InnerText, "Vendor Information");
            }
            Thread.Sleep(min);
            int xCoodinate = auto.MouseGetPosX();
            int yCoodinate = auto.MouseGetPosY();
            xCoodinate = xCoodinate - 250;
            auto.MouseMove(xCoodinate, yCoodinate);
            yCoodinate = yCoodinate + 40;
            auto.MouseMove(xCoodinate, yCoodinate);
            auto.MouseClick();

            /********************Perform The Downloading********************/
            Click<HtmlHyperlink>(PropertyType.Id, "downLoadTemplateLink");
            Thread.Sleep(mid*5);
            try {
                WindowButtonClick<WinToolBar>(PropertyType.Name, "Notification");
                WindowButtonClick<WinButton>(PropertyType.Name, "Open");
            }catch(Exception e) { }
            mparentwindow = null;
            Thread.Sleep(max * 15);
            auto.WinClose("Microsoft Excel");
            auto.WinClose("Excel");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);

            /***************************Clicking on the Download and Upload Button*********/
            try
            {

                Click<HtmlSpan>(PropertyType.InnerText, "Vendor Information");
            }
            catch (Exception e)
            {
                Click<HtmlSpan>(PropertyType.InnerText, "Vendor Information");
            }
            Thread.Sleep(min);
            int xCoodinate1 = auto.MouseGetPosX();
            int yCoodinate1 = auto.MouseGetPosY();
            xCoodinate1 = xCoodinate1 - 250;
            auto.MouseMove(xCoodinate1, yCoodinate1);
            yCoodinate1 = yCoodinate1 + 40;
            auto.MouseMove(xCoodinate1, yCoodinate1);
            auto.MouseClick();


            Click<HtmlCustom>(PropertyType.Id, "ContentPlaceHolder1_btnDownloadAllVendors");
            Thread.Sleep(max * 5);
            Click<HtmlDiv>(PropertyType.Id, "footer");
            Thread.Sleep(max*6);
            try {
                WindowButtonClick<WinToolBar>(PropertyType.Name, "Notification");
                WindowButtonClick<WinButton>(PropertyType.Name, "Open");
            }catch(Exception e) { }
            mparentwindow = null;
            Thread.Sleep(max * 15);
            auto.WinClose("Microsoft Excel");
            auto.WinClose("Excel");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
           // int i = 1;
            /**********************Delete the Vendor information****************************/
          


            EnterText<HtmlEdit>(PropertyType.Id, "txtVendorCodeOrName", ExcelDataTable.ReadData(1, "VendorCode"));
            Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearch");
            Thread.Sleep(min);

            Click<HtmlCell>(PropertyType.InnerText, ExcelDataTable.ReadData(1, "VendorCode"));
            Thread.Sleep(mid);
            int Mx2 = auto.MouseGetPosX();
            int My2 = auto.MouseGetPosY();
            Mx2 = Mx2 - 85;
            Thread.Sleep(max);
            auto.MouseMove(Mx2, My2);
            auto.MouseClick();
            Thread.Sleep(min);
            auto.Send("{ENTER}");

            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);








        }

        public void pageNavigator()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlDiv>(PropertyType.Id, "footer");
            int i = 1;
            try
            {
                var pageCount = window.ExecuteScript("var data=document.getElementById('ucPager_divPager').getElementsByTagName('a');  return  data.length");
                string len = pageCount.ToString();
                int length = Convert.ToInt32(len);
                for (i = 1; i <= length-2; i++)
                {
                    string tagId = "ucPager_hrefNum" + i;
                    Click<HtmlDiv>(PropertyType.Id, "footer");
                    Thread.Sleep(min);
                    Click<HtmlHyperlink>(PropertyType.Id, tagId);
                    Thread.Sleep(min);
                    validation(i);
                    Thread.Sleep(min);
                    tagId = "";
                }
            }
            catch (Exception e)
            {

                string error = "Data is Not there On Navigate page No:" + i;
                Assert.IsTrue(false, error);
            }
            Thread.Sleep(min);
        }
        public void validation(int i)
        {
            BrowserWindow window = new BrowserWindow();
            Thread.Sleep(1000);
            var len = window.ExecuteScript("var data=document.getElementById('ContentPlaceHolder1_tbdVendorInfo').getElementsByTagName('td');  return  data.length");
            string length = len.ToString().Trim();
            int Data = Convert.ToInt32(length);
            bool flag = true;
            if (Data == 0)
                flag = false;

            string error = "Data is Not there On Navigate page No:" + i;
            if (!flag)
            {
                string screenShotName = "DataIsNotThere_Navigate page No"+""+i;
                screenShot(screenShotName);
            }
            Assert.IsTrue(flag, error);
        }
        public void screenShot(string imgName)
        {
            BrowserWindow window = new BrowserWindow();
            string path = ConfigurationSettings.AppSettings["ScreenShot"];
            path = path + @"\\iPAS_VendorInformation";
            Directory.CreateDirectory(path);
            try
            {
                window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
                Image image = window.CaptureImage();
                image.Save(path + "\\" + imgName + ".jpeg", ImageFormat.Jpeg);
                image.Dispose();
            }
            catch (Exception e) { }
            Console.WriteLine("Screen Shot is Avaliable in " + path + "\t" + "Folder");
        }
        public void HtmlFileInput<T>(PropertyType type, string propertyvalue, string text) where T : HtmlControl
        {

            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            Mouse.Click(genericControl);

            AutoItX3 auto = new AutoItX3();
            auto.WinActivate("Choose File to Upload");
            auto.Send(text);
            auto.Send("{ENTER}");
            Thread.Sleep(1000);
        }
        public void PathEnterText<T>(PropertyType type, string propertyvalue, string text) where T : WinEdit
        {

            WinEdit genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            genericControl.FilterProperties[WinEdit.PropertyNames.Name] = propertyvalue;
            AutoItX3 auto = new AutoItX3();
            auto.WinActivate("Choose File to Upload");
            auto.Send(text);
            auto.Send("{ENTER}");
            Thread.Sleep(1000);
        }
        public void WindowButtonClick<T>(PropertyType type, string propertyvalue) where T : WinControl
        {
            WinControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Name)
                genericControl.SearchProperties[WinControl.PropertyNames.Name] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void Click<T>(PropertyType type, string propertyvalue) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });

            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;
            else if (type == PropertyType.InnerText)
            {
                genericControl.SearchProperties[HtmlControl.PropertyNames.InnerText] = propertyvalue;
            }
            else if (type == PropertyType.TagInstance)
                genericControl.FilterProperties[HtmlControl.PropertyNames.TagInstance] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void EnterText<T>(PropertyType type, string propertyvalue, string text) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;

            Keyboard.SendKeys(genericControl, text);

        }
        private BrowserWindow mparentwindow { get; set; }
        public enum PropertyType
        {
            Id,
            Name,
            InnerText,
            TagInstance
        }
        public BrowserWindow TopParentWindow()
        {

            BrowserWindow window = new BrowserWindow();
            window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
            return window;
        }
        public BrowserWindow ParentWindow
        {
            get
            {
                if (this.mparentwindow == null)
                {
                    this.mparentwindow = TopParentWindow();
                }
                return this.mparentwindow;
            }
        }
    }

}
