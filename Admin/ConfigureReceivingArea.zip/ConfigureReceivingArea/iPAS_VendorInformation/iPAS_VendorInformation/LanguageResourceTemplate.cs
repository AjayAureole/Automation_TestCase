﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Text;
using System.Threading.Tasks;

namespace iPAS_VendorInformation
{
    class LanguageResourceTemplate
    {
        static CultureInfo ci = null;
        static ResourceManager rm = null;
        static string resMsg_AddVendorSuccess = string.Empty;
        public string Msg_AddVendorSuccess
        {
            get { return resMsg_AddVendorSuccess; }
            set { resMsg_AddVendorSuccess = value; }
        }
        static string resMsg_EnterFreeStorageDays = string.Empty;
        public string Msg_EnterFreeStorageDays
        {
            get { return resMsg_EnterFreeStorageDays; }
            set { resMsg_EnterFreeStorageDays = value; }
        }
        static string resMsg_EnterValidEmailId = string.Empty;
        public string Msg_EnterValidEmailId
        {
            get { return resMsg_EnterValidEmailId; }
            set { resMsg_EnterValidEmailId = value; }
        }
        static string resMsg_EnterVendorCode = string.Empty;
        public string Msg_EnterVendorCode
        {
            get { return resMsg_EnterVendorCode; }
            set { resMsg_EnterVendorCode = value; }
        }
        static string resMsg_EnterVendorEmailId = string.Empty;
        public string Msg_EnterVendorEmailId
        {
            get { return resMsg_EnterVendorEmailId; }
            set { resMsg_EnterVendorEmailId = value; }
        }
        static string resMsg_EnterVendorName = string.Empty;
        public string Msg_EnterVendorName
        {
            get { return resMsg_EnterVendorName; }
            set { resMsg_EnterVendorName = value; }
        }
        static string resMsg_InvalidFormat = string.Empty;
        public string Msg_InvalidFormat
        {
            get { return resMsg_InvalidFormat; }
            set { resMsg_InvalidFormat = value; }
        }
        static string resMsg_NoRecordFound = string.Empty;
        public string Msg_NoRecordFound
        {
            get { return resMsg_NoRecordFound; }
            set { resMsg_NoRecordFound = value; }
        }
        static string resMsg_VendorAlreadyExist = string.Empty;
        public string Msg_VendorAlreadyExist
        {
            get { return resMsg_VendorAlreadyExist; }
            set { resMsg_VendorAlreadyExist = value; }
        }
        static string resMsg_VendorUpdateSuccess = string.Empty;
        public string Msg_VendorUpdateSuccess
        {
            get { return resMsg_VendorUpdateSuccess; }
            set { resMsg_VendorUpdateSuccess = value; }
        }
        public static void messageResource(string languageCode)
        {
            if (languageCode == "zh-CN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_VendorInformation.resources.VendorInfoResourceCN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "th-TH")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_VendorInformation.resources.VendorInfoResourceTH", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "vi-VN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_VendorInformation.resources.VendorInfoResourceVN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "ko-KR")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_VendorInformation.resources.VendorInfoResourceKR", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "ja-JP")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_VendorInformation.resources.VendorInfoResourceJP", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "id-ID")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_VendorInformation.resources.VendorInfoResourceID", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_VendorInformation.resources.VendorInfoResourceEN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
        }
        public static void messageInitialize()
        {
            resMsg_AddVendorSuccess = rm.GetString("resMsg_AddVendorSuccess", ci).Trim();
            resMsg_EnterFreeStorageDays = rm.GetString("resMsg_EnterFreeStorageDays", ci).Trim();
            resMsg_EnterValidEmailId = rm.GetString("resMsg_EnterValidEmailId", ci).Trim();
            resMsg_EnterVendorCode = rm.GetString("resMsg_EnterVendorCode", ci).Trim();
            resMsg_EnterVendorEmailId = rm.GetString("resMsg_EnterVendorEmailId", ci).Trim();
            resMsg_EnterVendorName = rm.GetString("resMsg_EnterVendorName", ci).Trim();
            resMsg_InvalidFormat = rm.GetString("resMsg_InvalidFormat", ci).Trim();
            resMsg_NoRecordFound = rm.GetString("resMsg_NoRecordFound", ci).Trim();
            resMsg_VendorAlreadyExist = rm.GetString("resMsg_VendorAlreadyExist", ci).Trim();
            resMsg_VendorUpdateSuccess = rm.GetString("resMsg_VendorUpdateSuccess", ci).Trim();

        }








    }
}
