﻿using AutoItX3Lib;
using DataDrivenTesting;
using iPAS_ManageForwarder;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ConfigureReceivingArea
{
    class ManageForwarder
    {
        string minsleep = ConfigurationSettings.AppSettings["min"];
        string midsleep = ConfigurationSettings.AppSettings["mid"];
        string maxsleep = ConfigurationSettings.AppSettings["max"];
        LanguageResourceTemplate languageResource = new LanguageResourceTemplate();
        public void Forwarder()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "lnkAdmin");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkGRIndex");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkManageForwarder");
            auto.MouseClick();
            Thread.Sleep(mid);
            auto.Send("F5");
            Thread.Sleep(mid);

            /*Here Checking how Many record is there befor add */

            //var totalbefore = window.ExecuteScript("var data=document.getElementById('spnTotalRecords').innerHTML;  return  data");
            //string tot = totalbefore.ToString().Trim();
            //int totalbeforerecord = Convert.ToInt32(totalbefore);

            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtForwarderName", ExcelDataTable.ReadData(1, "ForwarderName"));
              }
            catch (Exception e)
            { }
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnAddForwarder");
            auto.Sleep(mid);

            var data = window.ExecuteScript("var data=document.getElementById('spnAddForwarderError').innerHTML;  return  data");
            string successMsg = data.ToString().Trim();
            if (languageResource.Msg_AddForwarderSuccess!= successMsg)
            {
                string screenShotName = "AddingForwarder_NotSuccess";
                screenShot(screenShotName);
            }
            Assert.AreEqual(languageResource.Msg_AddForwarderSuccess, successMsg, successMsg);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);

            //var afterTotal = window.ExecuteScript("var data=document.getElementById('spnTotalRecords').innerHTML;  return  data");
            //string afterTot = afterTotal.ToString().Trim();
            //int afterTotalRecords = Convert.ToInt32(afterTot);
            //totalbeforerecord = totalbeforerecord + 1;
            //Thread.Sleep(mid);
            //if (afterTotalRecords != totalbeforerecord)
            //{
            //    string screenShotName = "afterTotalRecords_NotProper";
            //    screenShot(screenShotName);
            //}
            //Assert.AreEqual(afterTotalRecords, totalbeforerecord, "Total Record value is Not Proper");

            //Thread.Sleep(min);

            /*********************Edit Manage Forwarder Information****************/
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtSearchName", ExcelDataTable.ReadData(1, "ForwarderName"));
             }catch(Exception e) { }
            Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearch");
            Thread.Sleep(mid);
            /******************Here validate Search Text Box Empty or not *****************/
            var data1 = window.ExecuteScript("var data=document.getElementById('spnSearchError').innerHTML;  return  data");
            string successMsg1 = data1.ToString().Trim();

            if (successMsg1 != "")
            {
                string screenShotName = "Please_Enter_Data";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", successMsg1, successMsg1);
            Thread.Sleep(min);

            //var EditId1 = window.ExecuteScript("var data=document.querySelectorAll('i'); return data;");
            //var EditId = window.ExecuteScript("var data=document.querySelectorAll('i'); return data[11].id;");
            //string id = EditId.ToString();
            //id = "'" + id + "'";
            //Thread.Sleep(500);
            //var xCoodinate = window.ExecuteScript("var data1=document.getElementById(" + id + "); var rect = data1.getBoundingClientRect(); return  rect.left");
            //var yCoodinate = window.ExecuteScript("var data1=document.getElementById(" + id + "); var rect = data1.getBoundingClientRect(); return  rect.top");

            //string x = xCoodinate.ToString();
            //string y = yCoodinate.ToString();
            //double x1 = Convert.ToDouble(x);
            //double y1 = Convert.ToDouble(y);
            //int Xco = Convert.ToInt32(x1);
            //int Yco = Convert.ToInt32(y1);
            ////Make sure Browser Window is Maximize
            //// Xco = Xco;
            //Yco = Yco + 65;
            //Xco = Xco + 5;
            //auto.MouseMove(Xco, Yco);
            //auto.MouseClick();
            //Thread.Sleep(mid);



            mparentwindow = null;
            Click<HtmlCell>(PropertyType.InnerText, ExcelDataTable.ReadData(1, "ForwarderName"));
            Thread.Sleep(min);
            int xCoodinate = auto.MouseGetPosX();
            int yCoodinate = auto.MouseGetPosY();
            xCoodinate = xCoodinate - 335;
            auto.MouseMove(xCoodinate, yCoodinate);
            Thread.Sleep(mid);
            auto.MouseClick();
            Thread.Sleep(min);

            try
            {
                Click<HtmlEdit>(PropertyType.Id, "txtForwarderName");
                auto.Send("{BACKSPACE 20}");
                auto.Send("{DEL 20}");
                EnterText<HtmlEdit>(PropertyType.Id, "txtForwarderName", ExcelDataTable.ReadData(1, "UpdateForwarderName"));
            }
            catch (Exception e)
            { }
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnAddForwarder");
            auto.Sleep(mid);
            var data2 = window.ExecuteScript("var data=document.getElementById('spnAddForwarderError').innerHTML;  return  data");
            string successMsg2 = data2.ToString().Trim();
            if (languageResource.Msg_UpdateForwarderSuccess != successMsg2)
            {
                string screenShotName = "UpdateForwarder_NotSuccess";
                screenShot(screenShotName);
            }
            Assert.AreEqual(languageResource.Msg_UpdateForwarderSuccess, successMsg2, successMsg2);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void deleteForwarder()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtSearchName", ExcelDataTable.ReadData(1, "UpdateForwarderName"));
            }
            catch (Exception e) { }
            Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearch");
            Thread.Sleep(mid);
            /******************Here validate Search Text Box Empty or not *****************/
            var data1 = window.ExecuteScript("var data=document.getElementById('spnSearchError').innerHTML;  return  data");
            string successMsg1 = data1.ToString().Trim();
            if (successMsg1 != "")
            {
                string screenShotName = "Please_EnterData";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", successMsg1, successMsg1);
            Thread.Sleep(min);

            //var ArrayId = window.ExecuteScript("var data=document.querySelectorAll('i'); return data;");
            //var EditId = window.ExecuteScript("var data=document.querySelectorAll('i'); return data[11].id;");
            //string id = EditId.ToString();

            //id = "'" + id + "'";
            //Thread.Sleep(min);
            //var xCoodinate = window.ExecuteScript("var data1=document.getElementById(" + id + "); var rect = data1.getBoundingClientRect(); return  rect.left");
            //var yCoodinate = window.ExecuteScript("var data1=document.getElementById(" + id + "); var rect = data1.getBoundingClientRect(); return  rect.top");

            //string x = xCoodinate.ToString();
            //string y = yCoodinate.ToString();
            //double x1 = Convert.ToDouble(x);
            //double y1 = Convert.ToDouble(y);
            //int Xco = Convert.ToInt32(x1);
            //int Yco = Convert.ToInt32(y1);
            ////Make sure Browser Window is Maximize
            //Xco = Xco + 30;
            //Yco = Yco + 65;
            //auto.MouseMove(Xco, Yco);
            //auto.MouseClick();
            //Thread.Sleep(min);
            //auto.Send("{ENTER}");
            //Thread.Sleep(min);
            //auto.Send("{F5}");
            //Thread.Sleep(mid);


            mparentwindow = null;
            Click<HtmlCell>(PropertyType.InnerText, ExcelDataTable.ReadData(1, "UpdateForwarderName"));
            Thread.Sleep(min);
            int xCoodinate = auto.MouseGetPosX();
            int yCoodinate = auto.MouseGetPosY();
            xCoodinate = xCoodinate - 300;
            auto.MouseMove(xCoodinate, yCoodinate);
            Thread.Sleep(mid);
            auto.MouseClick();
            Thread.Sleep(min);
            auto.Send("{ENTER}");
            Thread.Sleep(min);            
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void SearchDataFound()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtSearchName", ExcelDataTable.ReadData(1, "UpdateForwarderName"));
            }
            catch (Exception e) { }
            Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearch");
            Thread.Sleep(mid);
            /******************Here validate Search Text Box Empty or not *****************/
            var data1 = window.ExecuteScript("var data=document.getElementById('spnSearchError').innerHTML;  return  data");
            string successMsg1 = data1.ToString().Trim();
            if (successMsg1 != "")
            {
                string screenShotName = "Please_EnterData";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", successMsg1, successMsg1);
            Thread.Sleep(min);

            bool b1 = search();
            Thread.Sleep(min);
            if (!b1)
            {
                string screenShotName = "Not_Found";
                screenShot(screenShotName);
            }
            Assert.IsTrue(b1, "Data  is Not Deleted");
            Thread.Sleep(min);
            try
            {
                Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnShowAll");
            }
            catch (Exception e) { }
            Thread.Sleep(max);
        }
        public void screenShot(string imgName)
        {
            BrowserWindow window = new BrowserWindow();
            string path = ConfigurationSettings.AppSettings["ScreenShot"];
            path = path + @"\\iPAS_ManageForwarder";
            Directory.CreateDirectory(path);
            try
            {
                window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
                Image image = window.CaptureImage();
                image.Save(path + "\\" + imgName + ".jpeg", ImageFormat.Jpeg);
                image.Dispose();
            }
            catch (Exception e) { }
            Console.WriteLine("Screen Shot is Avaliable in " + path + "\t" + "Folder");
        }
        public bool search()
        {
            BrowserWindow window = new BrowserWindow();
            var data = window.ExecuteScript("var data1=document.getElementById('ContentPlaceHolder1_tbdForwarderInfo').getElementsByTagName('span')[0]; return data1.innerHTML;");
            string data1 = data.ToString().Trim();
            string NoData = languageResource.Msg_NoRecordFound;
            bool b1 = data1.Equals(languageResource.Msg_NoRecordFound);
            return b1;
        }
        public void PathEnterText<T>(PropertyType type, string propertyvalue, string text) where T : WinEdit
        {
            WinEdit genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            genericControl.FilterProperties[WinEdit.PropertyNames.Name] = propertyvalue;
            AutoItX3 auto = new AutoItX3();
            auto.WinActivate("Choose File to Upload");
            auto.Send(text);
            auto.Send("{ENTER}");
            Thread.Sleep(1000);
        }
        public void WindowButtonClick<T>(PropertyType type, string propertyvalue) where T : WinControl
        {
            WinControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Name)
                genericControl.SearchProperties[WinControl.PropertyNames.Name] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void Click<T>(PropertyType type, string propertyvalue) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });

            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;
            else if (type == PropertyType.InnerText)
            {
                genericControl.SearchProperties[HtmlControl.PropertyNames.InnerText] = propertyvalue;
            }
            else if (type == PropertyType.TagInstance)
                genericControl.FilterProperties[HtmlControl.PropertyNames.TagInstance] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void EnterText<T>(PropertyType type, string propertyvalue, string text) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;

            Keyboard.SendKeys(genericControl, text);

        }
        private BrowserWindow mparentwindow { get; set; }
        public enum PropertyType
        {
            Id,
            Name,
            InnerText,
            TagInstance
        }
        public BrowserWindow TopParentWindow()
        {

            BrowserWindow window = new BrowserWindow();
            window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
            return window;
        }
        public BrowserWindow ParentWindow
        {
            get
            {
                if (this.mparentwindow == null)
                {
                    this.mparentwindow = TopParentWindow();
                }
                return this.mparentwindow;
            }
        }
    }
}
