﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Text;
using System.Threading.Tasks;

namespace iPAS_ManageForwarder
{
    class LanguageResourceTemplate
    {
        static CultureInfo ci = null;
        static ResourceManager rm = null;
        static string resMsg_NoRecordFound = string.Empty;
        public string Msg_NoRecordFound
        {
            get { return resMsg_NoRecordFound; }
            set { resMsg_NoRecordFound = value; }
        }
        static string resMsg_FailedToLoadForwarderInfo = string.Empty;
        public string Msg_FailedToLoadForwarderInfo
        {
            get { return resMsg_FailedToLoadForwarderInfo; }
            set { resMsg_FailedToLoadForwarderInfo = value; }
        }
        static string resMsg_Error = string.Empty;
        public string Msg_Error
        {
            get { return resMsg_Error; }
            set { resMsg_Error = value; }
        }

        static string resMsg_EnterForwarderName = string.Empty;
        public string Msg_EnterForwarderName
        {
            get { return resMsg_EnterForwarderName; }
            set { resMsg_EnterForwarderName = value; }
        }
        static string resMsg_ForwarderAlreadyExist = string.Empty;
        public string Msg_ForwarderAlreadyExist
        {
            get { return resMsg_ForwarderAlreadyExist; }
            set { resMsg_ForwarderAlreadyExist = value; }
        }

        static string resMsg_DeleteForwarderConfirm = string.Empty;
        public string Msg_DeleteForwarderConfirm
        {
            get { return resMsg_DeleteForwarderConfirm; }
            set { resMsg_DeleteForwarderConfirm = value; }
        }

        static string resMsg_BtnConfirm = string.Empty;
        public string Msg_BtnConfirm
        {
            get { return resMsg_BtnConfirm; }
            set { resMsg_BtnConfirm = value; }
        }

        static string resMsg_BtnCancel = string.Empty;
        public string Msg_BtnCancel
        {
            get { return resMsg_BtnCancel; }
            set { resMsg_BtnCancel = value; }
        }

        static string resMsg_FailedToRemoveForwarderInfo = string.Empty;
        public string Msg_FailedToRemoveForwarderInfo
        {
            get { return resMsg_FailedToRemoveForwarderInfo; }
            set { resMsg_FailedToRemoveForwarderInfo = value; }
        }

        static string resMsg_Ok = string.Empty;
        public string Msg_Ok
        {
            get { return resMsg_Ok; }
            set { resMsg_Ok = value; }
        }

        static string resMsg_Add = string.Empty;
        public string Msg_Add
        {
            get { return resMsg_Add; }
            set { resMsg_Add = value; }
        }

        static string resMsg_EnterSearchCriteria = string.Empty;
        public string Msg_EnterSearchCriteria
        {
            get { return resMsg_EnterSearchCriteria; }
            set { resMsg_EnterSearchCriteria = value; }
        }

        static string resMsg_BtnUpdate = string.Empty;
        public string Msg_BtnUpdate
        {
            get { return resMsg_BtnUpdate; }
            set { resMsg_BtnUpdate = value; }
        }

        static string resMsg_UpdateForwarderSuccess = string.Empty;
        public string Msg_UpdateForwarderSuccess
        {
            get { return resMsg_UpdateForwarderSuccess; }
            set { resMsg_UpdateForwarderSuccess = value; }
        }

        static string resMsg_AddForwarderSuccess = string.Empty;
        public string Msg_AddForwarderSuccess
        {
            get { return resMsg_AddForwarderSuccess; }
            set { resMsg_AddForwarderSuccess = value; }
        }

        static string resMsg_FailedToAddForwarderName = string.Empty;
        public string Msg_FailedToAddForwarderName
        {
            get { return resMsg_FailedToAddForwarderName; }
            set { resMsg_FailedToAddForwarderName = value; }
        }

        static string resMsg_FailedToUpdateForwarderName= string.Empty;
        public string Msg_FailedToUpdateForwarderName
        {
            get { return resMsg_FailedToUpdateForwarderName; }
            set { resMsg_FailedToUpdateForwarderName = value; }
        }

        public static void messageResource(string languageCode)
        {
            if (languageCode == "zh-CN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ManageForwarder.resources.ForwarderResourceCN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "th-TH")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ManageForwarder.resources.ForwarderResourceTH", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else
            {
               ci = new CultureInfo(languageCode);
               rm = new ResourceManager("iPAS_ManageForwarder.resources.ForwarderResourceEN", Assembly.GetExecutingAssembly());
               messageInitialize();
            }
        }
        public static void messageInitialize()
        {
            resMsg_NoRecordFound = rm.GetString("resMsg_NoRecordFound", ci).Trim();
            resMsg_FailedToLoadForwarderInfo = rm.GetString("resMsg_FailedToLoadForwarderInfo", ci).Trim();
            resMsg_Error = rm.GetString("resMsg_Error", ci).Trim();
            resMsg_EnterForwarderName = rm.GetString("resMsg_EnterForwarderName", ci).Trim();
            resMsg_ForwarderAlreadyExist = rm.GetString("resMsg_ForwarderAlreadyExist", ci).Trim();
            resMsg_DeleteForwarderConfirm = rm.GetString("resMsg_DeleteForwarderConfirm", ci).Trim();
            resMsg_BtnCancel = rm.GetString("resMsg_BtnCancel", ci).Trim();
            resMsg_FailedToRemoveForwarderInfo = rm.GetString("resMsg_FailedToRemoveForwarderInfo", ci).Trim();
            resMsg_Ok = rm.GetString("resMsg_Ok", ci).Trim();
            resMsg_Add = rm.GetString("resMsg_Add", ci).Trim();
            resMsg_EnterSearchCriteria = rm.GetString("resMsg_EnterSearchCriteria", ci).Trim();
            resMsg_BtnUpdate = rm.GetString("resMsg_BtnUpdate", ci).Trim();
            resMsg_UpdateForwarderSuccess = rm.GetString("resMsg_UpdateForwarderSuccess", ci).Trim();
            resMsg_AddForwarderSuccess = rm.GetString("resMsg_AddForwarderSuccess", ci).Trim();
            resMsg_FailedToAddForwarderName = rm.GetString("resMsg_FailedToAddForwarderName", ci).Trim();
            resMsg_FailedToUpdateForwarderName = rm.GetString("resMsg_FailedToUpdateForwarderName", ci).Trim();
        }
    }
}
