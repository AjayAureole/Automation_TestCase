﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Text;
using System.Threading.Tasks;

namespace iPAS_AdditionalMaterialInfo
{
    class MaterialInfoLanguageTemaple
    {

        static CultureInfo ci = null;
        static ResourceManager rm = null;
       
        static string resMsg_NoRecordsFound = string.Empty;
        public string Msg_NoRecordsFound
        {
            get { return resMsg_NoRecordsFound; }
            set { resMsg_NoRecordsFound = value; }
        }
        static string resMsg_EnterSearchCriteria = string.Empty;
        public string Msg_EnterSearchCriteria
        {
            get { return resMsg_EnterSearchCriteria; }
            set { resMsg_EnterSearchCriteria = value; }
        }


        public static void messageResource(string languageCode)
        {
            if (languageCode == "zh-CN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_AdditionalMaterialInfo.resources.MaterialInfoResourceEN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "th-TH")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_AdditionalMaterialInfo.resources.MaterialInfoResourceTH", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "vi-VN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_AdditionalMaterialInfo.resources.MaterialInfoResourceVN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "ko-KR")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_AdditionalMaterialInfo.resources.MaterialInfoResourceKR", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "ja-JP")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_AdditionalMaterialInfo.resources.MaterialInfoResourceJP", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "id-ID")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_AdditionalMaterialInfo.resources.MaterialInfoResourceID", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_AdditionalMaterialInfo.resources.MaterialInfoResourceEN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
        }
        public static void messageInitialize()
        {
            resMsg_NoRecordsFound = rm.GetString("resMsg_NoRecordsFound", ci).Trim();
            resMsg_EnterSearchCriteria = rm.GetString("resMsg_EnterSearchCriteria", ci).Trim();
        }

    }
}
