﻿using AutoItX3Lib;
using DataDrivenTesting;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace iPAS_AdditionalMaterialInfo
{
    class MaterialDatails
    {
        string minsleep = ConfigurationSettings.AppSettings["min"];
        string midsleep = ConfigurationSettings.AppSettings["mid"];
        string maxsleep = ConfigurationSettings.AppSettings["max"];
        MaterialInfoLanguageTemaple languageResource = new MaterialInfoLanguageTemaple();

        public void uploadInfo()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "lnkAdmin");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkGRIndex");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkAdditionalMatInfo");
            auto.MouseClick();
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(max);
            try {

                Click<HtmlSpan>(PropertyType.InnerText, "Additional Material Information");
            }catch(Exception e)
            {
                Click<HtmlSpan>(PropertyType.InnerText, "Additional Material Information");
            }
            Thread.Sleep(min);
            int xCoodinate = auto.MouseGetPosX();
            int yCoodinate = auto.MouseGetPosY();
            xCoodinate = xCoodinate - 320;
            auto.MouseMove(xCoodinate, yCoodinate);
            yCoodinate = yCoodinate + 40;
            auto.MouseMove(xCoodinate, yCoodinate);
            auto.MouseClick();
            try
            {
                EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpUploadType", ExcelDataTable.ReadData(1, "UploadType"));
            }
            catch (Exception) { }
            Click<HtmlFileInput>(PropertyType.Id, "ContentPlaceHolder1_uploadLooseCartonOrIsJIT");
            PathEnterText<WinEdit>(PropertyType.Name, "File name:", ExcelDataTable.ReadData(1, "filePath"));
            Thread.Sleep(mid);

            /****************Here check Validate File is Uploaded or not******************/
            var data = window.ExecuteScript("var data=document.getElementById('lblUploadError').innerHTML; return data;");
            string msg = data.ToString().Trim();
            if (msg != "")
            {
                string screenShotName = "SelectUploadType";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", msg, msg);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void SearchUploadinfo()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            try
            {
             EnterText<HtmlEdit>(PropertyType.Id, "txtIDHID",ExcelDataTable.ReadData(1, "Material_No"));
            }catch(Exception e) { }
            EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_ddlMaterialType",ExcelDataTable.ReadData(1, "UploadType"));
            Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearch");
            Thread.Sleep(mid);
            /*********************Here IDH Number is Enter Or Not**************/
            var data1 = window.ExecuteScript("var data=document.getElementById('spnSearchError').innerHTML; return data;");
            string msg1 = data1.ToString().Trim();
            bool b = msg1.Equals(languageResource.Msg_EnterSearchCriteria);
            if (b)
            {
                string screenShotName = "Please_Enter_IDHNumber";
                screenShot(screenShotName);
            }

            Assert.IsFalse(b, msg1);

            var EditId1 = window.ExecuteScript("var data=document.querySelectorAll('i'); return data;");
            var EditId = window.ExecuteScript("var data=document.querySelectorAll('i'); return data[16].id;");
            string id = EditId.ToString();
            id = "'" + id + "'";
            Thread.Sleep(mid);
            string uploadType = ExcelDataTable.ReadData(1, "UploadType");
            Thread.Sleep(mid);
            string str;
            bool b1;
            if (uploadType.Equals("JIT Materials"))
            {
                    id = id.Replace("delete", "tdISJit");
                    var data = window.ExecuteScript("var data=document.getElementById(" + id + ").getAttribute('isjit'); return data;");
                    str = data.ToString();
                    b1 = Boolean.Parse(str);
                if (!b1)
                {
                    string screenShotName = "CorrespondingChechBoxIsNot_Checked1";
                    screenShot(screenShotName);
                }

                Assert.IsTrue(b1, "Corresponding ChechBox is Not Checked");
            }
            else
            {
                id = id.Replace("delete", "tdIsLooseCarton");
                var data = window.ExecuteScript("var data=document.getElementById(" + id + ").getAttribute('isloosecarton'); return data;");
                    str = data.ToString();
                    b1 = Boolean.Parse(str);
                   if (!b1)
                  {
                   string screenShotName = "CorrespondingChechBoxIsNot_Checked2";
                   screenShot(screenShotName);
                  }
                Assert.IsTrue(b1, "Corresponding ChechBox is Not Checked");
            }
        }
        public void deleteUploadedinfo()
        {

            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtIDHID", ExcelDataTable.ReadData(1, "Material_No"));
            }
            catch (Exception e) { }
            EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_ddlMaterialType", ExcelDataTable.ReadData(1, "UploadType"));
            Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearch");
            Thread.Sleep(mid);

            /*********************Here IDH Number is Enter Or Not**************/
            var data1 = window.ExecuteScript("var data=document.getElementById('spnSearchError').innerHTML; return data;");
            string msg1 = data1.ToString().Trim();
            bool b = msg1.Equals(languageResource.Msg_EnterSearchCriteria);
            if (b)
            {
                string screenShotName = "Please_EnterIDH_Number";
                screenShot(screenShotName);
            }
            Assert.IsFalse(b, msg1);
            Thread.Sleep(mid);
            //var EditId1 = window.ExecuteScript("var data=document.querySelectorAll('i'); return data;");
            //var EditId = window.ExecuteScript("var data=document.querySelectorAll('i'); return data[17].id;");
            //string id = EditId.ToString();
            //id = "'" + id + "'";
            //var xCoodinate = window.ExecuteScript("var data1=document.getElementById(" + id + "); var rect = data1.getBoundingClientRect(); return  rect.left");
            //var yCoodinate = window.ExecuteScript("var data1=document.getElementById(" + id + "); var rect = data1.getBoundingClientRect(); return  rect.top");

            //string x = xCoodinate.ToString();
            //string y = yCoodinate.ToString();
            //double x1 = Convert.ToDouble(x);
            //double y1 = Convert.ToDouble(y);
            //int Xco = Convert.ToInt32(x1);
            //int Yco = Convert.ToInt32(y1);
            ////Make sure Browser Window is Maximize
            //// Xco = Xco;
            //Yco = Yco + 65;
            //auto.MouseMove(Xco, Yco);
            //auto.MouseClick();
            //Thread.Sleep(min);
            //auto.Send("{ENTER}");
            //Thread.Sleep(min);

            mparentwindow = null;
            Click<HtmlSpan>(PropertyType.InnerText, ExcelDataTable.ReadData(1, "Material_No"));
            Thread.Sleep(min);
            int xCoodinate = auto.MouseGetPosX();
            int yCoodinate = auto.MouseGetPosY();
            xCoodinate = xCoodinate - 75;
            auto.MouseMove(xCoodinate, yCoodinate);


            Thread.Sleep(mid);
            auto.MouseClick();
            Thread.Sleep(min);
            auto.Send("{ENTER}");
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void validateAvailability()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtIDHID", ExcelDataTable.ReadData(1, "Material_No"));
            }
            catch (Exception e) { }
            EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_ddlMaterialType", ExcelDataTable.ReadData(1, "UploadType"));
            Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearch");
            Thread.Sleep(mid);
            /*********************Here IDH Number is Enter Or Not**************/
            var data1 = window.ExecuteScript("var data=document.getElementById('spnSearchError').innerHTML; return data;");
            string msg1 = data1.ToString().Trim();
            bool b = msg1.Equals(languageResource.Msg_EnterSearchCriteria);
            if (b)
            {
                string screenShotName = "Please_EnterIDH_Number";
                screenShot(screenShotName);
            }
            Assert.IsFalse(b, msg1);
            Thread.Sleep(mid);
            bool b1 = Search();
            if (!b1)
            {
                string screenShotName = "Not_Found";
                screenShot(screenShotName);
            }

            Assert.IsTrue(b1, "Data is Not Deleted");
            Thread.Sleep(max);
            try
            {
                Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearchAll");
            }catch(Exception e) { }
            Thread.Sleep(max);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void screenShot(string imgName)
        {
            BrowserWindow window = new BrowserWindow();
            string path = ConfigurationSettings.AppSettings["ScreenShot"];
            path = path + @"\\iPAS_AdditionalMaterialInfo";
            Directory.CreateDirectory(path);
            try
            {
                window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
                Image image = window.CaptureImage();
                image.Save(path + "\\" + imgName + ".jpeg", ImageFormat.Jpeg);
                image.Dispose();
            }
            catch (Exception e) { }
            Console.WriteLine("Screen Shot is Avaliable in " + path + "\t" + "Folder");
        }
        public bool Search()
        {
            BrowserWindow window = new BrowserWindow();
            var data1 = window.ExecuteScript("var data=document.getElementById('ContentPlaceHolder1_tbSampleMaster').getElementsByTagName('td')[0];  return  data.innerHTML");
            string msg1 = data1.ToString().Trim();
            bool b1 = msg1.Equals(languageResource.Msg_NoRecordsFound);
            return b1;
        }
        public void downloadTemplate()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            try
            {

                Click<HtmlSpan>(PropertyType.InnerText, "Additional Material Information");
            }
            catch (Exception e)
            {
                Click<HtmlSpan>(PropertyType.InnerText, "Additional Material Information");
            }
            Thread.Sleep(min);
            int xCoodinate = auto.MouseGetPosX();
            int yCoodinate = auto.MouseGetPosY();
            xCoodinate = xCoodinate - 320;
            auto.MouseMove(xCoodinate, yCoodinate);
            yCoodinate = yCoodinate + 40;
            auto.MouseMove(xCoodinate, yCoodinate);
            auto.MouseClick();
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_downLoadTemplateLink");
            Thread.Sleep(max*4);
            Click<HtmlDiv>(PropertyType.Id, "footer");
            WindowButtonClick<WinToolBar>(PropertyType.Name, "Notification");
            WindowButtonClick<WinButton>(PropertyType.Name, "Open");
            mparentwindow = null;
            Thread.Sleep(max * 17);
            auto.WinClose("Microsoft Excel");
            auto.WinClose("Excel");
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void pageNavigator()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            /*************************Mouse control down***************************/
            auto.Send("{Down}");
            Thread.Sleep(mid);
            auto.Send("{Down}");
            Thread.Sleep(mid);
            auto.Send("{Down}");

            try
            {
               // Click<HtmlDiv>(PropertyType.Id, "footer");
                //Click<HtmlDiv>(PropertyType.Id, "ContentPlaceHolder1_divPager");
            }
            catch (Exception e)
            {
                //Click<HtmlDiv>(PropertyType.Id, "ContentPlaceHolder1_divPager");
            }
            //try
            //{
            //    var pageCount = window.ExecuteScript("var data=document.getElementById('ctl01_divPager').getElementsByTagName('a');  return  data.length");
            //    string len = pageCount.ToString();
            //    int length = Convert.ToInt32(len);
            //    for (int i = 1; i <= length; i++)
            //    {
            //        string tagId = "ctl01_hrefNum" + i;
            //        Thread.Sleep(mid);
            //        if (i == 7)
                        Click<HtmlHyperlink>(PropertyType.Id, "ctl01_hrefLast");
                        Thread.Sleep(max);
                        validation();
                        Thread.Sleep(min);
            //    tagId = "";
            //}
            //}
            //catch (Exception e) { }
        }

        public void validation()
        {
            BrowserWindow window = new BrowserWindow();
            Thread.Sleep(1000);
            var len = window.ExecuteScript("var data=document.getElementById('ContentPlaceHolder1_tbSampleMaster').getElementsByTagName('td');  return  data.length");
            string length = len.ToString().Trim();
            int Data = Convert.ToInt32(length);
            bool flag = true;
            if (Data == 0)
                flag = false;

            string error = "Data is Not there On Last Navigate page";
            Assert.IsTrue(flag, error);
        }
        public void WindowButtonClick<T>(PropertyType type, string propertyvalue) where T : WinControl
        {
            WinControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Name)
                genericControl.SearchProperties[WinControl.PropertyNames.Name] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void PathEnterText<T>(PropertyType type, string propertyvalue, string text) where T : WinEdit
        {
            WinEdit genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            genericControl.FilterProperties[WinEdit.PropertyNames.Name] = propertyvalue;
            AutoItX3 auto = new AutoItX3();
            auto.WinActivate("Choose File to Upload");
            auto.Send(text);
            auto.Send("{ENTER}");
            Thread.Sleep(1000);
        }

        public void Click<T>(PropertyType type, string propertyvalue) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });

            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;           
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;
            else if (type == PropertyType.InnerText)
                genericControl.SearchProperties[HtmlControl.PropertyNames.InnerText] = propertyvalue;
            else if (type == PropertyType.TagInstance)
                genericControl.FilterProperties[HtmlControl.PropertyNames.TagInstance] = propertyvalue;
            else if (type == PropertyType.TagName)
                genericControl.SearchProperties[HtmlControl.PropertyNames.TagName] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void EnterText<T>(PropertyType type, string propertyvalue, string text) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;

            Keyboard.SendKeys(genericControl, text);

        }
        private BrowserWindow mparentwindow { get; set; }
        public enum PropertyType
        {
            Id,
            Name,
            InnerText,
            TagInstance,
            TagName

        }
        public BrowserWindow TopParentWindow()
        {

            BrowserWindow window = new BrowserWindow();
            window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
            return window;
        }
        public BrowserWindow ParentWindow
        {
            get
            {
                if (this.mparentwindow == null)
                {
                    this.mparentwindow = TopParentWindow();
                }
                return this.mparentwindow;
            }
        }
    }
}
