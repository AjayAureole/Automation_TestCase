﻿
using AutoItX3Lib;
using DataDrivenTesting;
using iPAS_MRPControlValues;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ConfigureReceivingArea
{
    class MRPControlValues
    {

        string minsleep = ConfigurationSettings.AppSettings["min"];
        string midsleep = ConfigurationSettings.AppSettings["mid"];
        string maxsleep = ConfigurationSettings.AppSettings["max"];
        LanguageResouceTemplate languageResource = new LanguageResouceTemplate();
        public void MRPControllerInfo()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            auto.Send("{F5}");
            Thread.Sleep(mid);

            Click<HtmlHyperlink>(PropertyType.Id, "lnkAdmin");
            Thread.Sleep(mid);
            //Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkGRIndex");
            //Thread.Sleep(max);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkMRPControlValue");
            auto.MouseClick();
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            /*Here Checking how Many record is there befor add */

            //var totalbefore = window.ExecuteScript("var data=document.getElementById('spnTotalRecords').innerHTML;  return  data");
            //string tot = totalbefore.ToString().Trim();
            //int totalbeforerecord = Convert.ToInt32(totalbefore);
            //Thread.Sleep(min);
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtController", ExcelDataTable.ReadData(1, "MRPController"));
            }
            catch(Exception e){}
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtControllerDesc", ExcelDataTable.ReadData(1, "Description"));
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpTechnologyName", ExcelDataTable.ReadData(1, "Technology"));
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlSpan>(PropertyType.Id, "sldIsImportedGood");
            }
            catch (Exception e){
            }

            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnAddMRPController");
            Thread.Sleep(min);

            var data1 = window.ExecuteScript("var data=document.getElementById('spnMRPControllerError').innerHTML;  return  data");
            string successMsg1 = data1.ToString().Trim();
            if (successMsg1!= languageResource.Msg_AddMRPControllerSuccess)
            {
                string screenShotName = "MRPController_NotAdded";
                screenShot(screenShotName);
            }
            Assert.AreEqual(languageResource.Msg_AddMRPControllerSuccess, successMsg1, successMsg1);
            Thread.Sleep(min);
            //var afterTotal = window.ExecuteScript("var data=document.getElementById('spnTotalRecords').innerHTML;  return  data");
            //string afterTot = afterTotal.ToString().Trim();
            //int afterTotalRecords = Convert.ToInt32(afterTot);
            //totalbeforerecord = totalbeforerecord + 1;
            //Thread.Sleep(mid);
            //if (afterTotalRecords != totalbeforerecord)
            //{
            //    string screenShotName = "afterTotalRecords_NotProper";
            //    screenShot(screenShotName);
            //}
            //Assert.AreEqual(afterTotalRecords, totalbeforerecord, "Total Record value is Not Proper");
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);

            /****************Edit the MRPControllerInfo*********************/
           
            Click<HtmlCell>(PropertyType.InnerText, ExcelDataTable.ReadData(1, "MRPController"));
            int Mx1 = auto.MouseGetPosX();
            int My1 = auto.MouseGetPosY();
            Mx1 = Mx1 - 105;
            My1 = My1 - 3;
            Thread.Sleep(max);
            auto.MouseMove(Mx1, My1);
            auto.MouseClick();
            Thread.Sleep(min);
            try
            { 
                Click<HtmlEdit>(PropertyType.Id, "txtControllerDesc");
                auto.Send("{BACKSPACE 30}");//Existing Data Deletion
                auto.Send("{DEL 30}");
                EnterText<HtmlEdit>(PropertyType.Id, "txtControllerDesc", ExcelDataTable.ReadData(1, "UpdateDescription"));
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpTechnologyName", ExcelDataTable.ReadData(1, "UpdateTechnology"));
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlSpan>(PropertyType.Id, "sldIsFinishedGood");
            }
            catch (Exception e) { }
            try
            {
                Click<HtmlCheckBox>(PropertyType.Id, "chkIsFinishedGood");
            }
            catch (Exception e) { }
            Thread.Sleep(min);
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnAddMRPController");
            Thread.Sleep(min);
            var data = window.ExecuteScript("var data=document.getElementById('spnMRPControllerError').innerHTML;  return  data");
            string successMsg = data.ToString().Trim();
            if (successMsg !=languageResource.Msg_MRPControllerUpdateSuccess)
            {
                string screenShotName = "MRPController_NotUpdating";
                screenShot(screenShotName);
            }
            Assert.AreEqual(languageResource.Msg_MRPControllerUpdateSuccess, successMsg, successMsg);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            /*********************Deletion of MRP Controller Information****************************/
               
            Click<HtmlCell>(PropertyType.InnerText, ExcelDataTable.ReadData(1, "MRPController"));
            int Mx2 = auto.MouseGetPosX();
            int My2 = auto.MouseGetPosY();
            Mx2 = Mx2 - 75;
            Thread.Sleep(max);
            auto.MouseMove(Mx2, My2);
            auto.MouseClick();
            Thread.Sleep(min);
            auto.Send("{ENTER}");
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void pageNavigation()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            int i = 1;
            try
            {
                var pageCount = window.ExecuteScript("var data=document.getElementById('ctl01_divPager').getElementsByTagName('a');  return  data.length");
                string len = pageCount.ToString();
                int length = Convert.ToInt32(len);
                Click<HtmlDiv>(PropertyType.Id, "footer");
                for (i = 1; i <= length; i++)
                {
                    string tagId = "ctl01_hrefNum" + i;
                    Click<HtmlDiv>(PropertyType.Id, "footer");
                    Thread.Sleep(mid);
                    Click<HtmlHyperlink>(PropertyType.Id, tagId);
                    validation(i);
                    tagId = "";
                }
            }
            catch (Exception e)
            {
                string error = "Data is Not there On Navigate page No:" + i;
                Assert.IsTrue(false, error);
            }
        }

        public void validation(int i)
        {
            BrowserWindow window = new BrowserWindow();
            Thread.Sleep(1000);
            var len = window.ExecuteScript("var data=document.getElementById('ContentPlaceHolder1_tbdMRPControllerInfo').getElementsByTagName('td');  return  data.length");
            string length = len.ToString().Trim();
            int Data = Convert.ToInt32(length);
            bool flag = true;
            if (Data == 0)
                flag = false;

            string error = "Data is Not there On Navigate page No:" + i;
            if (!flag)
            {
                string screenShotName = "Data_NotThereNavigatePage_No"+""+i;
                screenShot(screenShotName);
            }
            Assert.IsTrue(flag, error);
        }

        public void screenShot(string imgName)
        {
            BrowserWindow window = new BrowserWindow();
            string path = ConfigurationSettings.AppSettings["ScreenShot"];
            path = path + @"\\iPAS_MRPControlValues";
            Directory.CreateDirectory(path);
            try
            {
                window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
                Image image = window.CaptureImage();
                image.Save(path + "\\" + imgName + ".jpeg", ImageFormat.Jpeg);
                image.Dispose();
            }
            catch (Exception e) { }
            Console.WriteLine("Screen Shot is Avaliable in " + path + "\t" + "Folder");
        }
        public void PathEnterText<T>(PropertyType type, string propertyvalue, string text) where T : WinEdit
        {
            WinEdit genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            genericControl.FilterProperties[WinEdit.PropertyNames.Name] = propertyvalue;
            AutoItX3 auto = new AutoItX3();
            auto.WinActivate("Choose File to Upload");
            auto.Send(text);
            auto.Send("{ENTER}");
            Thread.Sleep(1000);
        }
        public void WindowButtonClick<T>(PropertyType type, string propertyvalue) where T : WinControl
        {
            WinControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Name)
                genericControl.SearchProperties[WinControl.PropertyNames.Name] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void Click<T>(PropertyType type, string propertyvalue) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });

            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;
            else if (type == PropertyType.InnerText)
            {
                genericControl.SearchProperties[HtmlControl.PropertyNames.InnerText] = propertyvalue;
            }
            else if (type == PropertyType.TagInstance)
                genericControl.FilterProperties[HtmlControl.PropertyNames.TagInstance] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void EnterText<T>(PropertyType type, string propertyvalue, string text) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;

            Keyboard.SendKeys(genericControl, text);

        }
        private BrowserWindow mparentwindow { get; set; }
        public enum PropertyType
        {
            Id,
            Name,
            InnerText,
            TagInstance
        }
        public BrowserWindow TopParentWindow()
        {

            BrowserWindow window = new BrowserWindow();
            window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
            return window;
        }
        public BrowserWindow ParentWindow
        {
            get
            {
                if (this.mparentwindow == null)
                {
                    this.mparentwindow = TopParentWindow();
                }
                return this.mparentwindow;
            }
        }
    }
}
