﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Text;
using System.Threading.Tasks;

namespace iPAS_MRPControlValues
{
    class LanguageResouceTemplate
    {
        static CultureInfo ci = null;
        static ResourceManager rm = null;
        static string resMsg_NoRecordFound = string.Empty;
        public string Msg_NoRecordFound
        {
            get { return resMsg_NoRecordFound; }
            set { resMsg_NoRecordFound = value; }
        }
        static string resMsg_EnterMRPController = string.Empty;
        public string Msg_EnterMRPController
        {
            get { return resMsg_EnterMRPController; }
            set { resMsg_EnterMRPController = value; }
        }
        static string resMsg_EnterMRPControllerDesc = string.Empty;
        public string Msg_EnterMRPControllerDesc
        {
            get { return resMsg_EnterMRPControllerDesc; }
            set { resMsg_EnterMRPControllerDesc = value; }
        }
        static string resMsg_AddMRPControllerSuccess = string.Empty;
        public string Msg_AddMRPControllerSuccess
        {
            get { return resMsg_AddMRPControllerSuccess; }
            set { resMsg_AddMRPControllerSuccess = value; }
        }
        static string resMsg_MRPControllerAlreadyExist = string.Empty;
        public string Msg_MRPControllerAlreadyExist
        {
            get { return resMsg_MRPControllerAlreadyExist; }
            set { resMsg_MRPControllerAlreadyExist = value; }
        }
        static string resMsg_FailedToAddMRPControllerInfo = string.Empty;
        public string Msg_FailedToAddMRPControllerInfo
        {
            get { return resMsg_FailedToAddMRPControllerInfo; }
            set { resMsg_FailedToAddMRPControllerInfo = value; }
        }

        static string resMsg_MRPControllerUpdateSuccess = string.Empty;
        public string Msg_MRPControllerUpdateSuccess
        {
            get { return resMsg_MRPControllerUpdateSuccess; }
            set { resMsg_MRPControllerUpdateSuccess = value; }
        }
        static string resMsg_FailedToUpdateMRPControllerInfo = string.Empty;
        public string Msg_FailedToUpdateMRPControllerInfo
        {
            get { return resMsg_FailedToUpdateMRPControllerInfo; }
            set { resMsg_FailedToUpdateMRPControllerInfo = value; }
        }
        public static void messageResource(string languageCode)
        {
            if (languageCode == "zh-CN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_MRPControlValues.resources.MRPControllerResourceCN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "th-TH")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_MRPControlValues.resources.MRPControllerResourceTH", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "vi-VN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_MRPControlValues.resources.MRPControllerResourceVN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "ko-KR")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_MRPControlValues.resources.MRPControllerResourceKR", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "ja-JP")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_MRPControlValues.resources.MRPControllerResourceJP", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "id-ID")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_MRPControlValues.resources.MRPControllerResourceID", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_MRPControlValues.resources.MRPControllerResourceEN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
        }
        public static void messageInitialize()
        {
            resMsg_NoRecordFound = rm.GetString("resMsg_NoRecordFound", ci).Trim();
            resMsg_EnterMRPController = rm.GetString("resMsg_EnterMRPController", ci).Trim();
            resMsg_EnterMRPControllerDesc = rm.GetString("resMsg_EnterMRPControllerDesc", ci).Trim();
            resMsg_AddMRPControllerSuccess = rm.GetString("resMsg_AddMRPControllerSuccess", ci).Trim();
            resMsg_MRPControllerAlreadyExist = rm.GetString("resMsg_MRPControllerAlreadyExist", ci).Trim();
            resMsg_FailedToAddMRPControllerInfo = rm.GetString("resMsg_FailedToAddMRPControllerInfo", ci).Trim();
            resMsg_MRPControllerUpdateSuccess = rm.GetString("resMsg_MRPControllerUpdateSuccess", ci).Trim();
            resMsg_FailedToUpdateMRPControllerInfo = rm.GetString("resMsg_FailedToUpdateMRPControllerInfo", ci).Trim();
        }
    }
}
