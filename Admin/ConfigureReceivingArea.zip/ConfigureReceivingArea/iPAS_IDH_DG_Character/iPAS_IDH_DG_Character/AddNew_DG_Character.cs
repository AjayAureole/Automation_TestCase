﻿using AutoItX3Lib;
using DataDrivenTesting;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace iPAS_IDH_DG_Character
{
    class AddNew_DG_Character
    {
        string minsleep = ConfigurationSettings.AppSettings["min"];
        string midsleep = ConfigurationSettings.AppSettings["mid"];
        string maxsleep = ConfigurationSettings.AppSettings["max"];

        public void  addNewDG_Character()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(max);
            auto.Send("{F5}");
            Thread.Sleep(mid);                  
            Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnNewAddCharacterType");
            Thread.Sleep(max);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            try
            {
               
                try
                {
                    EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtIDHNumber", ExcelDataTable.ReadData(1, "IDHNum"));
                }
                catch (Exception) { }
                try
                {
                    
                    EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtPreferedBrand", ExcelDataTable.ReadData(1, "PreferedBrand"));
                }
                catch (Exception) { }
                try
                {
                    EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtDescription", ExcelDataTable.ReadData(1, "IDHDescription"));

                }
                catch (Exception) { }
                try
                {

                    EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtTechnicalName", ExcelDataTable.ReadData(1, "TechnicalName"));
                }
                catch (Exception) { }

                try
                {
                   
                    EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtUNCode", ExcelDataTable.ReadData(1, "UNCode"));

                }
                catch (Exception) { }
                try
                {
                    EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder_txtDGClass", ExcelDataTable.ReadData(1, "DGClass"));

                }
                catch (Exception) { }
                try
                {
                   
                    EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtSubrisk", ExcelDataTable.ReadData(1, "Subrisk"));
                }
                catch (Exception) { }
                try
                {
                    EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtHAZ", ExcelDataTable.ReadData(1, "HAZ"));

                }
                catch (Exception) { }
                try
                {
                    EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtEPG", ExcelDataTable.ReadData(1, "EPG"));

                }
                catch (Exception) { }
                try
                {
                    EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtPG", ExcelDataTable.ReadData(1, "PG"));

                }
                catch (Exception) { }
                try
                {
                    EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtASS", ExcelDataTable.ReadData(1, "ASS"));

                }
                catch (Exception) { }
                try
                {
                    EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtASSG", ExcelDataTable.ReadData(1, "ASSG"));

                }
                catch (Exception) { }
                try
                {
                    EnterText<HtmlTextArea>(PropertyType.Id, "ContentPlaceHolder1_txtCritcalCharacteristic", ExcelDataTable.ReadData(1, "CritcalCharacteristic"));

                }
                catch (Exception) { }
            }
            catch (Exception e) { }
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnAdd");
            Thread.Sleep(mid);
            /******************Here Validate Mandatory  Text Box is not Empty *************************/
            string msg ="";
            try {
                var data = window.ExecuteScript("var data=document.getElementById('spnMessage').innerHTML; return data;");
                msg = data.ToString().Trim();
            } catch(Exception e) { }
            Thread.Sleep(min);
            if (msg!="")
            {
                string screenShotName = "Please_EnterData";
                screenShot(screenShotName);
            }
            Assert.AreEqual("",msg,msg);

            /*******************Here Search and update the data new Added Data*****************/
            auto.Send("{F5}");
            Thread.Sleep(mid);
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtIDHNumber", ExcelDataTable.ReadData(1, "IDHNum"));

            }
            catch (Exception e) { }
            Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearch");
            Thread.Sleep(min);

            /******************************Here Update the Data**************************/
            //var EditId1 = window.ExecuteScript("var data=document.querySelectorAll('i'); return data;");
            //var EditId = window.ExecuteScript("var data=document.querySelectorAll('i'); return data[18].id;");
            //string id = EditId.ToString();
            //id = "'" + id + "'";
            //Thread.Sleep(min);
            //var xCoodinate = window.ExecuteScript("var data1=document.getElementById(" + id + "); var rect = data1.getBoundingClientRect(); return  rect.left");
            //var yCoodinate = window.ExecuteScript("var data1=document.getElementById(" + id + "); var rect = data1.getBoundingClientRect(); return  rect.top");

            //string x = xCoodinate.ToString();
            //string y = yCoodinate.ToString();
            //double x1 = Convert.ToDouble(x);
            //double y1 = Convert.ToDouble(y);
            //int Xco = Convert.ToInt32(x1);
            //int Yco = Convert.ToInt32(y1);
            ////Make sure Browser Window is Maximize
            //// Xco = Xco;
            //Yco = Yco + 65;
            //Xco = Xco - 20;
            //auto.MouseMove(Xco, Yco);
            //Thread.Sleep(min);
            //auto.MouseClick();
            //Thread.Sleep(min);

            mparentwindow = null;
            Click<HtmlSpan>(PropertyType.InnerText, ExcelDataTable.ReadData(1, "IDHNum"));
            Thread.Sleep(min);
            int xCoodinate = auto.MouseGetPosX();
            int yCoodinate = auto.MouseGetPosY();
            xCoodinate = xCoodinate - 95;
            auto.MouseMove(xCoodinate, yCoodinate);


            Thread.Sleep(mid);
            auto.MouseClick();
            Thread.Sleep(min);
            //auto.Send("{ENTER}");
            //Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }

        public void deleteUploadedData()
        {

            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);


            ///******************Here Validate Any Text Box is not Empty*************************/
            //string msg = "";
            //try
            //{
            //    var data = window.ExecuteScript("var data=document.getElementById('spnMessage').innerHTML; return data;");
            //    msg = data.ToString();
            //}
            //catch (Exception e) { }
            //Thread.Sleep(min);
            //Assert.AreEqual("", msg, msg);

            /*******************Here Search and Delete the data new Added Data*****************/
           // auto.Send("{F5}");
            try
            {
                Thread.Sleep(mid);
                EnterText<HtmlEdit>(PropertyType.Id, "txtIDHNumber", ExcelDataTable.ReadData(1, "UpdateIDHNumber"));

            }
            catch (Exception e) { }
            Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearch");
            Thread.Sleep(min);

            /*********************Here IDH Number is Enter Or Not**************/
            var data1 = window.ExecuteScript("var data=document.getElementById('spnSearchError').innerHTML; return data;");
            string msg1 = data1.ToString();
            bool b1 = msg1.Equals("Please define search criteria");
            if (b1)
            {
                string screenShotName = "defineSearch_Criteria";
                screenShot(screenShotName);
            }
            Assert.IsFalse(b1, msg1);
            Thread.Sleep(min);

            /********************Delete the Uploaded Data******************************/
            //var EditId1 = window.ExecuteScript("var data=document.querySelectorAll('i'); return data;");
            //var EditId = window.ExecuteScript("var data=document.querySelectorAll('i'); return data[18].id;");
            //string id = EditId.ToString();
            //id = "'" + id + "'";
            //Thread.Sleep(min);
            //var xCoodinate = window.ExecuteScript("var data1=document.getElementById(" + id + "); var rect = data1.getBoundingClientRect(); return  rect.left");
            //var yCoodinate = window.ExecuteScript("var data1=document.getElementById(" + id + "); var rect = data1.getBoundingClientRect(); return  rect.top");

            //string x = xCoodinate.ToString();
            //string y = yCoodinate.ToString();
            //double x1 = Convert.ToDouble(x);
            //double y1 = Convert.ToDouble(y);
            //int Xco = Convert.ToInt32(x1);
            //int Yco = Convert.ToInt32(y1);

            //Yco = Yco + 65;
            //Xco = Xco + 5;
            //auto.MouseMove(Xco, Yco);
            //Thread.Sleep(mid);
            //auto.MouseClick();
            //Thread.Sleep(min);
            //auto.Send("{ENTER}");
            //Thread.Sleep(min);
            //auto.Send("{F5}");
            //Thread.Sleep(mid);


            mparentwindow = null;
            Click<HtmlSpan>(PropertyType.InnerText, ExcelDataTable.ReadData(1, "UpdateIDHNumber"));
            Thread.Sleep(min);
            int xCoodinate = auto.MouseGetPosX();
            int yCoodinate = auto.MouseGetPosY();
            xCoodinate = xCoodinate - 60;
            auto.MouseMove(xCoodinate, yCoodinate);
            Thread.Sleep(mid);
            auto.MouseClick();
            Thread.Sleep(mid);
            Click<HtmlButton>(PropertyType.InnerText, "Confirm");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);

            ///*****************Again Searching Data is Available or not************/
            //try
            //{
            //    EnterText<HtmlEdit>(PropertyType.Id, "txtIDHNumber", ExcelDataTable.ReadData(1, "UpdateIDHNumber"));

            //}
            //catch (Exception e) { }
            //Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearch");
            //Thread.Sleep(min);
            ///*********************Here Validate IDH Number is Enter Or Not**************/
            //var data2 = window.ExecuteScript("var data=document.getElementById('spnSearchError').innerHTML; return data;");
            //string msg2 = data2.ToString();
            //bool b2 = msg2.Equals("Please define search criteria");
            //if (b2)
            //{
            //    string screenShotName = "defineSearch_Criteria";
            //    screenShot(screenShotName);
            //}
            //Assert.IsFalse(b2, msg2);
            //Thread.Sleep(min);
            ///**********************Collect the Data************************/
            //bool vali = Search();
            //Assert.IsTrue(vali, "Record is Not Deleted");
            //Thread.Sleep(max);
            try
            {
                Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearchAll");
            }catch(Exception e) { }
            Thread.Sleep(max);
        }

        public void UpdateData()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);

            try
            {
                try {
                    Click<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtIDHNumber");
                    auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                    auto.Send("{DEL 20}");
                    EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtIDHNumber", ExcelDataTable.ReadData(1, "UpdateIDHNumber"));
                }
                catch(Exception) { }
                try
                {
                    Click<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtPreferedBrand");
                    auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                    auto.Send("{DEL 20}");
                    EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtPreferedBrand", ExcelDataTable.ReadData(1, "PreferedBrand"));
                }
                catch (Exception) { }
                    try {
                        Click<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtDescription");
                        auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                        auto.Send("{DEL 20}");
                        EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtDescription", ExcelDataTable.ReadData(1, "IDHDescription"));

                    }
                    catch (Exception) { }
                    try {

                        Click<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtTechnicalName");
                        auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                        auto.Send("{DEL 20}");
                        EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtTechnicalName", ExcelDataTable.ReadData(1, "TechnicalName"));
                    }catch(Exception) { }

                    try
                    {
                        Click<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtUNCode");
                        auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                        auto.Send("{DEL 20}");
                        EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtUNCode", ExcelDataTable.ReadData(1, "UNCode"));

                    }
                    catch (Exception) { }
                    try
                    {
                        Click<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtDGClass");
                        auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                        auto.Send("{DEL 20}");
                        EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtDGClass", ExcelDataTable.ReadData(1, "DGClass"));


                    }
                    catch (Exception) { }
                    try {
                        Click<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtSubrisk");
                        auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                        auto.Send("{DEL 20}");
                        EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtSubrisk", ExcelDataTable.ReadData(1, "Subrisk"));
                    }catch(Exception) { }
                    try
                    {
                        Click<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtHAZ");
                        auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                        auto.Send("{DEL 20}");
                        EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtHAZ", ExcelDataTable.ReadData(1, "HAZ"));

                    }
                    catch (Exception) { }
                    try
                    {
                        Click<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtEPG");
                        auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                        auto.Send("{DEL 20}");
                        EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtEPG", ExcelDataTable.ReadData(1, "EPG"));

                    }
                    catch (Exception) { }
                    try
                    {
                        Click<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtPG");
                        auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                        auto.Send("{DEL 20}");
                        EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtPG", ExcelDataTable.ReadData(1, "PG"));

                    }
                    catch (Exception) { }
                try
                {
                    Click<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtASS");
                    auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                    auto.Send("{DEL 20}");
                    EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtASS", ExcelDataTable.ReadData(1, "ASS"));

                }
                catch (Exception) { }
                        try
                        {
                            Click<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtASSG");
                            auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                            auto.Send("{DEL 20}");
                            EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtASSG", ExcelDataTable.ReadData(1, "ASSG"));

                        }
                        catch (Exception) { }
                        try
                        {
                            Click<HtmlTextArea>(PropertyType.Id, "ContentPlaceHolder1_txtCritcalCharacteristic");
                            auto.Send("{BACKSPACE 30}");//Existing Data Deletion
                            auto.Send("{DEL 30}");
                            EnterText<HtmlTextArea>(PropertyType.Id, "ContentPlaceHolder1_txtCritcalCharacteristic", ExcelDataTable.ReadData(1, "CritcalCharacteristic"));

                        }
                        catch (Exception) { }
               
            }
            catch (Exception e) { }
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnAdd");
            Thread.Sleep(mid);
            /******************Here Validate Mandatory  Text Box is not Empty *************************/
            string msg = "";
            try
            {
                var data = window.ExecuteScript("var data=document.getElementById('spnMessage').innerHTML; return data;");
                msg = data.ToString();
            }
            catch (Exception e) { }
            Thread.Sleep(min);
            if (msg!="")
            {
                string screenShotName = "PleaseEnter_Data";
                screenShot(screenShotName);
            }

            Assert.AreEqual("", msg, msg);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        } 

        public bool Search()
        {
            BrowserWindow window = new BrowserWindow();
            Thread.Sleep(500);
            var tbl = window.ExecuteScript("var data=document.getElementById('ContentPlaceHolder1_tbCharacterstic').getElementsByTagName('span')[0];  return  data.innerHTML");
            string data = tbl.ToString();
            bool b1 = data.Equals("No records found.");
            return b1;
        }
        public void screenShot(string imgName)
        {
            BrowserWindow window = new BrowserWindow();
            string path = ConfigurationSettings.AppSettings["ScreenShot"];
            try
            {
                window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
                Image image = window.CaptureImage();
                image.Save(path + "\\" + imgName + ".jpeg", ImageFormat.Jpeg);
                image.Dispose();
            }
            catch (Exception e) { }
            Console.WriteLine("Screen Shot is Avaliable in " + path + "\t" + "Folder");
        }

        public void PathEnterText<T>(PropertyType type, string propertyvalue, string text) where T : WinEdit
        {
            WinEdit genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            genericControl.FilterProperties[WinEdit.PropertyNames.Name] = propertyvalue;
            AutoItX3 auto = new AutoItX3();
            auto.WinActivate("Choose File to Upload");
            auto.Send(text);
            auto.Send("{ENTER}");
            Thread.Sleep(1000);
        }

        public void WindowButtonClick<T>(PropertyType type, string propertyvalue) where T : WinControl
        {
            WinControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Name)
                genericControl.SearchProperties[WinControl.PropertyNames.Name] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void Click<T>(PropertyType type, string propertyvalue) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });

            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;
            else if (type == PropertyType.InnerText)
            {
                genericControl.SearchProperties[HtmlControl.PropertyNames.InnerText] = propertyvalue;
            }
            else if (type == PropertyType.TagInstance)
                genericControl.FilterProperties[HtmlControl.PropertyNames.TagInstance] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void EnterText<T>(PropertyType type, string propertyvalue, string text) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;

            Keyboard.SendKeys(genericControl, text);

        }
        private BrowserWindow mparentwindow { get; set; }
        public enum PropertyType
        {
            Id,
            Name,
            InnerText,
            TagInstance
        }
        public BrowserWindow TopParentWindow()
        {

            BrowserWindow window = new BrowserWindow();
            window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
            return window;
        }
        public BrowserWindow ParentWindow
        {
            get
            {
                if (this.mparentwindow == null)
                {
                    this.mparentwindow = TopParentWindow();
                }
                return this.mparentwindow;
            }
        }





    }
}
