﻿using AutoItX3Lib;
using DataDrivenTesting;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace iPAS_ReceivingQCTestMethods
{
    class ReceivingQCTestMethods
    {
        string minsleep = ConfigurationSettings.AppSettings["min"];
        string midsleep = ConfigurationSettings.AppSettings["mid"];
        string maxsleep = ConfigurationSettings.AppSettings["max"];
        LanguageResouceTemplate languageResource = new LanguageResouceTemplate();
        public void ReceivingQCTest()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "lnkAdmin");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkGRIndex");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkQCMaster");
            auto.MouseClick();
            Thread.Sleep(min);
            auto.Send("F5");
            Thread.Sleep(mid);
            /*****************************clicking on the Download and Uploading Button**************/
            try
            {

                Click<HtmlSpan>(PropertyType.InnerText, "Receiving QC Test Methods");
            }
            catch (Exception e)
            {
                Click<HtmlSpan>(PropertyType.InnerText, "Receiving QC Test Methods");
            }
            Thread.Sleep(min);
            int xCoodinate = auto.MouseGetPosX();
            int yCoodinate = auto.MouseGetPosY();
            xCoodinate = xCoodinate - 310;
            auto.MouseMove(xCoodinate, yCoodinate);
            yCoodinate = yCoodinate + 40;
            auto.MouseMove(xCoodinate, yCoodinate);
            auto.MouseClick();


            Click<HtmlButton>(PropertyType.Id, "btnUploadQCData");
            Click<HtmlFileInput>(PropertyType.Id, "ContentPlaceHolder1_uploadFile");
            PathEnterText<WinEdit>(PropertyType.Name, "File name:", ExcelDataTable.ReadData(1, "filePath"));
            Thread.Sleep(mid);
            /****************Here check Validate File is Uploaded or not******************/
            var data = window.ExecuteScript("var data=document.getElementById('lblUploadError').innerHTML; return data;");
            string msg = data.ToString().Trim();
            if (msg!="")
            {
                string screenShotName = "FileIsNotUploaded";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", msg, msg);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void searchUploadedQC()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            try
            {
              EnterText<HtmlEdit>(PropertyType.Id, "txtIDHID", ExcelDataTable.ReadData(1, "IDH"));
            }catch(Exception e) { }
            Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearch");
            Thread.Sleep(mid);
            /*****************Here check Material Number is Enter Or not***/
            var data1 = window.ExecuteScript("var data=document.getElementById('spnSearchError').innerHTML; return data;");
            string msg1 = data1.ToString().Trim();
            bool b = msg1.Equals(languageResource.Msg_PleaseEnterSearchCriteria);

            if (b)
            {
                string screenShotName = "PleaseEnterSearchCriteria";
                screenShot(screenShotName);
            }
            Assert.IsFalse(b, msg1);
            Thread.Sleep(mid);
            /***************Here Click Edit Button update the QC info**************************/
            Click<HtmlHeaderCell>(PropertyType.InnerText, "Action");
            Thread.Sleep(min);
            int xCoodinate1 = auto.MouseGetPosX();
            int yCoodinate1 = auto.MouseGetPosY();
            yCoodinate1 = yCoodinate1 + 30;
            xCoodinate1 = xCoodinate1 - 15;
            auto.MouseMove(xCoodinate1, yCoodinate1);
            Thread.Sleep(min);
            auto.MouseClick();
            Thread.Sleep(max * 2);
        }
        public void updateQC()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            /***************Here Click Edit Button update the QC info**************************/
            Click<HtmlSpan>(PropertyType.InnerText, ExcelDataTable.ReadData(1, "Test Method"));
            Thread.Sleep(min);
            int Mx1 = auto.MouseGetPosX();
            int My1 = auto.MouseGetPosY();
            Mx1 = Mx1 - 120;
            My1 = My1 - 3;
            Thread.Sleep(max);
            auto.MouseMove(Mx1, My1);
            auto.MouseClick();
            Thread.Sleep(max);
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_tmValueTextBox");
                auto.Send("{BACKSPACE 20}");
                auto.Send("{DEL 20}");
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_tmValueTextBox",ExcelDataTable.ReadData(1, "UpdateTest Method"));
            }
            catch (Exception e) { }
                try
                {
                Click<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_labDetailsTextBox");
                auto.Send("{BACKSPACE 20}");
                auto.Send("{DEL 20}");
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_labDetailsTextBox", ExcelDataTable.ReadData(1, "UpdateDetails (Parameter + Inspection Methods)"));

            }
            catch (Exception e) { }
                try
                {
                Click<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_expectedOutputTextBox");
                auto.Send("{BACKSPACE 20}");
                auto.Send("{DEL 20}");
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_expectedOutputTextBox", ExcelDataTable.ReadData(1, "UpdateExpected Output"));
            }
            catch (Exception) { }
                try
                {
                Click<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_highValueTextBox");
                auto.Send("{BACKSPACE 20}");
                auto.Send("{DEL 20}");
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_highValueTextBox", ExcelDataTable.ReadData(1, "UpdateHigh"));
            }
            catch (Exception e) { }
                try
                {
                Click<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_lowValueTextBox");
                auto.Send("{BACKSPACE 20}");
                auto.Send("{DEL 20}");
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_lowValueTextBox", ExcelDataTable.ReadData(1, "UpdateLow"));
                
            }
            catch (Exception e) { }
            /***************Qc Note Field is mandatory********************************/
            try {
                Click<HtmlTextArea>(PropertyType.Id, "ContentPlaceHolder1_qcNoteTextArea");
                auto.Send("{BACKSPACE 30}");
                auto.Send("{DEL 30}");
                EnterText<HtmlTextArea>(PropertyType.Id, "ContentPlaceHolder1_qcNoteTextArea", ExcelDataTable.ReadData(1, "UpdateAdditional QC Notes"));
            }catch(Exception e)
            {
                string QCNote = ExcelDataTable.ReadData(1, "UpdateAdditional QC Notes");
                QCNote=QCNote.Trim();
                if (QCNote.Equals(""))
                {
                  QCNote = null;

                    if (QCNote==null)
                    {
                        string screenShotName = "PleaseFillTheQC_NoteInExcelFile";
                        screenShot(screenShotName);
                    }
                    Assert.IsNotNull(QCNote, "Please Fill the QC Note in Excel File");
                }

            }
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnCreateMaterialQC");
            Thread.Sleep(mid);
            /*************************Here validate updated successfully****************/

            var data1 = window.ExecuteScript("var data=document.getElementById('spnMethodMessage').innerHTML; return data;");
            string msg1 = data1.ToString().Trim();
            if (languageResource.Msg_QCMethodUpdatedSuccessfully!= msg1)
            {
                string screenShotName = "QCMethodUpdated_NotSuccessfully";
                screenShot(screenShotName);
            }
            Assert.AreEqual(languageResource.Msg_QCMethodUpdatedSuccessfully, msg1,msg1);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void deleteUploadedQC()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            /***************Here Click Edit Button update the QC info**************************/
            Click<HtmlSpan>(PropertyType.InnerText, ExcelDataTable.ReadData(1, "UpdateTest Method"));
            Thread.Sleep(min);
            int Mx1 = auto.MouseGetPosX();
            int My1 = auto.MouseGetPosY();
            Mx1 = Mx1 - 115;
            My1 = My1 - 3;
            Thread.Sleep(max);
            auto.MouseMove(Mx1, My1);
            auto.MouseClick();
            Thread.Sleep(min);
            auto.Send("{ENTER}");
            Thread.Sleep(max);           
            auto.Send("{F5}");
            Thread.Sleep(mid);          
            try
            {
                Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearchAll");
            }catch(Exception e) { }
            Thread.Sleep(max);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void downloadExcelTemplate()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            // Click<HtmlHyperlink>(PropertyType.Id, "lnkManageResource");
            // auto.Send("{F5}");
            try
            {

                Click<HtmlSpan>(PropertyType.InnerText, "Receiving QC Test Methods");
            }
            catch (Exception e)
            {
                Click<HtmlSpan>(PropertyType.InnerText, "Receiving QC Test Methods");
            }
            Thread.Sleep(min);
            int xCoodinate = auto.MouseGetPosX();
            int yCoodinate = auto.MouseGetPosY();
            xCoodinate = xCoodinate - 310;
            auto.MouseMove(xCoodinate, yCoodinate);
            yCoodinate = yCoodinate + 40;
            auto.MouseMove(xCoodinate, yCoodinate);
            auto.MouseClick();

            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "btnDownloadTemplate");
            Thread.Sleep(max * 2);
            Click<HtmlDiv>(PropertyType.Id, "footer");
            try {
                WindowButtonClick<WinToolBar>(PropertyType.Name, "Notification");
                WindowButtonClick<WinButton>(PropertyType.Name, "Open");
            }catch(Exception e) { }
            mparentwindow = null;
            Thread.Sleep(max * 17);
            auto.WinClose("Microsoft Excel");
            auto.WinClose("Excel");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void downloadTestMethod()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlCustom>(PropertyType.Id, "ContentPlaceHolder1_btnDownloadQCData");
            Thread.Sleep(max * 15);
            Click<HtmlDiv>(PropertyType.Id, "footer");
            try {
                WindowButtonClick<WinToolBar>(PropertyType.Name, "Notification");
                WindowButtonClick<WinButton>(PropertyType.Name, "Open");
            }catch(Exception e) { }
            mparentwindow = null;
            Thread.Sleep(max * 17);
            auto.WinClose("Microsoft Excel");
            auto.WinClose("Excel");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void pageNavigator()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlDiv>(PropertyType.Id, "footer");
            //try
            //{
            //    var pageCount = window.ExecuteScript("var data=document.getElementById('ctl01_divPager').getElementsByTagName('a');  return  data.length");
            //    string len = pageCount.ToString();
            //    int length = Convert.ToInt32(len);
            //    for (int i = 1; i <= length; i++)
            //    {
            //        string tagId = "ctl01_hrefNum" + i;
            //        Thread.Sleep(mid);
            //        if (i == 7)
            Click<HtmlHyperlink>(PropertyType.Id, "ctl01_hrefLast");
            Thread.Sleep(max);
            validation();
            Thread.Sleep(min);
            //    tagId = "";
            //}
            //}
            //catch (Exception e) { }

        }

        public void validation()
        {
            BrowserWindow window = new BrowserWindow();
            Thread.Sleep(1000);
            var len = window.ExecuteScript("var data=document.getElementById('ContentPlaceHolder1_tbQCMaster').getElementsByTagName('td');  return  data.length");
            string length = len.ToString().Trim();
            int Data = Convert.ToInt32(length);
            bool flag = true;
            if (Data == 0)
                flag = false;

            string error = "Data is Not there On Last Navigate page";
            if (!flag)
            {
                string screenShotName = "DataIsNotThere_LastNavigatePage";
                screenShot(screenShotName);
            }
            Assert.IsTrue(flag, error);
        }
        public void screenShot(string imgName)
        {
            BrowserWindow window = new BrowserWindow();
            string path = ConfigurationSettings.AppSettings["ScreenShot"];
            path = path + @"\\iPAS_ReceivingQCTestMethods";
            Directory.CreateDirectory(path);
            try
            {
                window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
                Image image = window.CaptureImage();
                image.Save(path + "\\" + imgName + ".jpeg", ImageFormat.Jpeg);
                image.Dispose();
            }
            catch (Exception e) { }
            Console.WriteLine("Screen Shot is Avaliable in " + path + "\t" + "Folder");
        }
        public void WindowButtonClick<T>(PropertyType type, string propertyvalue) where T : WinControl
        {
            WinControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Name)
                genericControl.SearchProperties[WinControl.PropertyNames.Name] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void PathEnterText<T>(PropertyType type, string propertyvalue, string text) where T : WinEdit
        {
            WinEdit genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            genericControl.FilterProperties[WinEdit.PropertyNames.Name] = propertyvalue;
            AutoItX3 auto = new AutoItX3();
            auto.WinActivate("Choose File to Upload");
            auto.Send(text);
            auto.Send("{ENTER}");
            Thread.Sleep(1000);
        }

        public void Click<T>(PropertyType type, string propertyvalue) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });

            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;
            else if (type == PropertyType.InnerText)
            {
                genericControl.SearchProperties[HtmlControl.PropertyNames.InnerText] = propertyvalue;
            }
            else if (type == PropertyType.TagInstance)
                genericControl.FilterProperties[HtmlControl.PropertyNames.TagInstance] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void EnterText<T>(PropertyType type, string propertyvalue, string text) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;

            Keyboard.SendKeys(genericControl, text);

        }
        private BrowserWindow mparentwindow { get; set; }
        public enum PropertyType
        {
            Id,
            Name,
            InnerText,
            TagInstance
        }
        public BrowserWindow TopParentWindow()
        {

            BrowserWindow window = new BrowserWindow();
            window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
            return window;
        }
        public BrowserWindow ParentWindow
        {
            get
            {
                if (this.mparentwindow == null)
                {
                    this.mparentwindow = TopParentWindow();
                }
                return this.mparentwindow;
            }
        }
    }
}
