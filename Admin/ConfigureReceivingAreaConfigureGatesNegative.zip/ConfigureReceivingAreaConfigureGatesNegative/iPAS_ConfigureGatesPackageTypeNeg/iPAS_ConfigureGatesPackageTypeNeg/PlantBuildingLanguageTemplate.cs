﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Text;
using System.Threading.Tasks;

namespace iPAS_ConfigureGatesNegative
{
    class PlantBuildingLanguageTemplate
    {
        static CultureInfo ci = null;
        static ResourceManager rm = null;
        static string resMsg_EnterBuildingName = string.Empty;
        public string Msg_EnterBuildingName
        {
            get { return resMsg_EnterBuildingName; }
            set { resMsg_EnterBuildingName = value; }
        }
        public static void messageResource(string languageCode)
        {
            if (languageCode == "zh-CN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ConfigureGatesPackageTypeNeg.resource.PlantBuildingCN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "th-TH")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ConfigureGatesPackageTypeNeg.resource.PlantBuildingTH", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "vi-VN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ConfigureGatesPackageTypeNeg.resource.PlantBuildingVN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "ko-KR")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ConfigureGatesPackageTypeNeg.resource.PlantBuildingKR", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "ja-JP")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ConfigureGatesPackageTypeNeg.resource.PlantBuildingJP", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "id-ID")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ConfigureGatesPackageTypeNeg.resource.PlantBuildingID", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ConfigureGatesPackageTypeNeg.resource.PlantBuildingEN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
        }
        public static void messageInitialize()
        {
            resMsg_EnterBuildingName = rm.GetString("resMsg_EnterBuildingName", ci).Trim();
        }
    }
}
