﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Text;
using System.Threading.Tasks;

namespace iPAS_ConfigureGatesNegative
{
    class PlantGateLanguageTemplate
    {
        static CultureInfo ci = null;
        static ResourceManager rm = null;
        static string resMsg_EnterGateName = string.Empty;
        public string Msg_EnterGateName
        {
            get { return resMsg_EnterGateName; }
            set { resMsg_EnterGateName = value; }
        }

        static string resMsg_SelectBuildingName = string.Empty;
        public string Msg_SelectBuildingName
        {
            get { return resMsg_SelectBuildingName; }
            set { resMsg_SelectBuildingName = value; }
        }
        static string resMsg_EnterTrucksWaitingMinutes = string.Empty;
        public string Msg_EnterTrucksWaitingMinutes
        {
            get { return resMsg_EnterTrucksWaitingMinutes; }
            set { resMsg_EnterTrucksWaitingMinutes = value; }
        }        
        public static void messageResource(string languageCode)
        {
            if (languageCode == "zh-CN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ConfigureGatesPackageTypeNeg.resource.PlantGateCN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "th-TH")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ConfigureGatesPackageTypeNeg.resource.PlantGateTH", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "vi-VN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ConfigureGatesPackageTypeNeg.resource.PlantGateVN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "ko-KR")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ConfigureGatesPackageTypeNeg.resource.PlantGateKR", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "ja-JP")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ConfigureGatesPackageTypeNeg.resource.PlantGateJP", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "id-ID")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ConfigureGatesPackageTypeNeg.resource.PlantGateID", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ConfigureGatesPackageTypeNeg.resource.PlantGateEN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
        }
        public static void messageInitialize()
        {
            resMsg_EnterGateName = rm.GetString("resMsg_EnterGateName", ci).Trim(); 
            resMsg_SelectBuildingName = rm.GetString("resMsg_SelectBuildingName", ci).Trim();
            resMsg_EnterTrucksWaitingMinutes = rm.GetString("resMsg_EnterTrucksWaitingMinutes", ci).Trim();
        }
    }
}
