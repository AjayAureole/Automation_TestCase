﻿using AutoItX3Lib;
using DataDrivenTesting;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace iPAS_ConfigureGatesNegative
{
    class ConfigureGatesNegative
    {
        string minsleep = ConfigurationSettings.AppSettings["min"];
        string midsleep = ConfigurationSettings.AppSettings["mid"];
        string maxsleep = ConfigurationSettings.AppSettings["max"];
        PlantBuildingLanguageTemplate plantBuildingLanguage = new PlantBuildingLanguageTemplate();
        PlantGateLanguageTemplate plantGateLanguage = new PlantGateLanguageTemplate();
        public void ConfigureGates()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "lnkAdmin");
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkGRIndex");
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkBuilding");
            Thread.Sleep(min);
            auto.MouseClick();
            Thread.Sleep(max);
            auto.Send("{F5}");
            Thread.Sleep(max);


            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnAddBuilding");
            Thread.Sleep(mid);
            var data = window.ExecuteScript("var data=document.getElementById('spnAddBuildingError').innerHTML;  return  data");
            string successMsg = data.ToString().Trim();
            successMsg = successMsg.Replace("<br>","");
            if (plantBuildingLanguage.Msg_EnterBuildingName != successMsg)
            {
                string screenShotName = "BuildingAddNot_Success";
                screenShot(screenShotName);
            }
            Assert.AreEqual(plantBuildingLanguage.Msg_EnterBuildingName, successMsg, successMsg);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void plantGatesTab()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "lnkPlantGate");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            auto.Send("{Down}");
            Thread.Sleep(mid);
            auto.Send("{Down}");
            auto.Send("{Down}");
            Thread.Sleep(mid);
            auto.Send("{Down}");
            auto.Send("{Down}");
            Thread.Sleep(mid);
            auto.Send("{Down}");
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnAddGate");
            Thread.Sleep(mid);
            var data1 = window.ExecuteScript("var data=document.getElementById('spnGateError').innerHTML;  return  data");
            string successMsg1 = data1.ToString().Trim();
            successMsg1 = successMsg1.Replace("<br>", "");
            string MakeMSG = plantGateLanguage.Msg_EnterGateName + plantGateLanguage.Msg_SelectBuildingName;
            if (MakeMSG != successMsg1)
            {
                string screenShotName = "GateInfo_NotUpdated";
                screenShot(screenShotName);
            }
            Assert.AreEqual(MakeMSG, successMsg1, successMsg1);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }

        public void TrucksWaiting()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "txtWaitMinute");
                Thread.Sleep(mid);
                auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                auto.Send("{DEL 20}");
            }
            catch(Exception e) { }
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnSaveTruckWait");
            Thread.Sleep(mid);
            var data = window.ExecuteScript("var data=document.getElementById('spnErrorMessage').innerHTML;  return  data");
            string successMsg = data.ToString().Trim();
            if (plantGateLanguage.Msg_EnterTrucksWaitingMinutes != successMsg)
            {
                string screenShotName = "TrucksWaitingMinutes_MSGIsNotProper";
                screenShot(screenShotName);
            }
            Assert.AreEqual(plantGateLanguage.Msg_EnterTrucksWaitingMinutes, successMsg, successMsg);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
      

        public void screenShot(string imgName)
        {
            BrowserWindow window = new BrowserWindow();
            string path = ConfigurationSettings.AppSettings["ScreenShot"];
            path = path + @"\\iPAS_ConfigureGatesNegative";
            Directory.CreateDirectory(path);
            try
            {
                window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
                Image image = window.CaptureImage();
                image.Save(path + "\\" + imgName + ".jpeg", ImageFormat.Jpeg);
                image.Dispose();
            }
            catch (Exception e) { }
            Console.WriteLine("Screen Shot is Avaliable in " + path + "\t" + "Folder");
        }
        public void PathEnterText<T>(PropertyType type, string propertyvalue, string text) where T : WinEdit
        {
            WinEdit genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            genericControl.FilterProperties[WinEdit.PropertyNames.Name] = propertyvalue;
            AutoItX3 auto = new AutoItX3();
            auto.WinActivate("Choose File to Upload");
            auto.Send(text);
            auto.Send("{ENTER}");
            Thread.Sleep(1000);
        }
        public void WindowButtonClick<T>(PropertyType type, string propertyvalue) where T : WinControl
        {
            WinControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Name)
                genericControl.SearchProperties[WinControl.PropertyNames.Name] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void Click<T>(PropertyType type, string propertyvalue) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });

            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;
            else if (type == PropertyType.InnerText)
            {
                genericControl.SearchProperties[HtmlControl.PropertyNames.InnerText] = propertyvalue;
            }
            else if (type == PropertyType.TagInstance)
                genericControl.FilterProperties[HtmlControl.PropertyNames.TagInstance] = propertyvalue;
            else if (type == PropertyType.Class)
                genericControl.FilterProperties[HtmlControl.PropertyNames.Class] = propertyvalue;


            Mouse.Click(genericControl);
        }
        public void EnterText<T>(PropertyType type, string propertyvalue, string text) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;


            Keyboard.SendKeys(genericControl, text);

        }
        private BrowserWindow mparentwindow { get; set; }
        public enum PropertyType
        {
            Id,
            Name,
            InnerText,
            TagInstance,
            Class
        }
        public BrowserWindow TopParentWindow()
        {

            BrowserWindow window = new BrowserWindow();
            window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
            return window;
        }
        public BrowserWindow ParentWindow
        {
            get
            {
                if (this.mparentwindow == null)
                {
                    this.mparentwindow = TopParentWindow();
                }
                return this.mparentwindow;
            }
        }
    }
}
