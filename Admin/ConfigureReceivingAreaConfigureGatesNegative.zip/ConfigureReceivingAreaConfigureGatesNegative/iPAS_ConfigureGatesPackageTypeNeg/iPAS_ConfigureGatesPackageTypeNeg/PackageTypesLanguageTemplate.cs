﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Text;
using System.Threading.Tasks;

namespace iPAS_ConfigureGatesNegative
{
    class PackageTypesLanguageTemplate
    {
        static CultureInfo ci = null;
        static ResourceManager rm = null; 
        static string resMsg_PleaseEnterPackageName = string.Empty;
        public string Msg_PleaseEnterPackageName
        {
            get { return resMsg_PleaseEnterPackageName; }
            set { resMsg_PleaseEnterPackageName = value; }
        }
        static string resMsg_login_msg = string.Empty;
        public string Msg_login_msg
        {
            get { return resMsg_login_msg; }
            set { resMsg_login_msg = value; }
        }

        public static void messageResource(string languageCode)
        {
            if (languageCode == "zh-CN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ConfigureGatesPackageTypeNeg.resource.PackageTypeCN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "th-TH")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ConfigureGatesPackageTypeNeg.resource.PackageTypeTH", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "vi-VN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ConfigureGatesPackageTypeNeg.resource.PackageTypeVN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "ko-KR")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ConfigureGatesPackageTypeNeg.resource.PackageTypeKR", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "ja-JP")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ConfigureGatesPackageTypeNeg.resource.PackageTypeJP", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "id-ID")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ConfigureGatesPackageTypeNeg.resource.PackageTypeID", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ConfigureGatesPackageTypeNeg.resource.PackageTypeEN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
        }
        public static void messageInitialize()
        {
            resMsg_PleaseEnterPackageName = rm.GetString("resMsg_PleaseEnterPackageName", ci).Trim();
            resMsg_login_msg = rm.GetString("resMsg_login_msg", ci).Trim(); 

                }
    }
}
