﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Text;
using System.Threading.Tasks;

namespace iPAS_AdditionalMaterialInfoNegative
{
    class ManageMaterialInfoLanguageTemplate
    {
        static CultureInfo ci = null;
        static ResourceManager rm = null;
        static string resMsg_InvalidFileFormat = string.Empty; 
        public string Msg_InvalidFileFormat
        {
            get { return resMsg_InvalidFileFormat; }
            set { resMsg_InvalidFileFormat = value; }
        }
        static string resMsg_NoRecordsFound = string.Empty;
        public string Msg_NoRecordsFound
        {
            get { return resMsg_NoRecordsFound; }
            set { resMsg_NoRecordsFound = value; }
        }
        static string resMsg_SelectUploadType = string.Empty;
        public string Msg_SelectUploadType
        {
            get { return resMsg_SelectUploadType; }
            set { resMsg_SelectUploadType = value; }
        }        
        static string resMsg_Msg_login_msg = string.Empty;
        public string Msg_login_msg
        {
            get { return resMsg_Msg_login_msg; }
            set { resMsg_Msg_login_msg = value; }
        }
        static string resMsg_EnterSearchCriteria = string.Empty;
        public string Msg_EnterSearchCriteria
        {
            get { return resMsg_EnterSearchCriteria; }
            set { resMsg_EnterSearchCriteria = value; }
        }
        public static void messageResource(string languageCode)
        {
            if (languageCode == "zh-CN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_AdditionalMaterialInfoNegative.resource.ManageMaterialInfoCN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "th-TH")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_AdditionalMaterialInfoNegative.resource.ManageMaterialInfoTH", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "vi-VN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_AdditionalMaterialInfoNegative.resource.ManageMaterialInfoVN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "ko-KR")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_AdditionalMaterialInfoNegative.resource.ManageMaterialInfoKR", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "ja-JP")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_AdditionalMaterialInfoNegative.resource.ManageMaterialInfoJP", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "id-ID")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_AdditionalMaterialInfoNegative.resource.ManageMaterialInfoID", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_AdditionalMaterialInfoNegative.resource.ManageMaterialInfoEN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
        }
        public static void messageInitialize()
        {
            resMsg_InvalidFileFormat = rm.GetString("resMsg_InvalidFileFormat", ci).Trim(); 
             resMsg_NoRecordsFound = rm.GetString("resMsg_NoRecordsFound", ci).Trim();
            resMsg_SelectUploadType = rm.GetString("resMsg_SelectUploadType", ci).Trim();
            resMsg_Msg_login_msg = rm.GetString("resMsg_Msg_login_msg", ci).Trim();
            resMsg_EnterSearchCriteria = rm.GetString("resMsg_EnterSearchCriteria", ci).Trim();

        }
    }
}
