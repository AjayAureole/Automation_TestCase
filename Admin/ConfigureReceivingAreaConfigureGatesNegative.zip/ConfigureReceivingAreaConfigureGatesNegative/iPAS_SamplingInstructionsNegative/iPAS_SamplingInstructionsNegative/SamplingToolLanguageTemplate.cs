﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Text;
using System.Threading.Tasks;

namespace iPAS_SamplingInstructionsNegative
{
    class SamplingToolLanguageTemplate
    {
        static CultureInfo ci = null;
        static ResourceManager rm = null;
        static string resMsg_InvalidImageFormat = string.Empty;
        public string Msg_InvalidImageFormat
        {
            get { return resMsg_InvalidImageFormat; }
            set { resMsg_InvalidImageFormat = value; }
        }
        
        static string reMSG_LoginMSG = string.Empty;
        public string MSG_LoginMSG
        {
            get { return reMSG_LoginMSG; }
            set { reMSG_LoginMSG = value; }
        }
        static string resMsg_EnterSamplingToolName = string.Empty;
        public string Msg_EnterSamplingToolName
        {
            get { return resMsg_EnterSamplingToolName; }
            set { resMsg_EnterSamplingToolName = value; }
        }
        public static void messageResource(string languageCode)
        {
            if (languageCode == "zh-CN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_SamplingInstructionsNegative.resource.SamplingToolCN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "th-TH")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_SamplingInstructionsNegative.resource.SamplingToolTH", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "vi-VN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_SamplingInstructionsNegative.resource.SamplingToolVN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "ko-KR")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_SamplingInstructionsNegative.resource.SamplingToolKR", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "ja-JP")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_SamplingInstructionsNegative.resource.SamplingToolJP", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "id-ID")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_SamplingInstructionsNegative.resource.SamplingToolID", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_SamplingInstructionsNegative.resource.SamplingToolEN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
        }
        public static void messageInitialize()
        {
            resMsg_InvalidImageFormat = rm.GetString("resMsg_InvalidImageFormat", ci).Trim();
            reMSG_LoginMSG = rm.GetString("reMSG_LoginMSG", ci).Trim();
            resMsg_EnterSamplingToolName = rm.GetString("resMsg_EnterSamplingToolName", ci).Trim();

    }
}
}
