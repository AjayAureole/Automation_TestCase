﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Text;
using System.Threading.Tasks;

namespace iPAS_SamplingInstructionsNegative
{
    class SamplingInstructionsLanguageTemplate
    {
        static CultureInfo ci = null;
        static ResourceManager rm = null;
        static string resMsg_InvalidFileFormat = string.Empty;
        public string Msg_InvalidFileFormat
        {
            get { return resMsg_InvalidFileFormat; }
            set { resMsg_InvalidFileFormat = value; }
        }
        static string resMsg_EnterSearchCriteria = string.Empty;
        public string Msg_EnterSearchCriteria
        {
            get { return resMsg_EnterSearchCriteria; }
            set { resMsg_EnterSearchCriteria = value; }
        }
        static string resMsg_NoRecordsFound = string.Empty;
        public string Msg_NoRecordsFound
        {
            get { return resMsg_NoRecordsFound; }
            set { resMsg_NoRecordsFound = value; }
        }
        public static void messageResource(string languageCode)
        {
            if (languageCode == "zh-CN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_SamplingInstructionsNegative.resource.SamplingInstructionsCN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "th-TH")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_SamplingInstructionsNegative.resource.SamplingInstructionsTH", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "vi-VN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_SamplingInstructionsNegative.resource.SamplingInstructionsVN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "ko-KR")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_SamplingInstructionsNegative.resource.SamplingInstructionsKR", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "ja-JP")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_SamplingInstructionsNegative.resource.SamplingInstructionsJP", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "id-ID")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_SamplingInstructionsNegative.resource.SamplingInstructionsID", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_SamplingInstructionsNegative.resource.SamplingInstructionsEN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
        }
        public static void messageInitialize()
        {
            resMsg_InvalidFileFormat = rm.GetString("resMsg_InvalidFileFormat", ci).Trim();
            resMsg_EnterSearchCriteria = rm.GetString("resMsg_EnterSearchCriteria", ci).Trim();
            resMsg_NoRecordsFound = rm.GetString("resMsg_NoRecordsFound", ci).Trim();
        }
    }
}
