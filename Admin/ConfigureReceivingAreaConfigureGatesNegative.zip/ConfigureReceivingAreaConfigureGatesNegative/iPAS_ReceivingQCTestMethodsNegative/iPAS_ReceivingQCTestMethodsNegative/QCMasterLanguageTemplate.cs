﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Text;
using System.Threading.Tasks;

namespace iPAS_ReceivingQCTestMethodsNegative
{
    class QCMasterLanguageTemplate
    {
        static CultureInfo ci = null;
        static ResourceManager rm = null;
        static string resMsg_InvalidFileFormat = string.Empty;
        public string Msg_InvalidFileFormat
        {
            get { return resMsg_InvalidFileFormat; }
            set { resMsg_InvalidFileFormat = value; }
        }
        static string resMsg_NoRecordsFound = string.Empty;
        public string Msg_NoRecordsFound
        {
            get { return resMsg_NoRecordsFound; }
            set { resMsg_NoRecordsFound = value; }
        }
        static string resMsg_PleaseEnterSearchCriteria = string.Empty;
        public string Msg_PleaseEnterSearchCriteria
        {
            get { return resMsg_PleaseEnterSearchCriteria; }
            set { resMsg_PleaseEnterSearchCriteria = value; }
        }
        static string resMsg_LoginMsg = string.Empty;
        public string Msg_LoginMsg
        {
            get { return resMsg_LoginMsg; }
            set { resMsg_LoginMsg = value; }
        }
        public static void messageResource(string languageCode)
        {
            if (languageCode == "zh-CN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ReceivingQCTestMethodsNegative.resource.QCMasterCN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "th-TH")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ReceivingQCTestMethodsNegative.resource.QCMasterTH", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "vi-VN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ReceivingQCTestMethodsNegative.resource.QCMasterVN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "ko-KR")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ReceivingQCTestMethodsNegative.resource.QCMasterKR", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "ja-JP")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ReceivingQCTestMethodsNegative.resource.QCMasterJP", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "id-ID")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ReceivingQCTestMethodsNegative.resource.QCMasterID", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ReceivingQCTestMethodsNegative.resource.QCMasterEN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
        }
        public static void messageInitialize()
        {
            resMsg_InvalidFileFormat = rm.GetString("resMsg_InvalidFileFormat", ci).Trim();
            resMsg_NoRecordsFound = rm.GetString("resMsg_NoRecordsFound", ci).Trim(); 
             resMsg_PleaseEnterSearchCriteria = rm.GetString("resMsg_PleaseEnterSearchCriteria", ci).Trim();
            resMsg_LoginMsg = rm.GetString("resMsg_LoginMsg", ci).Trim();

        }
    }
}
