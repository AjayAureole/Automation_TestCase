﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Text;
using System.Threading.Tasks;

namespace iPAS_VendorQuesAndForwarderNegative
{
    class ForwarderLanguageTemplate
    {
        static CultureInfo ci = null;
        static ResourceManager rm = null;
        static string resMsg_EnterForwarderName = string.Empty;
        public string Msg_EnterForwarderName
        {
            get { return resMsg_EnterForwarderName; }
            set { resMsg_EnterForwarderName = value; }
        }
        static string resMsg_EnterSearchCriteria = string.Empty;
        public string Msg_EnterSearchCriteria
        {
            get { return resMsg_EnterSearchCriteria; }
            set { resMsg_EnterSearchCriteria = value; }
        }
        static string resMsg_LoginMsg = string.Empty;
        public string Msg_LoginMsg
        {
            get { return resMsg_LoginMsg; }
            set { resMsg_LoginMsg = value; }
        }

        public static void messageResource(string languageCode)
        {
            if (languageCode == "zh-CN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_VendorQuesAndForwarderNegative.resource.ForwarderCN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "th-TH")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_VendorQuesAndForwarderNegative.resource.ForwarderTH", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "vi-VN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_VendorQuesAndForwarderNegative.resource.ForwarderVN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "ko-KR")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_VendorQuesAndForwarderNegative.resource.ForwarderKR", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "ja-JP")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_VendorQuesAndForwarderNegative.resource.ForwarderJP", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "id-ID")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_VendorQuesAndForwarderNegative.resource.ForwarderID", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_VendorQuesAndForwarderNegative.resource.ForwarderEN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
        }
        public static void messageInitialize()
        {
            resMsg_EnterForwarderName = rm.GetString("resMsg_EnterForwarderName", ci).Trim();
            resMsg_EnterSearchCriteria = rm.GetString("resMsg_EnterSearchCriteria", ci).Trim();
            resMsg_LoginMsg = rm.GetString("resMsg_LoginMsg", ci).Trim();
        }
    }
}
