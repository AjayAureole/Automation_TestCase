﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Text;
using System.Threading.Tasks;

namespace iPAS_VendorQuesAndForwarderNegative
{
    class VendorQuestionaryLanguageTemplate
    {
        static CultureInfo ci = null;
        static ResourceManager rm = null;
        static string resMsg_PleaseEnterQuestion = string.Empty;
        public string Msg_PleaseEnterQuestion
        {
            get { return resMsg_PleaseEnterQuestion; }
            set { resMsg_PleaseEnterQuestion = value; }
        }
        
        public static void messageResource(string languageCode)
        {
            if (languageCode == "zh-CN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_VendorQuesAndForwarderNegative.resource.VendorQuestionaryCN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "th-TH")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_VendorQuesAndForwarderNegative.resource.VendorQuestionaryTH", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "vi-VN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_VendorQuesAndForwarderNegative.resource.VendorQuestionaryVN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "ko-KR")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_VendorQuesAndForwarderNegative.resource.VendorQuestionaryKR", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "ja-JP")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_VendorQuesAndForwarderNegative.resource.VendorQuestionaryJP", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "id-ID")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_VendorQuesAndForwarderNegative.resource.VendorQuestionaryID", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_VendorQuesAndForwarderNegative.resource.VendorQuestionaryEN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
        }
        public static void messageInitialize()
        {
            resMsg_PleaseEnterQuestion = rm.GetString("resMsg_PleaseEnterQuestion", ci).Trim();
        }
    }
}
