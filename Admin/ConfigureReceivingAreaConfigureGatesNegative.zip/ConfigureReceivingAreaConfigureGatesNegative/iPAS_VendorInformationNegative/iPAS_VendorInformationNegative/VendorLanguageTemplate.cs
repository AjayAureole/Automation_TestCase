﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Text;
using System.Threading.Tasks;

namespace iPAS_VendorInformationNegative
{
    class VendorLanguageTemplate
    {
        static CultureInfo ci = null;
        static ResourceManager rm = null;
        static string resMsg_InvalidFormat = string.Empty;
        public string Msg_InvalidFormat
        {
            get { return resMsg_InvalidFormat; }
            set { resMsg_InvalidFormat = value; }
        }
        static string resMsg_PleaseDefineSearchCriteria = string.Empty;
        public string Msg_PleaseDefineSearchCriteria
        {
            get { return resMsg_PleaseDefineSearchCriteria; }
            set { resMsg_PleaseDefineSearchCriteria = value; }
        }
        static string resMsg_LoginMsg = string.Empty;
        public string Msg_LoginMsg
        {
            get { return resMsg_LoginMsg; }
            set { resMsg_LoginMsg = value; }
        }
        static string resMsg_NoRecordFound = string.Empty;
        public string Msg_NoRecordFound
        {
            get { return resMsg_NoRecordFound; }
            set { resMsg_NoRecordFound = value; }
        }
        static string resMsg_EnterVendorCode = string.Empty;
        public string Msg_EnterVendorCode
        {
            get { return resMsg_EnterVendorCode; }
            set { resMsg_EnterVendorCode = value; }
        }
        static string resMsg_EnterVendorName = string.Empty;
        public string Msg_EnterVendorName
        {
            get { return resMsg_EnterVendorName; }
            set { resMsg_EnterVendorName = value; }
        }
        static string resMsg_EnterValidEmailId = string.Empty;
        public string Msg_EnterValidEmailId
        {
            get { return resMsg_EnterValidEmailId; }
            set { resMsg_EnterValidEmailId = value; }
        }


        public static void messageResource(string languageCode)
        {
            if (languageCode == "zh-CN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_VendorInformationNegative.resource.VendorCN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "th-TH")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_VendorInformationNegative.resource.VendorTH", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "vi-VN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_VendorInformationNegative.resource.VendorVN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "ko-KR")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_VendorInformationNegative.resource.VendorKR", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "ja-JP")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_VendorInformationNegative.resource.VendorJP", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "id-ID")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_VendorInformationNegative.resource.VendorID", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_VendorInformationNegative.resource.VendorEN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
        }
        public static void messageInitialize()
        {
            resMsg_InvalidFormat = rm.GetString("resMsg_InvalidFormat", ci).Trim();
            resMsg_PleaseDefineSearchCriteria = rm.GetString("resMsg_PleaseDefineSearchCriteria", ci).Trim();
            resMsg_LoginMsg = rm.GetString("resMsg_LoginMsg", ci).Trim();
            resMsg_NoRecordFound = rm.GetString("resMsg_NoRecordFound", ci).Trim();
            resMsg_EnterVendorCode = rm.GetString("resMsg_EnterVendorCode", ci).Trim();
            resMsg_EnterVendorName = rm.GetString("resMsg_EnterVendorName", ci).Trim();
            resMsg_EnterValidEmailId = rm.GetString("resMsg_EnterValidEmailId", ci).Trim();

        }
    }
}
