﻿using AutoItX3Lib;
using DataDrivenTesting;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace iPAS_MaterialDGCharectersNegative
{
    class MaterialDGCharectersNegative
    {
        string minsleep = ConfigurationSettings.AppSettings["min"];
        string midsleep = ConfigurationSettings.AppSettings["mid"];
        string maxsleep = ConfigurationSettings.AppSettings["max"];
        ManageIDHDetailsLanguageTemplate IDHLanguage = new ManageIDHDetailsLanguageTemplate();
        CreateIDHCharactersLanguageTemplate createIDHLan = new CreateIDHCharactersLanguageTemplate();
        public void invalidFileFormat()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);

            Click<HtmlHyperlink>(PropertyType.Id, "lnkAdmin");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkGRIndex");
            Thread.Sleep(min);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkIDH");
            auto.Sleep(min);
            auto.MouseClick();
            Thread.Sleep(mid);
            auto.Send("F5");
            Thread.Sleep(mid);
            /**************************Clicking on the download and Uploading Button**********/
            try
            {

                Click<HtmlSpan>(PropertyType.InnerText, "Material DG Characters");
            }
            catch (Exception e)
            {
                Click<HtmlSpan>(PropertyType.InnerText, "Material DG Characters");
            }
            Thread.Sleep(min);
            int xCoodinate = auto.MouseGetPosX();
            int yCoodinate = auto.MouseGetPosY();
            xCoodinate = xCoodinate - 310;
            auto.MouseMove(xCoodinate, yCoodinate);
            yCoodinate = yCoodinate + 40;
            auto.MouseMove(xCoodinate, yCoodinate);
            auto.MouseClick();
            
            /***********************Here uploading invalid file format**********************************/
            Click<HtmlCustom>(PropertyType.Id, "btnUploadData");
            Click<HtmlFileInput>(PropertyType.Id, "ContentPlaceHolder1_uploadFile");
            PathEnterText<WinEdit>(PropertyType.Name, "File name:", ExcelDataTable.ReadData(1, "DG_FilePathWrongFormat"));
            Thread.Sleep(max * 2);

            /****************Here check Validate File is Uploaded or not******************/
            var data3 = window.ExecuteScript("var data=document.getElementById('lblUploadError').innerHTML; return data;");
            string msg3 = data3.ToString().Trim();
            if (msg3 != IDHLanguage.Msg_InvalidFileFormat)
            {
                string screenShotName = "invalidFileFormat";
                screenShot(screenShotName);
            }
            Assert.AreEqual(IDHLanguage.Msg_InvalidFileFormat, msg3, msg3);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void invalidData()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);

            /**************************Clicking on the download and Uploading Button**********/
            try
            {

                Click<HtmlSpan>(PropertyType.InnerText, "Material DG Characters");
            }
            catch (Exception e)
            {
                Click<HtmlSpan>(PropertyType.InnerText, "Material DG Characters");
            }
            Thread.Sleep(min);
            int xCoodinate = auto.MouseGetPosX();
            int yCoodinate = auto.MouseGetPosY();
            xCoodinate = xCoodinate - 310;
            auto.MouseMove(xCoodinate, yCoodinate);
            yCoodinate = yCoodinate + 40;
            auto.MouseMove(xCoodinate, yCoodinate);
            auto.MouseClick();


            /***********************Here uploading invalid Data**********************************/

            Click<HtmlCustom>(PropertyType.Id, "btnUploadData");
            Thread.Sleep(mid);
            Click<HtmlFileInput>(PropertyType.Id, "ContentPlaceHolder1_uploadFile");
            PathEnterText<WinEdit>(PropertyType.Name, "File name:", ExcelDataTable.ReadData(1, "DG_WrongData"));
            Thread.Sleep(max * 15);

            /****************Here check Validate File is Uploaded or not******************/
            var data = window.ExecuteScript("var data=document.getElementById('lblUploadError').innerHTML; return data;");
            string msg = data.ToString().Trim();
            if (msg != "")
            {
                string screenShotName = "invalidData";
                screenShot(screenShotName);
            }
            Assert.AreEqual("", msg, msg);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void SearchData()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);

            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtIDHNumber", ExcelDataTable.ReadData(1, "Material_No"));
            }catch(Exception e) { }
            Thread.Sleep(min);
            Click < HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearch");
            bool b1 = Search();
            if (!b1)
            {
                string screenShotName = "validData";
                screenShot(screenShotName);
            }
            Assert.IsTrue(b1, "This is Valid Data");
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearch");
            Thread.Sleep(mid);
            var data = window.ExecuteScript("var data=document.getElementById('spnSearchError').innerHTML; return data;");
            string msg = data.ToString().Trim();
            if (msg != IDHLanguage.Msg_PleaseDefineSearchCriteria)
            {
                string screenShotName = "DefineSearchCriteria";
                screenShot(screenShotName);
            }
            Assert.AreEqual(IDHLanguage.Msg_PleaseDefineSearchCriteria, msg, msg);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void addData()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnNewAddCharacterType");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnAdd");
            Thread.Sleep(mid);

            /****************Here checking valid MSG dispaly  or not**************************/
            var data = window.ExecuteScript("var data=document.getElementById('spnMessage').innerHTML; return data;");
            string msg = data.ToString().Trim();
            msg = msg.Replace("<br>","");
            string makeMSG = createIDHLan.Msg_PleaseEnterIDHNumber + createIDHLan.Msg_PleaseEnterPreferredBrand; ;
            if (msg != makeMSG)
            {
                string screenShotName = "MessageIs_NotValid";
                screenShot(screenShotName);
            }
            Assert.AreEqual(makeMSG, msg, msg);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void logOut()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);

            /**********************************Log Out******************************/
            Click<HtmlCustom>(PropertyType.Id, "userPropfile");
            Thread.Sleep(max);
            try
            {
                Click<HtmlHyperlink>(PropertyType.Id, "signOut");
            }
            catch (Exception e)
            {
                Thread.Sleep(mid);
                Click<HtmlHyperlink>(PropertyType.InnerText, "Sign Out");
            }
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);

            /***********************Here checking after LogOut login Page in coming or Not******************/

            var data1 = window.ExecuteScript("var data=document.getElementById('ContentPlaceHolder_lblThanks').innerHTML;  return  data");
            string successMsg1 = data1.ToString().Trim();
            string[] msg = successMsg1.Split('.');
            successMsg1 = msg[0];
            string[] resMsg = createIDHLan.Msg_loginMsg.Split('.');
            if (resMsg[0] != successMsg1)
            {
                string screenShotName = "LoginPageNotOpen";
                screenShot(screenShotName);
            }
            Assert.AreEqual(resMsg[0], successMsg1, successMsg1);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void screenShot(string imgName)
        {
            BrowserWindow window = new BrowserWindow();
            string path = ConfigurationSettings.AppSettings["ScreenShot"];
            path = path + @"\\iPAS_MaterialDGCharectersNegative";
            Directory.CreateDirectory(path);
            try
            {
                window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
                Image image = window.CaptureImage();
                image.Save(path + "\\" + imgName + ".jpeg", ImageFormat.Jpeg);
                image.Dispose();
            }
            catch (Exception e) { }
            Console.WriteLine("Screen Shot is Avaliable in " + path + "\t" + "Folder");
        }
        public bool Search()
        {
            BrowserWindow window = new BrowserWindow();
            Thread.Sleep(500);
            var tbl = window.ExecuteScript("var data=document.getElementById('ContentPlaceHolder1_tbCharacterstic').getElementsByTagName('span')[0];  return  data.innerHTML");
            string data = tbl.ToString().Trim();
            bool b1 = data.Equals(IDHLanguage.Msg_NoRecordsFound);
            return b1;
        }
        public void PathEnterText<T>(PropertyType type, string propertyvalue, string text) where T : WinEdit
        {
            WinEdit genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            genericControl.FilterProperties[WinEdit.PropertyNames.Name] = propertyvalue;
            AutoItX3 auto = new AutoItX3();
            auto.WinActivate("Choose File to Upload");
            auto.Send(text);
            auto.Send("{ENTER}");
            Thread.Sleep(1000);
        }
        public void WindowButtonClick<T>(PropertyType type, string propertyvalue) where T : WinControl
        {
            WinControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Name)
                genericControl.SearchProperties[WinControl.PropertyNames.Name] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void Click<T>(PropertyType type, string propertyvalue) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });

            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;
            else if (type == PropertyType.InnerText)
            {
                genericControl.SearchProperties[HtmlControl.PropertyNames.InnerText] = propertyvalue;
            }
            else if (type == PropertyType.TagInstance)
                genericControl.FilterProperties[HtmlControl.PropertyNames.TagInstance] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void EnterText<T>(PropertyType type, string propertyvalue, string text) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;

            Keyboard.SendKeys(genericControl, text);

        }
        private BrowserWindow mparentwindow { get; set; }
        public enum PropertyType
        {
            Id,
            Name,
            InnerText,
            TagInstance
        }
        public BrowserWindow TopParentWindow()
        {

            BrowserWindow window = new BrowserWindow();
            window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
            return window;
        }
        public BrowserWindow ParentWindow
        {
            get
            {
                if (this.mparentwindow == null)
                {
                    this.mparentwindow = TopParentWindow();
                }
                return this.mparentwindow;
            }
        }
    }
}
