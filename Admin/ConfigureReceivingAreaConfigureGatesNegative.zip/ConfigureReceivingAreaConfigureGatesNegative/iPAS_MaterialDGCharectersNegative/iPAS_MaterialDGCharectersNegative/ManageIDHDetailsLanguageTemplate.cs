﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Text;
using System.Threading.Tasks;

namespace iPAS_MaterialDGCharectersNegative
{
    class ManageIDHDetailsLanguageTemplate
    {
        static CultureInfo ci = null;
        static ResourceManager rm = null;
        static string resMsg_InvalidFileFormat = string.Empty;
        public string Msg_InvalidFileFormat
        {
            get { return resMsg_InvalidFileFormat; }
            set { resMsg_InvalidFileFormat = value; }
        }        
        static string resMsg_NoRecordsFound = string.Empty;
        public string Msg_NoRecordsFound
        {
            get { return resMsg_NoRecordsFound; }
            set { resMsg_NoRecordsFound = value; }
        }
        static string resMsg_PleaseDefineSearchCriteria = string.Empty;
        public string Msg_PleaseDefineSearchCriteria
        {
            get { return resMsg_PleaseDefineSearchCriteria; }
            set { resMsg_PleaseDefineSearchCriteria = value; }
        }

        public static void messageResource(string languageCode)
        {
            if (languageCode == "zh-CN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_MaterialDGCharectersNegative.resource.ManageIDHDetailsCN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "th-TH")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_MaterialDGCharectersNegative.resource.ManageIDHDetailsTH", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "vi-VN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_MaterialDGCharectersNegative.resource.ManageIDHDetailsVN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "ko-KR")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_MaterialDGCharectersNegative.resource.ManageIDHDetailsKR", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "ja-JP")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_MaterialDGCharectersNegative.resource.ManageIDHDetailsJP", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "id-ID")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_MaterialDGCharectersNegative.resource.ManageIDHDetailsID", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_MaterialDGCharectersNegative.resource.ManageIDHDetailsEN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
        }
        public static void messageInitialize()
        {
            resMsg_InvalidFileFormat = rm.GetString("resMsg_InvalidFileFormat", ci).Trim(); 
             resMsg_NoRecordsFound = rm.GetString("resMsg_NoRecordsFound", ci).Trim();
            resMsg_PleaseDefineSearchCriteria = rm.GetString("resMsg_PleaseDefineSearchCriteria", ci).Trim();
        }

    }
}
