﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Text;
using System.Threading.Tasks;

namespace iPAS_MaterialDGCharectersNegative
{
    class CreateIDHCharactersLanguageTemplate
    {
        static CultureInfo ci = null;
        static ResourceManager rm = null;
        static string resMsg_PleaseEnterIDHNumber = string.Empty;
        public string Msg_PleaseEnterIDHNumber
        {
            get { return resMsg_PleaseEnterIDHNumber; }
            set { resMsg_PleaseEnterIDHNumber = value; }
            
        }
        static string resMsg_PleaseEnterPreferredBrand = string.Empty;
        public string Msg_PleaseEnterPreferredBrand
        {
            get { return resMsg_PleaseEnterPreferredBrand; }
            set { resMsg_PleaseEnterPreferredBrand = value; }
        }
        static string resMsg_loginMsg = string.Empty;
        public string Msg_loginMsg
        {
            get { return resMsg_loginMsg; }
            set { resMsg_loginMsg = value; }
        }

        public static void messageResource(string languageCode)
        {
            if (languageCode == "zh-CN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_MaterialDGCharectersNegative.resource.CreateIDHCharactersCN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "th-TH")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_MaterialDGCharectersNegative.resource.CreateIDHCharactersTH", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "vi-VN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_MaterialDGCharectersNegative.resource.CreateIDHCharactersVN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "ko-KR")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_MaterialDGCharectersNegative.resource.CreateIDHCharactersKR", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "ja-JP")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_MaterialDGCharectersNegative.resource.CreateIDHCharactersJP", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "id-ID")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_MaterialDGCharectersNegative.resource.CreateIDHCharactersID", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_MaterialDGCharectersNegative.resource.CreateIDHCharactersEN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
        }
        public static void messageInitialize()
        {
            resMsg_PleaseEnterIDHNumber = rm.GetString("resMsg_PleaseEnterIDHNumber", ci).Trim(); 
            resMsg_PleaseEnterPreferredBrand = rm.GetString("resMsg_PleaseEnterPreferredBrand", ci).Trim();
            resMsg_loginMsg = rm.GetString("resMsg_loginMsg", ci).Trim();

        }

    }
}
