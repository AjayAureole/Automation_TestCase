﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Text;
using System.Threading.Tasks;

namespace iPAS_ReceivingNotesPurchasingGroupN
{
    class GRNotesLanguageTemplate
    {
        static CultureInfo ci = null;
        static ResourceManager rm = null;
        static string resMsg_EnterShelfLifeValue = string.Empty;
        public string Msg_EnterShelfLifeValue
        {
            get { return resMsg_EnterShelfLifeValue; }
            set { resMsg_EnterShelfLifeValue = value; }
        }
        static string resMsg_InvalidFileFormat = string.Empty;
        public string Msg_InvalidFileFormat
        {
            get { return resMsg_InvalidFileFormat; }
            set { resMsg_InvalidFileFormat = value; }
        }
        
        static string resMsg_LoginMsg = string.Empty;
        public string Msg_LoginMsg
        {
            get { return resMsg_LoginMsg; }
            set { resMsg_LoginMsg = value; }
        }
        static string resMsg_EnterSearchCriteria = string.Empty;
        public string Msg_EnterSearchCriteria
        {
            get { return resMsg_EnterSearchCriteria; }
            set { resMsg_EnterSearchCriteria = value; }
        }
        public static void messageResource(string languageCode)
        {
            if (languageCode == "zh-CN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ReceivingNotesPurchasingGroupN.resource.GRNotesCN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "th-TH")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ReceivingNotesPurchasingGroupN.resource.GRNotesTH", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "vi-VN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ReceivingNotesPurchasingGroupN.resource.GRNotesVN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "ko-KR")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ReceivingNotesPurchasingGroupN.resource.GRNotesKR", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "ja-JP")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ReceivingNotesPurchasingGroupN.resource.GRNotesJP", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "id-ID")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ReceivingNotesPurchasingGroupN.resource.GRNotesID", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ReceivingNotesPurchasingGroupN.resource.GRNotesEN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
        }
        public static void messageInitialize()
        {
            resMsg_EnterShelfLifeValue = rm.GetString("resMsg_EnterShelfLifeValue", ci).Trim();
            resMsg_InvalidFileFormat = rm.GetString("resMsg_InvalidFileFormat", ci).Trim();
            resMsg_LoginMsg = rm.GetString("resMsg_LoginMsg", ci).Trim();
            resMsg_EnterSearchCriteria = rm.GetString("resMsg_EnterSearchCriteria", ci).Trim();

    }
}
}
