﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Text;
using System.Threading.Tasks;

namespace iPAS_ReceivingNotesPurchasingGroupN
{
    class POGroupLanguageTemplate
    {
        static CultureInfo ci = null;
        static ResourceManager rm = null;
        static string resMsg_PleaseEnterPOGroup = string.Empty;
        public string Msg_PleaseEnterPOGroup
        {
            get { return resMsg_PleaseEnterPOGroup; }
            set { resMsg_PleaseEnterPOGroup = value; }
        }
        static string resMsg_PleaseSelectOneTechnology = string.Empty;
        public string Msg_PleaseSelectOneTechnology
        {
            get { return resMsg_PleaseSelectOneTechnology; }
            set { resMsg_PleaseSelectOneTechnology = value; }
        }
        public static void messageResource(string languageCode)
        {
            if (languageCode == "zh-CN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ReceivingNotesPurchasingGroupN.resource.POGroupCN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "th-TH")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ReceivingNotesPurchasingGroupN.resource.POGroupTH", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "vi-VN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ReceivingNotesPurchasingGroupN.resource.POGroupVN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "ko-KR")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ReceivingNotesPurchasingGroupN.resource.POGroupKR", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "ja-JP")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ReceivingNotesPurchasingGroupN.resource.POGroupJP", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "id-ID")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ReceivingNotesPurchasingGroupN.resource.POGroupID", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_ReceivingNotesPurchasingGroupN.resource.POGroupEN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
        }
        public static void messageInitialize()
        {
            resMsg_PleaseEnterPOGroup = rm.GetString("resMsg_PleaseEnterPOGroup", ci).Trim();
            resMsg_PleaseSelectOneTechnology = rm.GetString("resMsg_PleaseSelectOneTechnology", ci).Trim();
        }
    }
}
